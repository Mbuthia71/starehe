import { r as getClientId, t as authHeaders } from "./auth-DetQxYHL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/selfApi-DGdOs9vm.js
var BASE = "/fineract-provider/api/v1";
var MPESA_BASE = "https://204.168.218.166:8081";
async function selfGet(path) {
	const res = await fetch(`${BASE}${path}`, { headers: authHeaders() });
	if (res.status === 401) throw new Error("Session expired. Please log in again.");
	if (!res.ok) {
		const err = await res.json().catch(() => ({}));
		throw new Error(err.defaultUserMessage || `Error ${res.status}`);
	}
	return res.json();
}
async function selfPost(path, body) {
	const res = await fetch(`${BASE}${path}`, {
		method: "POST",
		headers: authHeaders(),
		body: JSON.stringify(body)
	});
	if (res.status === 401) throw new Error("Session expired. Please log in again.");
	const data = await res.json();
	if (!res.ok) {
		console.error("[Fineract API] Error response:", {
			status: res.status,
			statusText: res.statusText,
			path,
			body,
			responseData: data,
			errors: data.errors,
			defaultUserMessage: data.defaultUserMessage
		});
		throw new Error(data.defaultUserMessage || data.errors?.[0]?.defaultUserMessage || JSON.stringify(data.errors) || `Error ${res.status}`);
	}
	return data;
}
async function getSelfAccounts() {
	const clientId = getClientId();
	console.log("Fetching accounts for clientId:", clientId);
	if (!clientId) throw new Error("Not authenticated");
	const data = await selfGet(`/savingsaccounts`);
	const items = data.pageItems ?? data.savingsAccounts ?? [];
	console.log("Total accounts returned:", items.length);
	const filtered = items.filter((a) => a.clientId === clientId);
	console.log("Filtered accounts for clientId", clientId, ":", filtered.length, filtered.map((a) => ({
		id: a.id,
		accountNo: a.accountNo,
		clientId: a.clientId
	})));
	return filtered.map((a) => ({
		id: String(a.id),
		accountNo: a.accountNo,
		type: mapSavingsType(a.depositType?.value || a.savingsProductName || "Savings"),
		balance: a.summary?.accountBalance ?? 0,
		available: a.summary?.availableBalance ?? a.summary?.accountBalance ?? 0,
		interestRate: a.nominalAnnualInterestRate ?? 0,
		status: a.status?.value === "Active" ? "Active" : a.status?.value === "Dormant" ? "Dormant" : "Closed",
		openedOn: a.timeline?.activatedOnDate?.join?.("-") || ""
	}));
}
function mapSavingsType(raw) {
	if (/share/i.test(raw)) return "Share Capital";
	if (/fixed|deposit/i.test(raw)) return "Fixed Deposit";
	if (/junior|target/i.test(raw)) return "Junior Savings";
	return "Savings";
}
async function getSelfTransactions(accountId) {
	const data = await selfGet(`/savingsaccounts/${accountId}?associations=transactions`);
	return (data.pageItems ?? data.transactions ?? []).map((t) => ({
		id: String(t.id),
		date: t.date?.join?.("-") || "",
		description: t.transactionType?.value || "Transaction",
		accountId,
		category: mapTxCategory(t.transactionType?.value || ""),
		amount: t.transactionType?.withdrawal ? -t.amount : t.amount,
		status: t.reversed ? "Failed" : "Completed",
		reference: t.paymentDetailData?.receiptNumber || void 0
	}));
}
function mapTxCategory(type) {
	if (/deposit/i.test(type)) return "Deposit";
	if (/withdrawal/i.test(type)) return "Withdrawal";
	if (/repayment/i.test(type)) return "Loan Repayment";
	if (/disburse/i.test(type)) return "Disbursement";
	if (/interest/i.test(type)) return "Interest";
	return "Deposit";
}
async function getSelfLoans() {
	const clientId = getClientId();
	if (!clientId) throw new Error("Not authenticated");
	const data = await selfGet(`/loans`);
	return (data.pageItems ?? data.loans ?? []).filter((l) => l.clientId === clientId).map((l) => ({
		id: String(l.id),
		accountNo: l.accountNo,
		product: l.loanProductName,
		principal: l.principal ?? l.approvedPrincipal ?? 0,
		outstanding: l.summary?.principalOutstanding ?? l.principal ?? 0,
		paid: l.summary?.principalPaid ?? 0,
		nextPaymentAmount: l.repaymentSchedule?.periods?.find((p) => !p.complete)?.totalDueForPeriod ?? 0,
		nextPaymentDate: l.repaymentSchedule?.periods?.find((p) => !p.complete)?.dueDate?.join?.("-") ?? "",
		stage: mapLoanStage(l.status?.value || ""),
		daysOverdue: l.summary?.overdueSinceDate ? Math.floor((Date.now() - new Date(l.summary.overdueSinceDate.join("-")).getTime()) / 864e5) : 0,
		guarantors: [],
		disbursedOn: l.timeline?.actualDisbursementDate?.join?.("-"),
		termMonths: l.numberOfRepayments ?? 12,
		monthsPaid: l.summary?.numberOfRepaymentsMade ?? 0,
		rate: l.annualInterestRate ?? l.interestRatePerPeriod ?? 0
	}));
}
function mapLoanStage(status) {
	if (/pending/i.test(status)) return "Applied";
	if (/approved/i.test(status)) return "Approved";
	if (/active/i.test(status)) return "Active";
	if (/arrears/i.test(status) || /overdue/i.test(status)) return "Arrears";
	if (/close/i.test(status)) return "Closed";
	if (/disburse/i.test(status)) return "Disbursed";
	return "Applied";
}
async function getSelfLoanProducts() {
	const data = await selfGet("/loanproducts");
	return (Array.isArray(data) ? data : []).map((p) => ({
		id: String(p.id),
		name: p.name,
		rate: p.annualInterestRate ?? p.interestRatePerPeriod ?? 0,
		minTermMonths: p.minNumberOfRepayments ?? 1,
		maxTermMonths: p.maxNumberOfRepayments ?? 60,
		minAmount: p.minPrincipal ?? 5e3,
		maxAmount: p.maxPrincipal ?? 3e6,
		eligibility: p.description || "Contact branch for eligibility details",
		description: p.description || p.name
	}));
}
async function applySelfLoan(productId, amount, termMonths, interestRate) {
	console.log("[Loan Application] Starting application:", {
		productId,
		amount,
		termMonths,
		interestRate
	});
	const clientId = getClientId();
	if (!clientId) throw new Error("Not authenticated");
	const today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric"
	}).replace(/\//g, " ");
	const payload = {
		clientId,
		productId: Number(productId),
		principal: amount,
		loanTermFrequency: termMonths,
		loanTermFrequencyType: 2,
		numberOfRepayments: termMonths,
		repaymentEvery: 1,
		repaymentFrequencyType: 2,
		interestRatePerPeriod: interestRate,
		amortizationType: 1,
		interestType: 0,
		interestCalculationPeriodType: 1,
		transactionProcessingStrategyCode: "mifos-standard-strategy",
		submittedOnDate: today,
		expectedDisbursementDate: today,
		dateFormat: "dd MM yyyy",
		locale: "en"
	};
	console.log("[Loan Application] Sending to Fineract:", payload);
	const result = await selfPost("/loans", payload);
	console.log("[Loan Application] Success:", result);
	return result;
}
async function lookupAccountByNumber(accountNo) {
	const data = await selfGet(`/savingsaccounts`);
	const account = (data.pageItems ?? data.savingsAccounts ?? []).find((a) => a.accountNo === accountNo);
	if (!account) throw new Error("Account not found");
	return {
		id: String(account.id),
		accountNo: account.accountNo,
		clientName: account.clientName,
		clientId: account.clientId ? String(account.clientId) : null,
		type: mapSavingsType(account.depositType?.value || account.savingsProductName || "Savings")
	};
}
async function transferToMember(fromAccountId, toAccountId, amount, description, toClientId) {
	try {
		console.log("[P2P Transfer] Starting transfer:", {
			fromAccountId,
			toAccountId,
			amount,
			description
		});
		const clientId = getClientId();
		if (!clientId) throw new Error("Not authenticated");
		if (!fromAccountId || !toAccountId) throw new Error("From account and To account are required");
		if (!amount || amount <= 0) throw new Error("Transfer amount must be greater than 0");
		if (fromAccountId === toAccountId) throw new Error("Cannot transfer to the same account");
		const today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", {
			day: "2-digit",
			month: "long",
			year: "numeric"
		});
		console.log("[P2P Transfer] Sending request to Fineract:", {
			fromAccountId: Number(fromAccountId),
			toAccountId: Number(toAccountId),
			fromClientId: Number(clientId),
			toClientId,
			amount,
			transferDate: today
		});
		const result = await selfPost("/accounttransfers", {
			fromOfficeId: 1,
			fromClientId: Number(clientId),
			fromAccountType: 2,
			fromAccountId: Number(fromAccountId),
			toOfficeId: 1,
			toClientId: toClientId ? Number(toClientId) : void 0,
			toAccountType: 2,
			toAccountId: Number(toAccountId),
			transferDate: today,
			transferAmount: amount,
			transferDescription: description || "P2P Transfer",
			dateFormat: "dd MMMM yyyy",
			locale: "en"
		});
		console.log("[P2P Transfer] Transfer successful:", result);
		return result;
	} catch (error) {
		console.error("[P2P Transfer] Error:", error);
		if (error.response) console.error("[P2P Transfer] API response:", error.response.status, error.response.data);
		throw new Error(error.message || "Transfer failed. Please try again.");
	}
}
async function getMemberCardDetails(clientId) {
	const notes = await selfGet(`/clients/${clientId}/notes`);
	const cardNote = (Array.isArray(notes) ? notes : notes.pageItems ?? []).map((n) => {
		try {
			return JSON.parse(n.note);
		} catch {
			return null;
		}
	}).filter((d) => d && d.cardNumber).pop();
	if (!cardNote) return null;
	return {
		cardNumber: cardNote.cardNumber,
		expiryDate: cardNote.expiryDate,
		cvv: cardNote.cvv,
		cardType: cardNote.cardType || "Virtual",
		status: cardNote.status || "Active",
		issuedAt: cardNote.issuedAt,
		dailyLimit: cardNote.dailyLimit,
		monthlyLimit: cardNote.monthlyLimit
	};
}
async function stkPush(msisdn, amount, accountRef) {
	const res = await fetch(`${MPESA_BASE}/stk/push`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			msisdn: msisdn.replace(/\s/g, ""),
			amount,
			account_ref: accountRef,
			description: `Payment for ${accountRef}`
		})
	});
	if (!res.ok) throw new Error("M-Pesa STK push failed");
	return res.json();
}
async function withdrawViaMpesa(accountId, amount, msisdn) {
	const clientId = getClientId();
	const res = await fetch(`${MPESA_BASE}/b2c/withdraw`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			account_id: accountId,
			client_id: String(clientId),
			msisdn: msisdn.replace(/\s/g, ""),
			amount
		})
	});
	const data = await res.json().catch(() => ({}));
	if (!res.ok) throw new Error(data.message || "Withdrawal failed");
	return data;
}
//#endregion
export { getSelfLoans as a, stkPush as c, getSelfLoanProducts as i, transferToMember as l, getMemberCardDetails as n, getSelfTransactions as o, getSelfAccounts as r, lookupAccountByNumber as s, applySelfLoan as t, withdrawViaMpesa as u };
