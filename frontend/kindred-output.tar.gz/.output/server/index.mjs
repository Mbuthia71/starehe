globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/api-DIvt6uQQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d73-vsIrrMACzpFUxyZCDPYh2PCt8mQ\"",
		"mtime": "2026-06-22T08:09:08.697Z",
		"size": 3443,
		"path": "../public/assets/api-DIvt6uQQ.js"
	},
	"/assets/arrow-left-CD89c06s.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a4-AmQ7S6GcTqe2Dxt2HNb7vufsgLs\"",
		"mtime": "2026-06-22T08:09:08.697Z",
		"size": 164,
		"path": "../public/assets/arrow-left-CD89c06s.js"
	},
	"/assets/auth-BHDXz6-B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e20c-eplTmxBk6Rbv7kefcewpinwSCAs\"",
		"mtime": "2026-06-22T08:09:08.706Z",
		"size": 123404,
		"path": "../public/assets/auth-BHDXz6-B.js"
	},
	"/assets/auth.otp-BvKwIKah.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"56d-HTXJK1GAo5VhQMOYXYT4L0EugTg\"",
		"mtime": "2026-06-22T08:09:08.708Z",
		"size": 1389,
		"path": "../public/assets/auth.otp-BvKwIKah.js"
	},
	"/assets/auth.login-7R1FTRVf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ac7-5zcfSawU5o011d4BHptuS3Ba+3k\"",
		"mtime": "2026-06-22T08:09:08.707Z",
		"size": 2759,
		"path": "../public/assets/auth.login-7R1FTRVf.js"
	},
	"/assets/auth.pin-setup-UyNdE_Ql.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"69a-eoelzQchi5+t+LOzjlDgVsWM0Mg\"",
		"mtime": "2026-06-22T08:09:08.709Z",
		"size": 1690,
		"path": "../public/assets/auth.pin-setup-UyNdE_Ql.js"
	},
	"/assets/banknote-BOMg5vhb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f5-J1bNlciVw7cjLabZxzBEOAomMGc\"",
		"mtime": "2026-06-22T08:09:08.732Z",
		"size": 245,
		"path": "../public/assets/banknote-BOMg5vhb.js"
	},
	"/assets/chevron-right-BaJECq_P.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"81-VJTNt07CN1YXKpFIDdMpqd2jucI\"",
		"mtime": "2026-06-22T08:09:08.733Z",
		"size": 129,
		"path": "../public/assets/chevron-right-BaJECq_P.js"
	},
	"/assets/circle-plus-C38gbffT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ce-vAYOb6iEik7ezdbEDFHeBxrutuU\"",
		"mtime": "2026-06-22T08:09:08.734Z",
		"size": 206,
		"path": "../public/assets/circle-plus-C38gbffT.js"
	},
	"/assets/createLucideIcon-CPOOcYn_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"38c-xkpRak2pTFBnZDhtSS5kGErLEsA\"",
		"mtime": "2026-06-22T08:09:08.735Z",
		"size": 908,
		"path": "../public/assets/createLucideIcon-CPOOcYn_.js"
	},
	"/assets/credit-card-B77suztx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ce-MGPSsulx7aQlZppUM50WmP6KWGs\"",
		"mtime": "2026-06-22T08:09:08.737Z",
		"size": 206,
		"path": "../public/assets/credit-card-B77suztx.js"
	},
	"/assets/EmptyState-CX6nppw4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"269-chsEMjKRHlhqCZb2YgIKBqaHWuU\"",
		"mtime": "2026-06-22T08:09:08.691Z",
		"size": 617,
		"path": "../public/assets/EmptyState-CX6nppw4.js"
	},
	"/assets/file-text-DePsHLEC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c-L+OdN59zxvpGd/G0JUCjSUv7gIk\"",
		"mtime": "2026-06-22T08:09:08.738Z",
		"size": 332,
		"path": "../public/assets/file-text-DePsHLEC.js"
	},
	"/assets/eye-CsqugZdO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"278-tVxAnVikDNWgpFKYz9GRLb1gnKk\"",
		"mtime": "2026-06-22T08:09:08.738Z",
		"size": 632,
		"path": "../public/assets/eye-CsqugZdO.js"
	},
	"/assets/format-DFUkzCo6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c9-4Y6UusYPg5eL3dC25XV+nqI5ovg\"",
		"mtime": "2026-06-22T08:09:08.740Z",
		"size": 457,
		"path": "../public/assets/format-DFUkzCo6.js"
	},
	"/assets/index-CxUMcYUf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5a698-O8tIbIM8yaPvtr1Li7/K4mYN4no\"",
		"mtime": "2026-06-22T08:09:08.687Z",
		"size": 370328,
		"path": "../public/assets/index-CxUMcYUf.js"
	},
	"/assets/jsx-runtime-DnlWeMvz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21db-DyRXgHJbgwJH/PAr3ueX5dgg7Yc\"",
		"mtime": "2026-06-22T08:09:08.741Z",
		"size": 8667,
		"path": "../public/assets/jsx-runtime-DnlWeMvz.js"
	},
	"/assets/react-dom-DriRPPLg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dda-Oa1wKf/KHSM9SlgG7lpQE8MQ8ZU\"",
		"mtime": "2026-06-22T08:09:08.742Z",
		"size": 3546,
		"path": "../public/assets/react-dom-DriRPPLg.js"
	},
	"/assets/selfApi-51VIF9_H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3f61-EpJhU42SJ6kbdnWiB1n3dMMSWPI\"",
		"mtime": "2026-06-22T08:09:08.744Z",
		"size": 16225,
		"path": "../public/assets/selfApi-51VIF9_H.js"
	},
	"/assets/siohioma-logo-zm9kMDod.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a-+oK+Go0ZLkF4kWJlwUkuPORYhyk\"",
		"mtime": "2026-06-22T08:09:08.745Z",
		"size": 58,
		"path": "../public/assets/siohioma-logo-zm9kMDod.js"
	},
	"/assets/check-DisOH-Hr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c-/4WcKqToimp96paDBYGABBfGQeY\"",
		"mtime": "2026-06-22T08:09:08.732Z",
		"size": 124,
		"path": "../public/assets/check-DisOH-Hr.js"
	},
	"/assets/StatusPill-DnckxUbZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6b4b-xwLmtvYwwOFMd6CUdgYEW4vyTXY\"",
		"mtime": "2026-06-22T08:09:08.692Z",
		"size": 27467,
		"path": "../public/assets/StatusPill-DnckxUbZ.js"
	},
	"/assets/styles-D6N1PQ_-.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17506-qdNdQsy69Dkw385Xyc2dfvvgYAQ\"",
		"mtime": "2026-06-22T08:09:08.751Z",
		"size": 95494,
		"path": "../public/assets/styles-D6N1PQ_-.css"
	},
	"/assets/useMutation-LTEkrm95.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8ca-MuiWv2AJbEX+zYvQNovrPaZaNXY\"",
		"mtime": "2026-06-22T08:09:08.746Z",
		"size": 2250,
		"path": "../public/assets/useMutation-LTEkrm95.js"
	},
	"/assets/user-Cf8iIhzP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4-pkA9VbLRCVU4cAVjK/iT8S7qrBw\"",
		"mtime": "2026-06-22T08:09:08.747Z",
		"size": 196,
		"path": "../public/assets/user-Cf8iIhzP.js"
	},
	"/assets/siohioma-logo-BTZxRCjr.png": {
		"type": "image/png",
		"etag": "\"1f7d1b-PSla8ctnEZ1FDFAeBCbjteG8CbA\"",
		"mtime": "2026-06-22T08:09:08.750Z",
		"size": 2063643,
		"path": "../public/assets/siohioma-logo-BTZxRCjr.png"
	},
	"/assets/users-B2L7i_p8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"130-EUu8E/mjwzBGwODJ7Wc4Iij8YL4\"",
		"mtime": "2026-06-22T08:09:08.748Z",
		"size": 304,
		"path": "../public/assets/users-B2L7i_p8.js"
	},
	"/assets/_app-7MEALYfx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c44-ut5KVRMwTmrMqfycCshMY468s5U\"",
		"mtime": "2026-06-22T08:09:08.693Z",
		"size": 11332,
		"path": "../public/assets/_app-7MEALYfx.js"
	},
	"/assets/_app.accounts-3kBOjhkC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d05-Ha5y2EWAWEwu+oGSu+AQIPHPFKo\"",
		"mtime": "2026-06-22T08:09:08.695Z",
		"size": 3333,
		"path": "../public/assets/_app.accounts-3kBOjhkC.js"
	},
	"/assets/_app.cards-CIv-3U8R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1733-WxYPGSZmtVfTNRnATFZ6Y8WpH+I\"",
		"mtime": "2026-06-22T08:09:08.695Z",
		"size": 5939,
		"path": "../public/assets/_app.cards-CIv-3U8R.js"
	},
	"/assets/_app.guarantors-C4CKQbz0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2c-97THV5qcRy3yF3TPRnFCi4h3WIs\"",
		"mtime": "2026-06-22T08:09:08.695Z",
		"size": 2860,
		"path": "../public/assets/_app.guarantors-C4CKQbz0.js"
	},
	"/assets/_app.index-BfbpglPL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1763-m3zCQNF9ZVjkK0oafYwMFkPhQF4\"",
		"mtime": "2026-06-22T08:09:08.697Z",
		"size": 5987,
		"path": "../public/assets/_app.index-BfbpglPL.js"
	},
	"/assets/_app.loans-BCJQdM22.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1375-xzhs713BrJeEjdIVVtaW6myBTmI\"",
		"mtime": "2026-06-22T08:09:08.697Z",
		"size": 4981,
		"path": "../public/assets/_app.loans-BCJQdM22.js"
	},
	"/assets/_app.loans.apply-BVL99uaZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ecc-rBZ2cyoSgiqnmAp7MUmaY3KiJOk\"",
		"mtime": "2026-06-22T08:09:08.697Z",
		"size": 7884,
		"path": "../public/assets/_app.loans.apply-BVL99uaZ.js"
	},
	"/assets/_app.profile-BNEE4TXI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13ec-DE9JeucNsw4Rm2uHTDIwczhYRCA\"",
		"mtime": "2026-06-22T08:09:08.697Z",
		"size": 5100,
		"path": "../public/assets/_app.profile-BNEE4TXI.js"
	},
	"/assets/_app.statements-yzDYORZj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7db-eCrCkvzG3XW7bVHwneRDzkiHUNM\"",
		"mtime": "2026-06-22T08:09:08.697Z",
		"size": 2011,
		"path": "../public/assets/_app.statements-yzDYORZj.js"
	},
	"/assets/_app.transfer-aZ1OFfT8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"172a-8vGTbHatiV3hFmp49M2+pjXM8kE\"",
		"mtime": "2026-06-22T08:09:08.697Z",
		"size": 5930,
		"path": "../public/assets/_app.transfer-aZ1OFfT8.js"
	},
	"/assets/_app.withdraw-C38ZefTV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10e1-l2YG3m5C1zEaMTowLdpPQfbRamE\"",
		"mtime": "2026-06-22T08:09:08.697Z",
		"size": 4321,
		"path": "../public/assets/_app.withdraw-C38ZefTV.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_dxhdju = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_dxhdju
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
