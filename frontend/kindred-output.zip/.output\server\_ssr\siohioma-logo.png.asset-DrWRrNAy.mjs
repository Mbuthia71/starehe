//#region node_modules/.nitro/vite/services/ssr/assets/siohioma-logo.png.asset-DrWRrNAy.js
var siohioma_logo_png_asset_default = {
	asset_id: "f03108cc-3cba-4407-bb89-d89198e622bd",
	content_type: "image/png",
	created_at: "2026-06-21T08:07:18Z",
	original_filename: "siohioma-logo.png",
	project_id: "e147c9a7-378e-42ac-8c1d-1357893284c9",
	r2_key: "a/v1/e147c9a7-378e-42ac-8c1d-1357893284c9/f03108cc-3cba-4407-bb89-d89198e622bd/siohioma-logo.png",
	size: 274635,
	url: "/__l5e/assets-v1/f03108cc-3cba-4407-bb89-d89198e622bd/siohioma-logo.png",
	version: 1
};
//#endregion
export { siohioma_logo_png_asset_default as t };
