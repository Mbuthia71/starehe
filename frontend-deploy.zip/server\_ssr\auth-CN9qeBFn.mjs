//#region node_modules/.nitro/vite/services/ssr/assets/auth-CN9qeBFn.js
var API_CONFIG = {
	baseUrl: "/api",
	timeout: parseInt("30000"),
	headers: (token) => ({
		"Content-Type": "application/json",
		...token ? { Authorization: `Bearer ${token}` } : {}
	})
};
var Logger = class {
	logs = [];
	maxLogs = 1e3;
	minLevel = 1;
	constructor() {
		if (typeof window === "undefined") setInterval(() => this.flushLogs(), 3e4);
	}
	setMinLevel(level) {
		this.minLevel = level;
	}
	log(level, message, context) {
		if (level < this.minLevel) return;
		const entry = {
			timestamp: (/* @__PURE__ */ new Date()).toISOString(),
			level,
			message,
			context,
			userId: this.getUserId(),
			sessionId: this.getSessionId()
		};
		this.logs.push(entry);
		if (this.logs.length > this.maxLogs) this.logs = this.logs.slice(-this.maxLogs);
	}
	getLevelEmoji(level) {
		switch (level) {
			case 0: return "🔍";
			case 1: return "ℹ️";
			case 2: return "⚠️";
			case 3: return "❌";
			case 4: return "💀";
			default: return "📝";
		}
	}
	getUserId() {
		if (typeof window === "undefined") return void 0;
		try {
			return localStorage.getItem("siohioma_clientId") || void 0;
		} catch {
			return;
		}
	}
	getSessionId() {
		if (typeof window === "undefined") return void 0;
		try {
			return sessionStorage.getItem("session_id") || void 0;
		} catch {
			return;
		}
	}
	debug(message, context) {
		this.log(0, message, context);
	}
	info(message, context) {
		this.log(1, message, context);
	}
	warn(message, context) {
		this.log(2, message, context);
	}
	error(message, context) {
		this.log(3, message, context);
	}
	fatal(message, context) {
		this.log(4, message, context);
	}
	getLogs(level) {
		if (level !== void 0) return this.logs.filter((log) => log.level >= level);
		return [...this.logs];
	}
	clearLogs() {
		this.logs = [];
	}
	async flushLogs() {
		if (this.logs.length === 0) return;
		try {
			if (typeof window !== "undefined") await fetch("/api/logs", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ logs: this.logs })
			});
			this.logs = [];
		} catch (error) {
			console.error("Failed to flush logs:", error);
		}
	}
};
var logger = new Logger();
var TOKEN_KEY = "oss_token";
var REFRESH_TOKEN_KEY = "oss_refresh_token";
var USER_ID_KEY = "oss_user_id";
var ROLE_KEY = "oss_role";
var SESSION_TIMEOUT_KEY = "oss_last_activity";
var SESSION_TIMEOUT_MS = 3600 * 1e3;
var isBrowser = () => typeof window !== "undefined" && typeof localStorage !== "undefined";
function getToken() {
	if (!isBrowser()) return null;
	return localStorage.getItem(TOKEN_KEY);
}
function getUserId() {
	if (!isBrowser()) return null;
	return localStorage.getItem(USER_ID_KEY);
}
function getRole() {
	if (!isBrowser()) return "member";
	return localStorage.getItem(ROLE_KEY) || "member";
}
function isAuthenticated() {
	return !!getToken() && !!getUserId();
}
function saveAuth(state) {
	localStorage.setItem(TOKEN_KEY, state.token);
	localStorage.setItem(REFRESH_TOKEN_KEY, state.refreshToken);
	localStorage.setItem(USER_ID_KEY, state.userId);
	localStorage.setItem(ROLE_KEY, state.role);
}
function getStoredMember() {
	if (!isBrowser()) return null;
	const userId = getUserId();
	const role = getRole();
	if (!userId) return null;
	const stored = localStorage.getItem("oss_member_data");
	if (stored) return JSON.parse(stored);
	return {
		id: userId,
		displayName: "Old Starehian",
		role
	};
}
function clearAuth() {
	if (!isBrowser()) return;
	localStorage.removeItem(TOKEN_KEY);
	localStorage.removeItem(REFRESH_TOKEN_KEY);
	localStorage.removeItem(USER_ID_KEY);
	localStorage.removeItem(ROLE_KEY);
}
var permissions = {
	super_admin: [
		"read",
		"write",
		"delete",
		"approve",
		"manage_users",
		"view_all",
		"broadcast",
		"bulk"
	],
	moderator: [
		"read",
		"write",
		"approve",
		"moderate"
	],
	support: [
		"read",
		"write",
		"support"
	],
	member: ["read_own", "write_own"]
};
function hasPermission(action) {
	return permissions[getRole()].includes(action) || false;
}
async function apiCall(endpoint, options = {}) {
	const url = `${API_CONFIG.baseUrl}${endpoint}`;
	const token = getToken();
	const response = await fetch(url, {
		...options,
		headers: {
			...API_CONFIG.headers(token || void 0),
			...options.headers
		}
	});
	if (!response.ok) {
		const error = await response.json().catch(() => ({ error: "Request failed" }));
		throw new Error(error.error || `HTTP ${response.status}`);
	}
	return response.json();
}
async function signup(phone, password, full_name) {
	const response = await apiCall("/auth/signup", {
		method: "POST",
		body: JSON.stringify({
			phone,
			password,
			full_name
		})
	});
	const state = {
		token: response.token,
		refreshToken: response.refresh_token,
		userId: response.user.id,
		role: response.user.role
	};
	saveAuth(state);
	logger.info(`User signed up: ${response.user.id}`);
	return state;
}
async function adminLogin(email, password) {
	const response = await apiCall("/auth/admin/login", {
		method: "POST",
		body: JSON.stringify({
			email,
			password
		})
	});
	const state = {
		token: response.token,
		refreshToken: response.refresh_token,
		userId: response.user.id,
		role: response.user.role
	};
	saveAuth(state);
	logger.info(`Admin logged in: ${response.user.id}`);
	return state;
}
async function login(identifier, password) {
	if (identifier.includes("@")) return adminLogin(identifier, password);
	const response = await apiCall("/auth/login", {
		method: "POST",
		body: JSON.stringify({
			phone: identifier,
			password
		})
	});
	const state = {
		token: response.token,
		refreshToken: response.refresh_token,
		userId: response.user.id,
		role: response.user.role
	};
	saveAuth(state);
	logger.info(`User logged in: ${response.user.id}`);
	return state;
}
function updateActivity() {
	if (!isBrowser()) return;
	localStorage.setItem(SESSION_TIMEOUT_KEY, Date.now().toString());
}
function isSessionExpired() {
	if (!isBrowser()) return false;
	const lastActivity = localStorage.getItem(SESSION_TIMEOUT_KEY);
	if (!lastActivity) return false;
	return Date.now() - Number(lastActivity) > SESSION_TIMEOUT_MS;
}
function startSessionTimeoutCheck(callback) {
	const interval = setInterval(() => {
		if (isSessionExpired()) {
			clearInterval(interval);
			callback();
		}
	}, 3e4);
	return interval;
}
function getDeviceFingerprint() {
	if (typeof navigator === "undefined" || typeof window === "undefined") return "server";
	const ua = navigator.userAgent;
	const language = navigator.language;
	const platform = navigator.platform;
	const screenSize = `${window.screen.width}x${window.screen.height}`;
	const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
	return btoa(`${ua}|${language}|${platform}|${screenSize}|${timezone}`);
}
function isTrustedDevice() {
	if (!isBrowser()) return true;
	const fingerprint = getDeviceFingerprint();
	const trusted = localStorage.getItem("oss_trusted_devices");
	if (!trusted) return false;
	return JSON.parse(trusted).includes(fingerprint);
}
function trustCurrentDevice() {
	if (!isBrowser()) return;
	const fingerprint = getDeviceFingerprint();
	const trusted = localStorage.getItem("oss_trusted_devices");
	const devices = trusted ? JSON.parse(trusted) : [];
	if (!devices.includes(fingerprint)) {
		devices.push(fingerprint);
		localStorage.setItem("oss_trusted_devices", JSON.stringify(devices));
	}
}
function detectDeviceSecurity() {
	if (typeof navigator === "undefined") return {
		isEmulator: false,
		isRooted: false,
		isJailbroken: false
	};
	const ua = navigator.userAgent;
	return {
		isEmulator: /Android SDK|Genymotion|Bluestacks|Nox|LDPlayer|Memu|Simulator|Emulator/i.test(ua),
		isRooted: /Android/i.test(ua) && /root|superuser|magisk|test-keys/i.test(ua.toLowerCase()),
		isJailbroken: /iPhone|iPad|iPod/i.test(ua) && /Cydia|Sileo|checkra1n|unc0ver/i.test(ua)
	};
}
//#endregion
export { isAuthenticated as a, signup as c, updateActivity as d, hasPermission as i, startSessionTimeoutCheck as l, detectDeviceSecurity as n, isTrustedDevice as o, getStoredMember as r, login as s, clearAuth as t, trustCurrentDevice as u };
