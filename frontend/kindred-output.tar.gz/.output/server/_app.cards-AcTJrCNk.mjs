import { o as __toESM } from "./_runtime.mjs";
import { i as getStoredMember } from "./_ssr/auth-DetQxYHL.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { S as Check, _ as CreditCard, h as EyeOff, m as Eye, v as Copy } from "./_libs/lucide-react.mjs";
import { n as getMemberCardDetails } from "./_ssr/selfApi-DGdOs9vm.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.cards-AcTJrCNk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Cards() {
	const member = getStoredMember();
	const [showNumber, setShowNumber] = (0, import_react.useState)(false);
	const [showCvv, setShowCvv] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const { data: card, isLoading } = useQuery({
		queryKey: ["memberCard", member?.id],
		queryFn: () => getMemberCardDetails(Number(member?.id)),
		enabled: !!member?.id
	});
	const copyToClipboard = (text) => {
		navigator.clipboard.writeText(text);
		setCopied(true);
		toast.success("Copied to clipboard");
		setTimeout(() => setCopied(false), 2e3);
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center justify-center py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-muted-foreground",
			children: "Loading card details..."
		})
	});
	if (!card) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-16 text-muted-foreground/50" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 text-lg font-medium",
				children: "No virtual card issued"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Contact admin to request a virtual card"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow",
				children: "Virtual Card"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-1 text-2xl font-semibold tracking-tight",
				children: "Your Visa Card"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 10
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: {
					duration: .5,
					ease: [
						.22,
						1,
						.36,
						1
					]
				},
				className: "card-anchor relative overflow-hidden rounded-2xl p-6 text-anchor-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-16 -top-16 size-48 rounded-full bg-white/5 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-20 -left-10 size-56 rounded-full bg-white/3 blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-semibold uppercase tracking-[0.22em] text-anchor-foreground/60",
									children: "Siohioma SACCO"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-semibold tracking-widest text-anchor-foreground/80",
									children: "VIRTUAL"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "num text-2xl tracking-[0.2em]",
									children: showNumber ? card.cardNumber : "•••• •••• •••• " + card.cardNumber?.slice(-4)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setShowNumber(!showNumber),
									className: "grid size-8 place-items-center rounded-full bg-white/10 text-anchor-foreground/70 active:scale-95",
									children: showNumber ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 flex items-end justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] uppercase tracking-wider text-anchor-foreground/50",
									children: "CARDHOLDER"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 text-sm font-medium uppercase tracking-wide",
									children: member?.displayName || "Member"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-right",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] uppercase tracking-wider text-anchor-foreground/50",
										children: "EXPIRES"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "num mt-1 text-sm font-medium",
										children: card.expiryDate
									})]
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev divide-y divide-border/60 p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-wider text-muted-foreground",
							children: "CVV"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "num text-lg font-semibold",
								children: showCvv ? card.cvv : "•••"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setShowCvv(!showCvv),
								className: "grid size-6 place-items-center rounded-full bg-muted text-muted-foreground active:scale-95",
								children: showCvv ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-3" })
							})]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => copyToClipboard(card.cardNumber?.replace(/\s/g, "") || ""),
							className: "grid size-10 place-items-center rounded-full bg-muted text-muted-foreground active:scale-95",
							children: copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-success" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-wider text-muted-foreground",
							children: "Daily Limit"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "num mt-1 text-sm font-semibold",
							children: ["KES ", card.dailyLimit?.toLocaleString()]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] uppercase tracking-wider text-muted-foreground",
								children: "Monthly Limit"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "num mt-1 text-sm font-semibold",
								children: ["KES ", card.monthlyLimit?.toLocaleString()]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-wider text-muted-foreground",
							children: "Status"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm font-medium text-success",
							children: card.status
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] uppercase tracking-wider text-muted-foreground",
								children: "Issued"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-sm text-muted-foreground",
								children: new Date(card.issuedAt || "").toLocaleDateString()
							})]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-muted/50 px-4 py-3 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Security note:" }), " Never share your card details with anyone. Only use this card on trusted websites."]
			})
		]
	});
}
//#endregion
export { Cards as component };
