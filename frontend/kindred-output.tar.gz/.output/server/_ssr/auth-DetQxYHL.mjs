//#region node_modules/.nitro/vite/services/ssr/assets/auth-DetQxYHL.js
var TOKEN_KEY = "siohioma_token";
var CLIENT_KEY = "siohioma_clientId";
var MEMBER_KEY = "siohioma_member";
function getToken() {
	if (typeof localStorage === "undefined") return null;
	return localStorage.getItem(TOKEN_KEY);
}
function getClientId() {
	if (typeof localStorage === "undefined") return null;
	const v = localStorage.getItem(CLIENT_KEY);
	return v ? Number(v) : null;
}
function getStoredMember() {
	if (typeof localStorage === "undefined") return null;
	const v = localStorage.getItem(MEMBER_KEY);
	return v ? JSON.parse(v) : null;
}
function isAuthenticated() {
	return !!getToken() && !!getClientId();
}
function saveAuth(state) {
	localStorage.setItem(TOKEN_KEY, state.token);
	localStorage.setItem(CLIENT_KEY, String(state.clientId));
	localStorage.setItem(MEMBER_KEY, JSON.stringify(state.member));
}
function clearAuth() {
	localStorage.removeItem(TOKEN_KEY);
	localStorage.removeItem(CLIENT_KEY);
	localStorage.removeItem(MEMBER_KEY);
}
var BASE = "/fineract-provider/api/v1";
var TENANT = "default";
async function login(username, password) {
	const credentials = btoa(`${username}:${password}`);
	console.log(`Attempting login for user: ${username}`);
	const res = await fetch(`${BASE}/clients?searchTerm=${username}`, {
		method: "GET",
		headers: {
			Authorization: `Basic ${credentials}`,
			"Fineract-Platform-TenantId": TENANT,
			"X-Requested-With": "XMLHttpRequest"
		}
	});
	console.log(`Auth response status: ${res.status}`);
	if (!res.ok) {
		const err = await res.json().catch(() => ({}));
		console.error("Auth failed:", err);
		const details = err.errors?.map((e) => e.defaultUserMessage || e.developerMessage).join("; ") || err.defaultUserMessage || `HTTP ${res.status}`;
		throw new Error(`Authentication failed: ${details}`);
	}
	const data = await res.json();
	console.log("Auth response data:", data);
	const clients = data.pageItems || [];
	if (clients.length === 0) {
		console.error("No client found in response");
		throw new Error("User not found or no client associated with this account");
	}
	const usernameParts = username.split(".");
	const expectedFirstName = usernameParts[0]?.toLowerCase();
	const expectedLastName = usernameParts[1]?.toLowerCase();
	const client = clients.find((c) => {
		const firstName = c.firstname?.toLowerCase();
		const lastName = c.lastname?.toLowerCase();
		return firstName === expectedFirstName && lastName === expectedLastName;
	}) || clients[0];
	console.log("Selected client:", client.displayName);
	const clientId = client.id;
	const token = credentials;
	const member = {
		id: clientId,
		displayName: client.displayName || username,
		firstName: client.firstname || username.split(".")?.[0],
		lastName: client.lastname || "",
		accountNo: client.accountNo,
		mobileNo: client.mobileNo,
		emailAddress: client.emailAddress
	};
	console.log("Login successful for:", member.displayName, "with clientId:", clientId);
	const state = {
		token,
		clientId: Number(clientId),
		member
	};
	saveAuth(state);
	console.log("Saved auth state with clientId:", state.clientId);
	return state;
}
function authHeaders() {
	return {
		Authorization: `Basic ${getToken()}`,
		"Fineract-Platform-TenantId": TENANT,
		"Content-Type": "application/json",
		"X-Requested-With": "XMLHttpRequest"
	};
}
//#endregion
export { isAuthenticated as a, getStoredMember as i, clearAuth as n, login as o, getClientId as r, authHeaders as t };
