import { r as getStoredMember } from "./_ssr/auth-CNvlfVI4.mjs";
import { n as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { Q as Building2, Z as Calendar, a as UserPlus, it as ArrowUpRight, q as ChevronRight, r as Users, st as Activity, x as MessageSquare } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.index-DK6yBAHq.js
var import_jsx_runtime = require_jsx_runtime();
var hero_splash_default = "/assets/hero-splash-Cqbv36Y-.jpg";
var quickActions = [
	{
		to: "/accounts",
		label: "Directory",
		icon: Users
	},
	{
		to: "/loans",
		label: "Connections",
		icon: UserPlus
	},
	{
		to: "/groups",
		label: "Chapters",
		icon: Building2
	},
	{
		to: "/statements",
		label: "Activity",
		icon: Activity
	}
];
var upcomingEvents = [
	{
		title: "Class of 2008 · 20-year reunion planning call",
		when: "Thu 12 Nov · 7:00 pm EAT"
	},
	{
		title: "OSS Nairobi chapter dinner",
		when: "Sat 21 Nov · Muthaiga Country Club"
	},
	{
		title: "Mentorship drive · Form 4 leavers",
		when: "Sat 05 Dec · Starehe Boys' Centre"
	}
];
var recentActivity = [
	{
		who: "Kevin Mwangi (Griffin, '08)",
		what: "sent you a connection request",
		when: "12 min ago",
		tone: "primary"
	},
	{
		who: "Class of 2010",
		what: "posted a chapter announcement",
		when: "1 h ago",
		tone: "muted"
	},
	{
		who: "Prof. Wanjiku (Faculty)",
		what: "commented on your post",
		when: "3 h ago",
		tone: "muted"
	},
	{
		who: "Brian Otieno (Livingstone, '11)",
		what: "endorsed you for mentorship",
		when: "Yesterday",
		tone: "muted"
	},
	{
		who: "OSS Secretariat",
		what: "shared the November newsletter",
		when: "2 d ago",
		tone: "muted"
	}
];
function Home() {
	const storedMember = getStoredMember();
	const greeting = (() => {
		const h = (/* @__PURE__ */ new Date()).getHours();
		if (h < 12) return "Good morning";
		if (h < 17) return "Good afternoon";
		return "Good evening";
	})();
	const firstName = storedMember?.firstName || storedMember?.displayName?.split(" ")?.[0] || "Old Starehian";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block h-[3px] w-6 rounded-full bg-primary" }), greeting]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "display mt-2 text-4xl font-semibold tracking-tight md:text-5xl",
					children: [firstName, "."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold text-foreground",
						children: "Nec aspera terrent."
					}), " Difficulties be damned — welcome back to the brotherhood."]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.section, {
				initial: {
					opacity: 0,
					y: 10
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: {
					duration: .5,
					ease: [
						.22,
						1,
						.36,
						1
					]
				},
				className: "relative overflow-hidden rounded-3xl border border-white/10 p-8 text-white shadow-[0_40px_80px_-40px_oklch(0.15_0.06_265/0.8)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.img, {
						"aria-hidden": true,
						src: hero_splash_default,
						alt: "",
						initial: {
							scale: 1.1,
							opacity: 0
						},
						animate: {
							scale: 1,
							opacity: 1
						},
						transition: {
							duration: 1.4,
							ease: [
								.22,
								1,
								.36,
								1
							]
						},
						className: "pointer-events-none absolute inset-0 h-full w-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						"aria-hidden": true,
						className: "pointer-events-none absolute inset-0",
						style: { background: "linear-gradient(135deg, rgba(8,8,20,0.55) 0%, rgba(8,8,20,0.15) 45%, rgba(8,8,20,0.75) 100%)" }
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "starehe-stripe absolute inset-x-0 top-0 z-10 h-[3px]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-bold uppercase tracking-[0.28em] text-white/75",
									children: "Your Starehe network"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "glass-panel rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-white/85",
									children: "Griffin · '08"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "glass-panel mt-6 flex items-end gap-6 rounded-2xl p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "num display text-6xl font-black tracking-tight text-white md:text-7xl",
									children: "184"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 text-xs font-medium text-white/70",
									children: storedMember?.officeName ?? "Class of 2008 · Griffin House"
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-1 flex-1 border-l border-white/20 pl-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[10px] font-bold uppercase tracking-[0.22em] text-white/60",
											children: "This week"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-1 text-2xl font-black text-white",
											children: "+3"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-white/60",
											children: "new connections"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/accounts",
									className: "inline-flex items-center gap-1.5 rounded-full bg-white text-slate-900 px-4 py-2 text-xs font-bold uppercase tracking-wider hover:bg-white/90",
									children: ["Open directory ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-3.5" })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/groups",
									className: "glass-panel inline-flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold uppercase tracking-wider text-white hover:bg-white/15",
									children: "Find your chapter"
								})]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
				children: quickActions.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						y: 8
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .35,
						delay: .05 * i,
						ease: [
							.22,
							1,
							.36,
							1
						]
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: a.to,
						className: "group flex h-full flex-col items-start gap-3 rounded-2xl border border-border/60 bg-card p-4 transition-all hover:-translate-y-0.5 hover:border-primary/30 hover:shadow-[0_18px_40px_-24px_oklch(0.52_0.20_25/0.35)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-10 place-items-center rounded-xl bg-primary/10 text-primary ring-1 ring-primary/15 transition-transform group-hover:scale-105",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(a.icon, {
								className: "size-5",
								strokeWidth: 1.75
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold leading-tight text-foreground",
							children: a.label
						})]
					})
				}, a.to))
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/loans",
				className: "block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.section, {
					initial: {
						opacity: 0,
						y: 8
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .4,
						delay: .15
					},
					className: "card-elev flex items-center justify-between gap-4 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "label-eyebrow",
								children: "Pending connection"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "display mt-1 text-xl font-semibold",
								children: "Kevin Mwangi"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 truncate text-xs text-muted-foreground",
								children: "Griffin House · Class of 2008 · wants to connect"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 shrink-0 place-items-center rounded-full bg-muted text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Upcoming"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/groups",
					className: "text-xs font-medium text-primary",
					children: "All chapters"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-elev divide-y divide-border/60 overflow-hidden p-0",
				children: upcomingEvents.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 shrink-0 place-items-center rounded-full bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-sm font-medium text-foreground",
							children: e.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground",
							children: e.when
						})]
					})]
				}, e.title))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Recent activity"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/statements",
					className: "text-xs font-medium text-primary",
					children: "See all"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-elev divide-y divide-border/60 overflow-hidden p-0",
				children: recentActivity.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `grid size-10 shrink-0 place-items-center rounded-full ${r.tone === "primary" ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageSquare, { className: "size-4" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "truncate text-sm font-medium text-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: r.who
								}),
								" ",
								r.what
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground",
							children: r.when
						})]
					})]
				}, i))
			})] })
		]
	});
}
//#endregion
export { Home as component };
