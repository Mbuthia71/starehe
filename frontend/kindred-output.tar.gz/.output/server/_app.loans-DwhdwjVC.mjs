import { i as getStoredMember } from "./_ssr/auth-DetQxYHL.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { w as Banknote, x as ChevronRight, y as CirclePlus } from "./_libs/lucide-react.mjs";
import { n as formatDate, t as KES } from "./_ssr/format-R9Jywg6X.mjs";
import { a as getSelfLoans, c as stkPush } from "./_ssr/selfApi-DGdOs9vm.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { t as EmptyState } from "./_ssr/EmptyState-DoXKeFW-.mjs";
import { t as StatusPill } from "./_ssr/StatusPill-DMgQUAW4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.loans-DwhdwjVC.js
var import_jsx_runtime = require_jsx_runtime();
function ProgressRing({ value }) {
	const r = 36;
	const c = 2 * Math.PI * r;
	const offset = c - value / 100 * c;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 88 88",
		className: "size-20 -rotate-90",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "44",
			cy: "44",
			r,
			fill: "none",
			stroke: "oklch(1 0 0 / 0.15)",
			strokeWidth: "6"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.circle, {
			cx: "44",
			cy: "44",
			r,
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "6",
			strokeLinecap: "round",
			strokeDasharray: c,
			initial: { strokeDashoffset: c },
			animate: { strokeDashoffset: offset },
			transition: {
				duration: .9,
				ease: [
					.22,
					1,
					.36,
					1
				]
			}
		})]
	});
}
function Loans() {
	const qc = useQueryClient();
	const member = getStoredMember();
	const { data: loans = [], isLoading } = useQuery({
		queryKey: ["selfLoans"],
		queryFn: getSelfLoans
	});
	const activeLoan = loans.find((l) => l.stage === "Active" || l.stage === "Arrears" || l.stage === "Disbursed");
	const pastLoans = loans.filter((l) => l.stage === "Closed" || l.stage === "Applied" || l.stage === "Approved");
	const repay = useMutation({
		mutationFn: (loan) => stkPush(member?.displayName || "", loan.nextPaymentAmount, loan.accountNo),
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["selfLoans"] });
			toast.success("M-Pesa STK push sent — check your phone");
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow",
				children: "My loans"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-1 text-3xl font-semibold tracking-tight",
				children: "Borrow with confidence."
			})] }),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm text-muted-foreground py-6",
				children: "Loading loans…"
			}) : activeLoan ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.section, {
				initial: {
					opacity: 0,
					y: 10
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { duration: .5 },
				className: "card-anchor relative overflow-hidden p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-semibold uppercase tracking-[0.22em] text-anchor-foreground/55",
								children: activeLoan.product
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "num display mt-3 text-3xl font-semibold tracking-tight",
								children: KES(activeLoan.outstanding)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-xs text-anchor-foreground/60",
								children: ["outstanding of ", KES(activeLoan.principal)]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-anchor-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressRing, { value: activeLoan.paid / activeLoan.principal * 100 })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid grid-cols-2 gap-4 border-t border-white/10 pt-5 text-anchor-foreground/80",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] uppercase tracking-widest text-anchor-foreground/50",
							children: "Next payment"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "num mt-1 text-lg font-semibold",
							children: KES(activeLoan.nextPaymentAmount)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] uppercase tracking-widest text-anchor-foreground/50",
							children: "Due"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "num mt-1 text-lg font-semibold",
							children: formatDate(activeLoan.nextPaymentDate)
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => repay.mutate(activeLoan),
						disabled: repay.isPending,
						className: "mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-warning px-5 py-3.5 text-sm font-semibold text-warning-foreground shadow-lg shadow-warning/20 active:scale-[0.98] disabled:opacity-50",
						children: repay.isPending ? "Sending STK push…" : `Repay ${KES(activeLoan.nextPaymentAmount)}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-center text-[11px] text-anchor-foreground/50",
						children: "You'll get an M-Pesa STK push to confirm."
					})
				]
			}) : !isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: Banknote,
				title: "No active loans",
				description: "When you take a loan, you'll see balance, due date and a repay button right here."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/loans/apply",
				className: "flex items-center justify-between rounded-2xl border border-dashed border-primary/30 bg-primary/5 px-5 py-4 text-primary active:bg-primary/10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlus, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-semibold",
						children: "Apply for a new loan"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
			}),
			pastLoans.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow mb-3",
				children: "Other loans"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: pastLoans.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-elev p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-semibold",
							children: l.product
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "num mt-0.5 text-xs text-muted-foreground",
							children: [
								KES(l.principal),
								" · ",
								l.termMonths,
								" mo"
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: l.stage })]
					}), l.disbursedOn && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 text-xs text-muted-foreground",
						children: ["Disbursed ", formatDate(l.disbursedOn)]
					})]
				}, l.id))
			})] })
		]
	});
}
//#endregion
export { Loans as component };
