import { o as __toESM } from "./_runtime.mjs";
import { i as getStoredMember } from "./_ssr/auth-BuJnZt4q.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react, t as useMutation } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { a as Smartphone, b as Check, w as ArrowLeft } from "./_libs/lucide-react.mjs";
import { t as KES } from "./_ssr/format-R9Jywg6X.mjs";
import { n as getSelfAccounts, s as withdrawViaMpesa } from "./_ssr/selfApi-BPocgXm-.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.withdraw-DX-Y4C5h.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Withdraw() {
	const member = getStoredMember();
	const { data: accounts = [] } = useQuery({
		queryKey: ["selfAccounts"],
		queryFn: getSelfAccounts
	});
	const savings = accounts.filter((a) => a.type === "Savings" || a.type === "Junior Savings");
	const [stage, setStage] = (0, import_react.useState)("form");
	const [amount, setAmount] = (0, import_react.useState)(2e3);
	const [accountId, setAccountId] = (0, import_react.useState)("");
	const [txRef, setTxRef] = (0, import_react.useState)("");
	const selectedAccount = savings.find((a) => a.id === accountId) || savings[0];
	const withdraw = useMutation({
		mutationFn: () => withdrawViaMpesa(selectedAccount?.id || "", amount, member?.displayName || ""),
		onSuccess: (data) => {
			setTxRef(data.transaction_id || data.ConversationID || "MPE" + Math.random().toString(36).slice(2, 8).toUpperCase());
			setStage("success");
		},
		onError: (e) => toast.error(e.message)
	});
	if (stage === "success") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			scale: .96
		},
		animate: {
			opacity: 1,
			scale: 1
		},
		transition: {
			duration: .45,
			ease: [
				.22,
				1,
				.36,
				1
			]
		},
		className: "card-elev flex flex-col items-center p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: { scale: 0 },
				animate: { scale: 1 },
				transition: {
					delay: .1,
					type: "spring",
					stiffness: 240,
					damping: 14
				},
				className: "grid size-16 place-items-center rounded-full bg-success-soft text-success",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-7" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display mt-5 text-2xl font-semibold tracking-tight",
				children: "Withdrawal initiated"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "num display mt-3 text-3xl font-semibold",
				children: KES(amount)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "M-Pesa payout in progress"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 w-full rounded-2xl bg-muted/60 px-4 py-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Reference"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "num mt-1 text-sm font-medium",
					children: txRef
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-6 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground",
				children: "Done"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "grid size-9 place-items-center rounded-full bg-muted active:scale-95",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Withdraw"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-2xl font-semibold tracking-tight",
					children: "To M-Pesa"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev p-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "label-eyebrow",
						children: "Amount"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "num display mt-3 text-5xl font-semibold tracking-tight",
						children: KES(amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 100,
						max: Math.max(100, myAccounts.find((a) => a.id === accountId)?.available ?? 100),
						step: 100,
						value: amount,
						onChange: (e) => setAmount(Number(e.target.value)),
						className: "mt-6 w-full accent-[color:var(--primary)]"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev divide-y divide-border/60 p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-wider text-muted-foreground",
						children: "From"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: accountId,
						onChange: (e) => setAccountId(e.target.value),
						className: "mt-1 w-full bg-transparent text-sm font-medium focus:outline-none",
						children: savings.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: a.id,
							children: [
								a.type,
								" · ",
								a.accountNo,
								" · ",
								KES(a.available),
								" available"
							]
						}, a.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] uppercase tracking-wider text-muted-foreground",
						children: "To"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-sm font-medium",
						children: member?.displayName || "Registered number"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-4 text-muted-foreground" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => withdraw.mutate(),
				disabled: withdraw.isPending || !selectedAccount,
				className: "w-full rounded-full bg-primary px-5 py-4 text-sm font-semibold text-primary-foreground active:scale-[0.98] disabled:opacity-50",
				children: withdraw.isPending ? "Processing…" : `Send ${KES(amount)} to M-Pesa`
			})
		]
	});
}
//#endregion
export { Withdraw as component };
