import { o as __toESM } from "./_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { S as Check, r as Users, t as X } from "./_libs/lucide-react.mjs";
import { n as formatDate, t as KES } from "./_ssr/format-R9Jywg6X.mjs";
import { r as guarantorRequests } from "./_ssr/api-D5WHFWw8.mjs";
import { t as EmptyState } from "./_ssr/EmptyState-DoXKeFW-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.guarantors-CB6uR8cd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Guarantors() {
	const [requests, setRequests] = (0, import_react.useState)(guarantorRequests);
	const pending = requests.filter((r) => r.status === "Pending");
	const decide = (id, status) => {
		setRequests((rs) => rs.map((r) => r.id === id ? {
			...r,
			status
		} : r));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow",
				children: "Guarantor inbox"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-1 text-3xl font-semibold tracking-tight",
				children: "Pledge requests."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Other members have asked you to guarantee their loans."
			})
		] }), pending.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			icon: Users,
			title: "All clear",
			description: "No pending pledge requests right now."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: pending.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-semibold",
							children: r.fromMemberName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground",
							children: r.fromMemberNo
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-muted-foreground",
							children: formatDate(r.requestedAt)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-3 rounded-2xl bg-muted/60 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground",
								children: "Loan"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "num mt-1 text-sm font-semibold",
								children: KES(r.loanAmount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted-foreground",
								children: r.loanProduct
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] uppercase tracking-wider text-muted-foreground",
								children: "You pledge"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "num mt-1 text-sm font-semibold",
								children: KES(r.pledgeAmount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] text-muted-foreground",
								children: [r.termMonths, " months"]
							})
						] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => decide(r.id, "Declined"),
							className: "flex-1 rounded-full bg-muted px-4 py-3 text-sm font-semibold text-foreground active:scale-[0.98]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mr-1 inline size-3.5" }), " Decline"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => decide(r.id, "Accepted"),
							className: "flex-1 rounded-full bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground active:scale-[0.98]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mr-1 inline size-3.5" }), " Accept"]
						})]
					})
				]
			}, r.id))
		})]
	});
}
//#endregion
export { Guarantors as component };
