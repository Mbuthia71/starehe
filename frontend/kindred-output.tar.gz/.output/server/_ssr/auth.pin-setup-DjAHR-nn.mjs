import { o as __toESM } from "../_runtime.mjs";
import { t as siohioma_logo_default } from "./siohioma-logo-DkFN5Et8.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { p as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.pin-setup-DjAHR-nn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PinSetup() {
	const navigate = useNavigate();
	const [pin, setPin] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const match = pin.length === 4 && pin === confirm;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-screen w-full max-w-[480px] flex-col bg-background px-6 pb-10 pt-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: siohioma_logo_default,
				alt: "Siohioma",
				className: "h-10 w-auto self-start"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-4xl font-semibold tracking-tight",
					children: "Set your PIN."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Choose a 4-digit PIN. You'll use it to confirm money movements."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					inputMode: "numeric",
					maxLength: 4,
					value: pin,
					onChange: (e) => setPin(e.target.value.replace(/\D/g, "")),
					placeholder: "New PIN",
					className: "num w-full rounded-2xl border border-border bg-card px-4 py-5 text-center text-3xl tracking-[0.8em] focus:outline-none focus:ring-2 focus:ring-ring/40"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "password",
					inputMode: "numeric",
					maxLength: 4,
					value: confirm,
					onChange: (e) => setConfirm(e.target.value.replace(/\D/g, "")),
					placeholder: "Confirm PIN",
					className: "num w-full rounded-2xl border border-border bg-card px-4 py-5 text-center text-3xl tracking-[0.8em] focus:outline-none focus:ring-2 focus:ring-ring/40"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: !match,
				onClick: () => navigate({ to: "/" }),
				className: "mt-8 w-full rounded-full bg-primary px-5 py-4 text-sm font-semibold text-primary-foreground active:scale-[0.98] disabled:opacity-40",
				children: "Save PIN"
			})
		]
	});
}
//#endregion
export { PinSetup as component };
