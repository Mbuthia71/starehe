import { o as __toESM } from "./_runtime.mjs";
import { i as getStoredMember } from "./_ssr/auth-BuJnZt4q.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react, t as useMutation } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { b as Check, w as ArrowLeft } from "./_libs/lucide-react.mjs";
import { t as KES } from "./_ssr/format-R9Jywg6X.mjs";
import { r as getSelfLoanProducts, t as applySelfLoan } from "./_ssr/selfApi-BPocgXm-.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.loans.apply-DvogCh1y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ApplyLoan() {
	const member = getStoredMember();
	const { data: loanProducts = [] } = useQuery({
		queryKey: ["selfLoanProducts"],
		queryFn: getSelfLoanProducts
	});
	const [step, setStep] = (0, import_react.useState)("product");
	const [productId, setProductId] = (0, import_react.useState)(null);
	const [amount, setAmount] = (0, import_react.useState)(5e4);
	const [term, setTerm] = (0, import_react.useState)(12);
	const [guarantors, setGuarantors] = (0, import_react.useState)([]);
	const [guarantorInput, setGuarantorInput] = (0, import_react.useState)("");
	const product = (0, import_react.useMemo)(() => loanProducts.find((p) => p.id === productId), [productId, loanProducts]);
	const steps = [
		"product",
		"amount",
		"term",
		"guarantors",
		"review"
	];
	const idx = steps.indexOf(step);
	const submit = useMutation({
		mutationFn: () => applySelfLoan(productId, amount, term, product?.rate || 1),
		onSuccess: () => setStep("submitted"),
		onError: (e) => toast.error(e.message)
	});
	const next = () => {
		const ni = idx + 1;
		if (ni < steps.length) setStep(steps[ni]);
		else submit.mutate();
	};
	const back = () => {
		if (idx > 0) setStep(steps[idx - 1]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3",
				children: [step !== "submitted" && step !== "product" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: back,
					className: "grid size-9 place-items-center rounded-full bg-muted text-foreground active:scale-95",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/loans",
					className: "grid size-9 place-items-center rounded-full bg-muted text-foreground active:scale-95",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Apply for a loan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-2xl font-semibold tracking-tight",
					children: step === "submitted" ? "Submitted" : `Step ${idx + 1} of ${steps.length}`
				})] })]
			}),
			step !== "submitted" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1.5",
				children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-1 flex-1 rounded-full transition-colors ${i <= idx ? "bg-primary" : "bg-border"}` }, s))
			}),
			step === "product" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "space-y-3",
				children: loanProducts.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						setProductId(p.id);
						setAmount(p.minAmount);
						setTerm(p.minTermMonths);
						next();
					},
					className: "card-elev w-full p-5 text-left active:scale-[0.99]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-semibold",
								children: p.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs font-medium text-primary",
								children: [p.rate, "% p.a."]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-xs text-muted-foreground",
							children: p.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 text-[11px] text-muted-foreground",
							children: p.eligibility
						})
					]
				}, p.id))
			}),
			step === "amount" && product && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "card-elev p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "label-eyebrow",
						children: "How much?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "num display mt-3 text-4xl font-semibold tracking-tight",
						children: KES(amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: product.minAmount,
						max: product.maxAmount,
						step: 1e3,
						value: amount,
						onChange: (e) => setAmount(Number(e.target.value)),
						className: "mt-6 w-full accent-[color:var(--primary)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex justify-between text-[11px] text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: KES(product.minAmount, { compact: true }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: KES(product.maxAmount, { compact: true }) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: next,
						className: "mt-6 w-full rounded-full bg-primary px-5 py-3.5 text-sm font-semibold text-primary-foreground active:scale-[0.98]",
						children: "Continue"
					})
				]
			}),
			step === "term" && product && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "card-elev p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "label-eyebrow",
						children: "Pay back over"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "num display mt-3 text-4xl font-semibold tracking-tight",
						children: [
							term,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xl text-muted-foreground",
								children: "months"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: product.minTermMonths,
						max: product.maxTermMonths,
						step: 1,
						value: term,
						onChange: (e) => setTerm(Number(e.target.value)),
						className: "mt-6 w-full accent-[color:var(--primary)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 rounded-2xl bg-muted/60 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-wider text-muted-foreground",
							children: "Estimated monthly payment"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "num mt-1 text-xl font-semibold",
							children: KES(Math.round(amount * (1 + product.rate / 100 * (term / 12)) / term))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: next,
						className: "mt-6 w-full rounded-full bg-primary px-5 py-3.5 text-sm font-semibold text-primary-foreground active:scale-[0.98]",
						children: "Continue"
					})
				]
			}),
			step === "guarantors" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-elev p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "label-eyebrow",
							children: "Add guarantors"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: guarantorInput,
								onChange: (e) => setGuarantorInput(e.target.value),
								placeholder: "Member number (e.g. TJS-00187)",
								className: "flex-1 rounded-full border border-border bg-background px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring/40"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									if (guarantorInput.trim()) {
										setGuarantors((g) => [...g, guarantorInput.trim()]);
										setGuarantorInput("");
									}
								},
								className: "rounded-full bg-primary px-4 text-sm font-semibold text-primary-foreground",
								children: "Add"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-2",
							children: [guarantors.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "No guarantors added yet."
							}), guarantors.map((g, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between rounded-xl bg-muted/60 px-3 py-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: g }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setGuarantors((gs) => gs.filter((_, j) => j !== i)),
									className: "text-xs text-danger",
									children: "Remove"
								})]
							}, i))]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: next,
					className: "w-full rounded-full bg-primary px-5 py-3.5 text-sm font-semibold text-primary-foreground active:scale-[0.98]",
					children: "Continue"
				})]
			}),
			step === "review" && product && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "card-elev p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "label-eyebrow",
						children: "Review"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 space-y-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Product",
								value: product.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Amount",
								value: KES(amount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Term",
								value: `${term} months`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Rate",
								value: `${product.rate}% p.a.`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Guarantors",
								value: guarantors.length ? guarantors.join(", ") : "None"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Disburse to",
								value: member?.displayName || "Registered account"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => submit.mutate(),
						disabled: submit.isPending,
						className: "mt-6 w-full rounded-full bg-primary px-5 py-3.5 text-sm font-semibold text-primary-foreground active:scale-[0.98] disabled:opacity-50",
						children: submit.isPending ? "Submitting…" : "Submit application"
					})
				]
			}),
			step === "submitted" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					scale: .96
				},
				animate: {
					opacity: 1,
					scale: 1
				},
				transition: {
					duration: .45,
					ease: [
						.22,
						1,
						.36,
						1
					]
				},
				className: "card-elev flex flex-col items-center p-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						initial: { scale: 0 },
						animate: { scale: 1 },
						transition: {
							delay: .1,
							type: "spring",
							stiffness: 240,
							damping: 14
						},
						className: "grid size-16 place-items-center rounded-full bg-success-soft text-success",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-7" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mt-5 text-2xl font-semibold tracking-tight",
						children: "Application received"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xs text-sm text-muted-foreground",
						children: "We'll review and message you within 1 business day. You can track progress under My loans."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/loans",
						className: "mt-6 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground",
						children: "Back to my loans"
					})
				]
			})
		]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-baseline justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "num text-right text-sm font-medium",
			children: value
		})]
	});
}
//#endregion
export { ApplyLoan as component };
