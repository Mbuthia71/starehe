import { o as __toESM } from "./_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { B as DollarSign, C as MapPin, E as Lock, F as Globe, H as CircleX, U as CircleCheckBig, V as Clock, f as Star, k as Instagram, ot as ArrowLeft, p as Shield, v as Phone, z as Facebook } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { t as Route } from "./_app.business._id-B_-AGwou.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.business._id-BqNBrJJC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var mockBusiness = {
	id: "1",
	businessName: "TechVentures Kenya",
	phoneNumber: "+254 712 345 678",
	location: "Nairobi",
	website: "https://techventures.co.ke",
	description: "Leading software development company specializing in custom solutions for businesses across East Africa. We offer web development, mobile apps, cloud services, and IT consulting.",
	instagramHandle: "@techventureske",
	facebookHandle: "TechVentures Kenya",
	logoUrl: null,
	isVerified: true,
	isFeatured: true,
	status: "active",
	createdAt: "3 months ago",
	userId: "user-123"
};
var mockEscrowTransactions = [{
	id: "1",
	businessId: "1",
	buyerId: "user-456",
	sellerId: "user-123",
	amount: 5e4,
	description: "Website development project",
	status: "funded",
	releaseConditions: "Project completion and delivery",
	fundedAt: "2024-07-15T10:00:00Z",
	completedAt: null,
	cancelledAt: null,
	createdAt: "2024-07-15T09:00:00Z"
}, {
	id: "2",
	businessId: "1",
	buyerId: "user-789",
	sellerId: "user-123",
	amount: 25e3,
	description: "Mobile app consultation",
	status: "completed",
	releaseConditions: "Consultation session delivered",
	fundedAt: "2024-07-10T14:00:00Z",
	completedAt: "2024-07-12T16:00:00Z",
	cancelledAt: null,
	createdAt: "2024-07-10T13:00:00Z"
}];
function BusinessDetail() {
	const { id } = Route.useParams();
	const [showEscrowModal, setShowEscrowModal] = (0, import_react.useState)(false);
	const [escrowAmount, setEscrowAmount] = (0, import_react.useState)("");
	const [escrowDescription, setEscrowDescription] = (0, import_react.useState)("");
	const [escrowConditions, setEscrowConditions] = (0, import_react.useState)("");
	const handleCreateEscrow = (e) => {
		e.preventDefault();
		console.log("Creating escrow:", {
			amount: escrowAmount,
			description: escrowDescription,
			conditions: escrowConditions
		});
		setShowEscrowModal(false);
	};
	const getStatusIcon = (status) => {
		switch (status) {
			case "funded": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "size-4 text-amber-500" });
			case "completed": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "size-4 text-green-500" });
			case "cancelled": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "size-4 text-red-500" });
			default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 text-muted-foreground" });
		}
	};
	const getStatusColor = (status) => {
		switch (status) {
			case "funded": return "bg-amber-500/10 text-amber-500";
			case "completed": return "bg-green-500/10 text-green-500";
			case "cancelled": return "bg-red-500/10 text-red-500";
			default: return "bg-muted text-muted-foreground";
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/business",
				className: "inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Back to Directory"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				className: "card-elev p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "display text-3xl font-semibold tracking-tight md:text-4xl",
										children: mockBusiness.businessName
									}),
									mockBusiness.isVerified && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "size-5 fill-amber-500 text-amber-500" }),
									mockBusiness.isFeatured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-amber-500",
										children: "Featured"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4" }), mockBusiness.location]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-4" }), mockBusiness.phoneNumber]
									}),
									mockBusiness.website && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
										href: mockBusiness.website,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "flex items-center gap-2 hover:text-primary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate max-w-[200px]",
											children: mockBusiness.website
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-sm text-muted-foreground",
								children: mockBusiness.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap items-center gap-3 text-sm text-muted-foreground",
								children: [mockBusiness.instagramHandle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, { className: "size-4" }), mockBusiness.instagramHandle]
								}), mockBusiness.facebookHandle && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Facebook, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate max-w-[150px]",
										children: mockBusiness.facebookHandle
									})]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setShowEscrowModal(true),
						className: "inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-4" }), "Create Escrow Transaction"]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { delay: .1 },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-semibold",
						children: "Escrow Transactions"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), "Secure payments with escrow protection"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [mockEscrowTransactions.map((transaction, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						initial: {
							opacity: 0,
							y: 8
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: { delay: .15 + .05 * i },
						className: "card-elev p-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-start justify-between gap-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-semibold text-foreground",
											children: transaction.description
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${getStatusColor(transaction.status)}`,
											children: transaction.status
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-4 text-sm text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "size-3.5" }),
												"KES ",
												transaction.amount.toLocaleString()
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1",
											children: [
												getStatusIcon(transaction.status),
												transaction.status === "funded" && "Awaiting completion",
												transaction.status === "completed" && "Completed and released",
												transaction.status === "cancelled" && "Transaction cancelled"
											]
										})]
									}),
									transaction.releaseConditions && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 text-xs text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-medium",
												children: "Release conditions:"
											}),
											" ",
											transaction.releaseConditions
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 text-xs text-muted-foreground",
										children: ["Created: ", new Date(transaction.createdAt).toLocaleDateString()]
									})
								]
							})
						})
					}, transaction.id)), mockEscrowTransactions.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card-elev p-8 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "mx-auto size-12 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "No escrow transactions yet"
						})]
					})]
				})]
			}),
			showEscrowModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						scale: .95
					},
					animate: {
						opacity: 1,
						scale: 1
					},
					className: "card-elev w-full max-w-lg p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "size-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-semibold",
								children: "Create Escrow Transaction"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-4 rounded-lg bg-primary/5 p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "How escrow works:" }), " Your payment is held securely until the seller delivers the agreed-upon work or product. Once you're satisfied, the funds are released."]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: handleCreateEscrow,
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1 block text-sm font-medium",
									children: "Amount (KES)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									value: escrowAmount,
									onChange: (e) => setEscrowAmount(e.target.value),
									className: "w-full rounded-xl border border-border/60 bg-card px-4 py-2.5 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary",
									placeholder: "e.g., 50000",
									required: true
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1 block text-sm font-medium",
									children: "Description"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "text",
									value: escrowDescription,
									onChange: (e) => setEscrowDescription(e.target.value),
									className: "w-full rounded-xl border border-border/60 bg-card px-4 py-2.5 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary",
									placeholder: "e.g., Website development project",
									required: true
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "mb-1 block text-sm font-medium",
									children: "Release Conditions"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 3,
									value: escrowConditions,
									onChange: (e) => setEscrowConditions(e.target.value),
									className: "w-full rounded-xl border border-border/60 bg-card px-4 py-2.5 text-sm focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary",
									placeholder: "e.g., Project completion and delivery of source code",
									required: true
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 rounded-lg bg-amber-500/10 p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 text-amber-500" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: "Your payment will be held securely until the release conditions are met."
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowEscrowModal(false),
										className: "flex-1 rounded-xl border border-border/60 bg-card px-4 py-2.5 text-sm font-medium hover:bg-muted",
										children: "Cancel"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "flex-1 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90",
										children: "Create Transaction"
									})]
								})
							]
						})
					]
				})
			})
		]
	});
}
//#endregion
export { BusinessDetail as component };
