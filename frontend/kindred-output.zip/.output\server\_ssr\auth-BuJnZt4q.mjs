//#region node_modules/.nitro/vite/services/ssr/assets/auth-BuJnZt4q.js
var TOKEN_KEY = "siohioma_token";
var CLIENT_KEY = "siohioma_clientId";
var MEMBER_KEY = "siohioma_member";
function getToken() {
	if (typeof localStorage === "undefined") return null;
	return localStorage.getItem(TOKEN_KEY);
}
function getClientId() {
	if (typeof localStorage === "undefined") return null;
	const v = localStorage.getItem(CLIENT_KEY);
	return v ? Number(v) : null;
}
function getStoredMember() {
	if (typeof localStorage === "undefined") return null;
	const v = localStorage.getItem(MEMBER_KEY);
	return v ? JSON.parse(v) : null;
}
function isAuthenticated() {
	return !!getToken() && !!getClientId();
}
function saveAuth(state) {
	localStorage.setItem(TOKEN_KEY, state.token);
	localStorage.setItem(CLIENT_KEY, String(state.clientId));
	localStorage.setItem(MEMBER_KEY, JSON.stringify(state.member));
}
function clearAuth() {
	localStorage.removeItem(TOKEN_KEY);
	localStorage.removeItem(CLIENT_KEY);
	localStorage.removeItem(MEMBER_KEY);
}
var BASE = "/fineract-provider/api/v1";
var TENANT = "default";
async function login(username, password) {
	const credentials = btoa(`${username}:${password}`);
	const res = await fetch(`${BASE}/self/authentication`, {
		method: "POST",
		headers: {
			Authorization: `Basic ${credentials}`,
			"Fineract-Platform-TenantId": TENANT,
			"Content-Type": "application/json"
		},
		body: JSON.stringify({})
	});
	if (!res.ok) {
		const err = await res.json().catch(() => ({}));
		throw new Error(err.defaultUserMessage || "Invalid credentials");
	}
	const data = await res.json();
	const token = data.base64EncodedAuthenticationKey;
	const clientId = data.clients?.[0] ?? data.clientId ?? data.userId;
	if (!token) throw new Error("Authentication failed — no token returned");
	const member = {
		id: clientId,
		displayName: data.username || username,
		firstName: data.username?.split(".")?.[0] ?? username
	};
	const state = {
		token,
		clientId: Number(clientId),
		member
	};
	saveAuth(state);
	return state;
}
function authHeaders() {
	return {
		Authorization: `Basic ${getToken()}`,
		"Fineract-Platform-TenantId": TENANT,
		"Content-Type": "application/json"
	};
}
//#endregion
export { isAuthenticated as a, getStoredMember as i, clearAuth as n, login as o, getClientId as r, authHeaders as t };
