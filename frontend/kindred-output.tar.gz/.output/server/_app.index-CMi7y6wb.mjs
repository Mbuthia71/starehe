import { o as __toESM } from "./_runtime.mjs";
import { i as getStoredMember } from "./_ssr/auth-DetQxYHL.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { D as ArrowDownLeft, T as ArrowUpRight, h as EyeOff, m as Eye, p as FileText, s as Send, w as Banknote, x as ChevronRight, y as CirclePlus } from "./_libs/lucide-react.mjs";
import { n as formatDate, t as KES } from "./_ssr/format-R9Jywg6X.mjs";
import { a as getSelfLoans, o as getSelfTransactions, r as getSelfAccounts } from "./_ssr/selfApi-DGdOs9vm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.index-CMi7y6wb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var quickActions = [
	{
		to: "/transfer",
		label: "Send to member",
		icon: Send
	},
	{
		to: "/withdraw",
		label: "Send to M-Pesa",
		icon: ArrowUpRight
	},
	{
		to: "/loans",
		label: "Pay loan",
		icon: Banknote
	},
	{
		to: "/statements",
		label: "Statement",
		icon: FileText
	},
	{
		to: "/loans/apply",
		label: "Apply loan",
		icon: CirclePlus
	}
];
function Home() {
	const [hidden, setHidden] = (0, import_react.useState)(false);
	const storedMember = getStoredMember();
	const greeting = (() => {
		const h = (/* @__PURE__ */ new Date()).getHours();
		if (h < 12) return "Good morning";
		if (h < 17) return "Good afternoon";
		return "Good evening";
	})();
	const { data: accounts = [] } = useQuery({
		queryKey: ["selfAccounts"],
		queryFn: getSelfAccounts
	});
	const { data: loans = [] } = useQuery({
		queryKey: ["selfLoans"],
		queryFn: getSelfLoans
	});
	const primaryAccount = accounts.find((a) => a.type === "Savings") || accounts[0];
	const activeLoan = loans.find((l) => l.stage === "Active" || l.stage === "Arrears" || l.stage === "Disbursed");
	const { data: allTransactions = [] } = useQuery({
		queryKey: ["selfTransactions", primaryAccount?.id],
		queryFn: () => getSelfTransactions(primaryAccount.id),
		enabled: !!primaryAccount?.id
	});
	const recentTransactions = allTransactions.slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[11px] font-semibold uppercase tracking-[0.22em] text-muted-foreground",
				children: greeting
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "display mt-1 text-3xl font-semibold tracking-tight",
				children: [storedMember?.firstName || storedMember?.displayName?.split(".")?.[0] || "Member", "."]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.section, {
				initial: {
					opacity: 0,
					y: 10
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: {
					duration: .5,
					ease: [
						.22,
						1,
						.36,
						1
					]
				},
				className: "card-anchor relative overflow-hidden p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-16 -top-16 size-48 rounded-full bg-white/[0.04] blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-20 -left-10 size-56 rounded-full bg-white/[0.03] blur-3xl" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-semibold uppercase tracking-[0.22em] text-anchor-foreground/55",
									children: "Savings balance"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setHidden((h) => !h),
									className: "grid size-8 place-items-center rounded-full bg-white/5 text-anchor-foreground/70 active:scale-95",
									"aria-label": hidden ? "Show balance" : "Hide balance",
									children: hidden ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "num display mt-5 text-5xl font-semibold tracking-tight",
								children: hidden ? "•••••••" : KES(primaryAccount?.balance ?? 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center justify-between text-xs text-anchor-foreground/55",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: primaryAccount?.accountNo ?? "—" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Available ", hidden ? "•••" : KES(primaryAccount?.available ?? 0)] })]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2",
				children: quickActions.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						opacity: 0,
						y: 8
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .35,
						delay: .05 * i,
						ease: [
							.22,
							1,
							.36,
							1
						]
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: a.to,
						className: "flex h-full flex-col items-center gap-2 rounded-2xl bg-card px-2 py-3 text-center transition-colors active:bg-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-11 place-items-center rounded-full bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(a.icon, {
								className: "size-5",
								strokeWidth: 1.75
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[11px] font-medium leading-tight text-foreground",
							children: a.label
						})]
					})
				}, a.to))
			}) }),
			activeLoan && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/loans",
				className: "block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.section, {
					initial: {
						opacity: 0,
						y: 8
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .4,
						delay: .15
					},
					className: "card-elev flex items-center justify-between gap-4 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "label-eyebrow",
								children: "Next loan payment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "num display mt-1 text-2xl font-semibold",
								children: KES(activeLoan.nextPaymentAmount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 text-xs text-muted-foreground",
								children: [
									"Due ",
									formatDate(activeLoan.nextPaymentDate),
									" · ",
									activeLoan.product
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-10 shrink-0 place-items-center rounded-full bg-muted text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Recent activity"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/statements",
					className: "text-xs font-medium text-primary",
					children: "See all"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-elev divide-y divide-border/60 overflow-hidden p-0",
				children: recentTransactions.map((t) => {
					const credit = t.amount > 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `grid size-10 shrink-0 place-items-center rounded-full ${credit ? "bg-success-soft text-success" : "bg-muted text-muted-foreground"}`,
								children: credit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownLeft, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-medium text-foreground",
									children: t.description
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground",
									children: formatDate(t.date, true)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `num shrink-0 text-sm font-semibold ${credit ? "text-success" : "text-foreground"} ${t.status === "Failed" ? "line-through opacity-50" : ""}`,
								children: [credit ? "+" : "−", KES(Math.abs(t.amount))]
							})
						]
					}, t.id);
				})
			})] })
		]
	});
}
//#endregion
export { Home as component };
