import { a as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { g as Download, p as FileText } from "./_libs/lucide-react.mjs";
import { t as availableStatements } from "./_ssr/api-D5WHFWw8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.statements-CBtDDnv5.js
var import_jsx_runtime = require_jsx_runtime();
function Statements() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow",
				children: "Statements"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-1 text-3xl font-semibold tracking-tight",
				children: "Your monthly record."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "label-eyebrow",
						children: "Custom range"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "mt-4 w-full rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground active:scale-[0.98]",
						children: "Generate PDF"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow mb-3",
				children: "Recent months"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-elev divide-y divide-border/60 p-0",
				children: availableStatements.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "flex w-full items-center gap-3 px-4 py-4 text-left active:bg-muted/50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-10 place-items-center rounded-full bg-muted text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: s.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] text-muted-foreground",
								children: "All accounts · PDF"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4 text-primary" })
					]
				}, s.id))
			})] })
		]
	});
}
//#endregion
export { Statements as component };
