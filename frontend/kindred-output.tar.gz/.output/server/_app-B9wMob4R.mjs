import { o as __toESM } from "./_runtime.mjs";
import { a as isAuthenticated, i as getStoredMember, n as clearAuth } from "./_ssr/auth-DetQxYHL.mjs";
import { t as siohioma_logo_default } from "./_ssr/siohioma-logo-DkFN5Et8.mjs";
import { a as require_jsx_runtime, o as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link, i as useRouterState, p as useNavigate, s as Outlet } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as AnimatePresence, t as motion } from "./_libs/framer-motion.mjs";
import { C as Bell, _ as CreditCard, d as House, i as User, n as Wallet, w as Banknote } from "./_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-B9wMob4R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Enterprise loading state — Siohioma mark with a measured breath animation
* and a thin progress hairline. Designed to feel calm, not busy.
*/
function SiohiomaLoader({ variant = "fullscreen", label = "Preparing your workspace", surface = "cream" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: variant === "fullscreen" ? `fixed inset-0 z-[100] grid place-items-center ${surface === "cream" ? "bg-background" : surface === "anchor" ? "bg-anchor" : "bg-transparent"}` : "grid w-full place-items-center py-16",
		role: "status",
		"aria-live": "polite",
		"aria-busy": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative grid place-items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						"aria-hidden": true,
						className: "absolute size-48 rounded-full",
						style: { background: "radial-gradient(closest-side, oklch(0.265 0.045 162 / 0.10), transparent 70%)" },
						animate: {
							scale: [
								1,
								1.18,
								1
							],
							opacity: [
								.5,
								.9,
								.5
							]
						},
						transition: {
							duration: 2.8,
							repeat: Infinity,
							ease: "easeInOut"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						"aria-hidden": true,
						className: "absolute size-32 rounded-full",
						style: { background: "radial-gradient(closest-side, oklch(0.62 0.18 55 / 0.18), transparent 70%)" },
						animate: {
							scale: [
								1,
								1.08,
								1
							],
							opacity: [
								.4,
								.8,
								.4
							]
						},
						transition: {
							duration: 2.8,
							repeat: Infinity,
							ease: "easeInOut",
							delay: .4
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.img, {
						src: siohioma_logo_default,
						alt: "Siohioma",
						className: "relative h-20 w-auto select-none",
						draggable: false,
						initial: {
							opacity: 0,
							y: 8,
							scale: .96
						},
						animate: {
							opacity: 1,
							y: 0,
							scale: 1
						},
						transition: {
							duration: .9,
							ease: [
								.22,
								1,
								.36,
								1
							]
						}
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative h-px w-56 overflow-hidden bg-foreground/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						className: "absolute inset-y-0 w-1/3 bg-foreground/70",
						initial: { x: "-100%" },
						animate: { x: "320%" },
						transition: {
							duration: 1.8,
							repeat: Infinity,
							ease: [
								.65,
								0,
								.35,
								1
							]
						}
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] font-semibold uppercase tracking-[0.32em] text-muted-foreground",
					children: label
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Loading"
		})]
	});
}
var tabs = [
	{
		to: "/",
		label: "Home",
		icon: House,
		exact: true
	},
	{
		to: "/accounts",
		label: "Accounts",
		icon: Wallet
	},
	{
		to: "/loans",
		label: "Loans",
		icon: Banknote
	},
	{
		to: "/cards",
		label: "Card",
		icon: CreditCard
	},
	{
		to: "/profile",
		label: "Profile",
		icon: User
	}
];
function BottomTab({ to, label, icon: Icon, exact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		activeOptions: { exact: !!exact },
		className: "group relative flex min-h-[56px] flex-1 flex-col items-center justify-center gap-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground transition-colors data-[status=active]:text-primary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-5",
				strokeWidth: 1.75
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-px h-[2px] w-8 rounded-full bg-transparent transition-colors group-data-[status=active]:bg-primary" })
		]
	});
}
function SideTab({ to, label, icon: Icon, exact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		activeOptions: { exact: !!exact },
		className: "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground data-[status=active]:bg-primary/10 data-[status=active]:text-primary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4",
			strokeWidth: 1.75
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function AppLayout() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const navigate = useNavigate();
	const [booting, setBooting] = (0, import_react.useState)(true);
	const member = getStoredMember();
	(0, import_react.useEffect)(() => {
		if (!isAuthenticated()) {
			navigate({ to: "/auth/login" });
			return;
		}
		const t = setTimeout(() => setBooting(false), 1400);
		return () => clearTimeout(t);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen w-full bg-background lg:grid lg:grid-cols-[260px_minmax(0,1fr)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: booting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: { opacity: 1 },
				exit: { opacity: 0 },
				transition: {
					duration: .5,
					ease: [
						.22,
						1,
						.36,
						1
					]
				},
				className: "fixed inset-0 z-[100]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiohiomaLoader, {
					surface: "cream",
					label: `Karibu, ${member?.firstName || member?.displayName || "Member"}`
				})
			}, "boot") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden lg:flex lg:sticky lg:top-0 lg:h-screen lg:flex-col lg:border-r lg:border-border/60 lg:bg-card/40 lg:px-5 lg:py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "flex items-center gap-2 px-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: siohioma_logo_default,
							alt: "Siohioma",
							className: "h-8 w-auto"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-10 flex flex-col gap-1",
						children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideTab, { ...t }, t.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto rounded-2xl border border-border/60 bg-background/60 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "Signed in as"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 truncate text-sm font-semibold",
								children: member?.displayName || "Member"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									clearAuth();
									navigate({ to: "/auth/login" });
								},
								className: "mt-2 text-xs text-danger hover:underline",
								children: "Sign out"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-[480px] flex-col lg:max-w-[720px] lg:px-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border/60 bg-background/90 px-5 py-3 backdrop-blur lg:border-b-0 lg:bg-transparent lg:px-2 lg:py-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "flex items-center gap-2 lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: siohioma_logo_default,
								alt: "Siohioma",
								className: "h-7 w-auto"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden lg:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
								children: "Member portal"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							"aria-label": "Notifications",
							className: "relative grid size-10 place-items-center rounded-full border border-border bg-card text-muted-foreground active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-2.5 top-2.5 size-1.5 rounded-full bg-warning" })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 px-5 pb-28 pt-5 lg:px-2 lg:pb-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
						mode: "wait",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							initial: {
								opacity: 0,
								y: 8
							},
							animate: {
								opacity: 1,
								y: 0
							},
							exit: { opacity: 0 },
							transition: {
								duration: .28,
								ease: [
									.22,
									1,
									.36,
									1
								]
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
						}, pathname)
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Primary",
				className: "fixed bottom-0 left-1/2 z-30 w-full max-w-[480px] -translate-x-1/2 border-t border-border/60 bg-background/95 px-2 pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1 backdrop-blur lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-stretch",
					children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomTab, { ...t }, t.to))
				})
			})
		]
	});
}
//#endregion
export { AppLayout as component };
