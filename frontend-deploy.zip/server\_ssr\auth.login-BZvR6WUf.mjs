import { o as __toESM } from "../_runtime.mjs";
import { c as signup, s as login } from "./auth-CN9qeBFn.mjs";
import { t as siohioma_logo_default } from "./siohioma-logo-DkFN5Et8.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { p as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { W as CircleAlert, at as ArrowRight } from "../_libs/lucide-react.mjs";
import { n as AnimatePresence, t as motion } from "../_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.login-BZvR6WUf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var videostarehe_default = "/assets/videostarehe-D6tB2Q8h.mp4";
function Login() {
	const navigate = useNavigate();
	const [identifier, setIdentifier] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [greeting, setGreeting] = (0, import_react.useState)("");
	const [mode, setMode] = (0, import_react.useState)("login");
	(0, import_react.useEffect)(() => {
		const hour = (/* @__PURE__ */ new Date()).getHours();
		if (hour >= 6 && hour < 12) setGreeting("Good morning");
		else if (hour >= 12 && hour < 15) setGreeting("Good afternoon");
		else if (hour >= 15 && hour < 18) setGreeting("Good evening");
		else setGreeting("Good evening");
	}, []);
	const isEmail = identifier.includes("@");
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!identifier.trim() || !password.trim()) return;
		setLoading(true);
		setError("");
		try {
			if (mode === "signup") {
				if (!fullName.trim()) {
					setError("Full name is required for signup");
					setLoading(false);
					return;
				}
				await signup(identifier.trim(), password.trim(), fullName.trim());
			} else await login(identifier.trim(), password.trim());
			navigate({ to: "/" });
		} catch (err) {
			setError(err.message || "Authentication failed");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen w-full overflow-hidden bg-black",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.video, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				transition: { duration: 1.4 },
				autoPlay: true,
				muted: true,
				loop: true,
				playsInline: true,
				className: "absolute inset-0 h-full w-full object-cover",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("source", {
					src: videostarehe_default,
					type: "video/mp4"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "absolute inset-0",
				style: { background: "linear-gradient(180deg, rgba(0,0,0,0.55) 0%, rgba(0,0,0,0.15) 35%, rgba(0,0,0,0.15) 55%, rgba(0,0,0,0.75) 100%)" }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "starehe-stripe absolute inset-x-0 top-0 z-30 h-[3px]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-20 flex items-center justify-between px-6 pt-6 md:px-12 md:pt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: siohioma_logo_default,
						alt: "Old Starehian Society",
						className: "h-11 w-auto brightness-0 invert drop-shadow-lg"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hidden sm:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] font-bold uppercase tracking-[0.3em] text-white/80",
							children: "Old Starehian Society"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[9px] font-medium uppercase tracking-[0.28em] text-white/50",
							children: "United to serve · Est. 1959"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center gap-2 md:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-[2px] w-6 bg-white/70" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-bold uppercase tracking-[0.3em] text-white/70",
						children: "Nec aspera terrent"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto grid min-h-[calc(100vh-88px)] w-full max-w-[1400px] grid-cols-1 items-center gap-10 px-6 pb-12 pt-8 md:px-12 lg:grid-cols-[1.15fr_minmax(0,440px)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 24
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .9,
						ease: [
							.22,
							1,
							.36,
							1
						]
					},
					className: "max-w-[720px] text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/5 px-3 py-1 backdrop-blur-md",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 rounded-full bg-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[10px] font-bold uppercase tracking-[0.28em] text-white/80",
								children: "Alumni Network"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "display font-black leading-[0.92] tracking-tight text-white text-[clamp(3rem,9vw,7.5rem)]",
							children: [
								greeting || "Welcome",
								",",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "italic text-white/85",
									children: "Old Starehian."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-[46ch] text-base font-light leading-relaxed text-white/75 md:text-lg",
							children: "Ten thousand brothers. Every class. Every corner of the world. Reconnect with the men who wore the maroon and gold before you — and the ones who will after."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 hidden gap-8 md:flex",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									n: "10,000+",
									label: "Alumni worldwide"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									n: "65+",
									label: "Years of tradition"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									n: "120+",
									label: "Chapters & class years"
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.form, {
					initial: {
						opacity: 0,
						y: 24,
						scale: .98
					},
					animate: {
						opacity: 1,
						y: 0,
						scale: 1
					},
					transition: {
						delay: .25,
						duration: .75,
						ease: [
							.22,
							1,
							.36,
							1
						]
					},
					onSubmit: handleSubmit,
					className: "glass-panel relative w-full max-w-[440px] justify-self-end rounded-3xl p-7 md:p-9",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-4 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setMode("login"),
										className: `flex-1 rounded-lg px-4 py-2 text-[11px] font-bold uppercase tracking-wider transition-all ${mode === "login" ? "bg-white text-black" : "bg-white/10 text-white/60 hover:bg-white/20"}`,
										children: "Sign In"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setMode("signup"),
										className: `flex-1 rounded-lg px-4 py-2 text-[11px] font-bold uppercase tracking-wider transition-all ${mode === "signup" ? "bg-white text-black" : "bg-white/10 text-white/60 hover:bg-white/20"}`,
										children: "Sign Up"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "display text-3xl font-black text-white",
									children: mode === "login" ? "Enter the brotherhood." : "Join the brotherhood."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[13px] text-white/60",
									children: mode === "login" ? "Use the phone number or email your class rep registered." : "Enter your phone number to create an account."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mb-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-white/60",
										children: isEmail ? "Email (admin)" : "Phone number"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: identifier,
										onChange: (e) => setIdentifier(e.target.value),
										autoComplete: "username",
										placeholder: isEmail ? "admin@oldstarehian.org" : "+254712345678",
										className: "w-full rounded-xl border border-white/15 bg-white/[0.08] px-4 py-3.5 text-[15px] font-medium text-white placeholder:text-white/35 focus:border-white/40 focus:bg-white/[0.12] focus:outline-none focus:ring-2 focus:ring-white/20"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-1.5 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-bold uppercase tracking-[0.2em] text-white/60",
											children: "Password"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
											href: "#",
											className: "text-[10px] font-semibold text-white/70 hover:text-white",
											children: "Forgot?"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "password",
										value: password,
										onChange: (e) => setPassword(e.target.value),
										autoComplete: mode === "signup" ? "new-password" : "current-password",
										placeholder: "••••••••",
										className: "w-full rounded-xl border border-white/15 bg-white/[0.08] px-4 py-3.5 text-[15px] font-medium text-white placeholder:text-white/35 focus:border-white/40 focus:bg-white/[0.12] focus:outline-none focus:ring-2 focus:ring-white/20"
									})]
								}),
								mode === "signup" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mb-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-white/60",
										children: "Full name"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: fullName,
										onChange: (e) => setFullName(e.target.value),
										placeholder: "John Doe",
										autoComplete: "name",
										className: "w-full rounded-xl border border-white/15 bg-white/[0.08] px-4 py-3.5 text-[15px] font-medium text-white placeholder:text-white/35 focus:border-white/40 focus:bg-white/[0.12] focus:outline-none focus:ring-2 focus:ring-white/20"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							initial: {
								opacity: 0,
								y: -6
							},
							animate: {
								opacity: 1,
								y: 0
							},
							exit: {
								opacity: 0,
								y: -6
							},
							className: "mt-4 flex items-center gap-2 rounded-xl border border-red-400/30 bg-red-500/15 px-3.5 py-3 text-[13px] font-medium text-red-100 backdrop-blur",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0" }), error]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.button, {
							type: "submit",
							disabled: loading || !identifier || !password,
							whileTap: { scale: .985 },
							className: "mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-white px-6 py-3.5 text-sm font-bold uppercase tracking-[0.14em] text-slate-900 shadow-xl transition-all hover:bg-white/90 disabled:cursor-not-allowed disabled:opacity-50",
							children: [loading ? "Processing…" : mode === "login" ? "Sign In" : "Sign Up", !loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-5 text-center text-[11px] text-white/50",
							children: [
								"New Old Starehian? ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "font-semibold text-white/80 underline-offset-2 hover:underline",
									href: "#",
									children: "Request an invite"
								}),
								" from your class rep."
							]
						})
					]
				})]
			})
		]
	});
}
function Stat({ n, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-l border-white/20 pl-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "display text-2xl font-black text-white",
			children: n
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-0.5 text-[10px] font-semibold uppercase tracking-[0.22em] text-white/50",
			children: label
		})]
	});
}
//#endregion
export { Login as component };
