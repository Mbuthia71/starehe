//#region node_modules/.nitro/vite/services/ssr/assets/api-C2hpwF9g.js
var API_CONFIG = {
	baseUrl: "/api",
	timeout: parseInt("30000"),
	headers: (token) => ({
		"Content-Type": "application/json",
		...token ? { Authorization: `Bearer ${token}` } : {}
	})
};
//#endregion
export { API_CONFIG as t };
