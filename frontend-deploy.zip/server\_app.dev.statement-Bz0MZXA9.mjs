import { n as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { n as Wrench } from "./_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.dev.statement-Bz0MZXA9.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "p-8 text-sm text-muted-foreground",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, { className: "mb-3 size-5" }), "Report templates are being rebuilt for the Old Starehian Society."]
});
//#endregion
export { SplitComponent as component };
