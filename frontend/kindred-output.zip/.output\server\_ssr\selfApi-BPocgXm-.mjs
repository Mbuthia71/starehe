import { r as getClientId, t as authHeaders } from "./auth-BuJnZt4q.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/selfApi-BPocgXm-.js
var BASE = "/fineract-provider/api/v1";
var MPESA_BASE = "http://204.168.218.166:8081";
async function selfGet(path) {
	const res = await fetch(`${BASE}${path}`, { headers: authHeaders() });
	if (res.status === 401) throw new Error("Session expired. Please log in again.");
	if (!res.ok) {
		const err = await res.json().catch(() => ({}));
		throw new Error(err.defaultUserMessage || `Error ${res.status}`);
	}
	return res.json();
}
async function selfPost(path, body) {
	const res = await fetch(`${BASE}${path}`, {
		method: "POST",
		headers: authHeaders(),
		body: JSON.stringify(body)
	});
	if (res.status === 401) throw new Error("Session expired. Please log in again.");
	const data = await res.json();
	if (!res.ok) throw new Error(data.defaultUserMessage || data.errors?.[0]?.defaultUserMessage || `Error ${res.status}`);
	return data;
}
async function getSelfAccounts() {
	const clientId = getClientId();
	if (!clientId) throw new Error("Not authenticated");
	const data = await selfGet(`/self/savingsaccounts?clientId=${clientId}`);
	return (data.pageItems ?? data.savingsAccounts ?? []).map((a) => ({
		id: String(a.id),
		accountNo: a.accountNo,
		type: mapSavingsType(a.depositType?.value || a.savingsProductName || "Savings"),
		balance: a.summary?.accountBalance ?? 0,
		available: a.summary?.availableBalance ?? a.summary?.accountBalance ?? 0,
		interestRate: a.nominalAnnualInterestRate ?? 0,
		status: a.status?.value === "Active" ? "Active" : a.status?.value === "Dormant" ? "Dormant" : "Closed",
		openedOn: a.timeline?.activatedOnDate?.join?.("-") || ""
	}));
}
function mapSavingsType(raw) {
	if (/share/i.test(raw)) return "Share Capital";
	if (/fixed|deposit/i.test(raw)) return "Fixed Deposit";
	if (/junior|target/i.test(raw)) return "Junior Savings";
	return "Savings";
}
async function getSelfTransactions(accountId) {
	const data = await selfGet(`/self/savingsaccounts/${accountId}/transactions`);
	return (data.pageItems ?? data.transactions ?? []).map((t) => ({
		id: String(t.id),
		date: t.date?.join?.("-") || "",
		description: t.transactionType?.value || "Transaction",
		accountId,
		category: mapTxCategory(t.transactionType?.value || ""),
		amount: t.transactionType?.withdrawal ? -t.amount : t.amount,
		status: t.reversed ? "Failed" : "Completed",
		reference: t.paymentDetailData?.receiptNumber || void 0
	}));
}
function mapTxCategory(type) {
	if (/deposit/i.test(type)) return "Deposit";
	if (/withdrawal/i.test(type)) return "Withdrawal";
	if (/repayment/i.test(type)) return "Loan Repayment";
	if (/disburse/i.test(type)) return "Disbursement";
	if (/interest/i.test(type)) return "Interest";
	return "Deposit";
}
async function getSelfLoans() {
	const clientId = getClientId();
	if (!clientId) throw new Error("Not authenticated");
	const data = await selfGet(`/self/loans?clientId=${clientId}`);
	return (data.pageItems ?? data.loans ?? []).map((l) => ({
		id: String(l.id),
		accountNo: l.accountNo,
		product: l.loanProductName,
		principal: l.principal ?? l.approvedPrincipal ?? 0,
		outstanding: l.summary?.principalOutstanding ?? l.principal ?? 0,
		paid: l.summary?.principalPaid ?? 0,
		nextPaymentAmount: l.repaymentSchedule?.periods?.find((p) => !p.complete)?.totalDueForPeriod ?? 0,
		nextPaymentDate: l.repaymentSchedule?.periods?.find((p) => !p.complete)?.dueDate?.join?.("-") ?? "",
		stage: mapLoanStage(l.status?.value || ""),
		daysOverdue: l.summary?.overdueSinceDate ? Math.floor((Date.now() - new Date(l.summary.overdueSinceDate.join("-")).getTime()) / 864e5) : 0,
		guarantors: [],
		disbursedOn: l.timeline?.actualDisbursementDate?.join?.("-"),
		termMonths: l.numberOfRepayments ?? 12,
		monthsPaid: l.summary?.numberOfRepaymentsMade ?? 0,
		rate: l.annualInterestRate ?? l.interestRatePerPeriod ?? 0
	}));
}
function mapLoanStage(status) {
	if (/pending/i.test(status)) return "Applied";
	if (/approved/i.test(status)) return "Approved";
	if (/active/i.test(status)) return "Active";
	if (/arrears/i.test(status) || /overdue/i.test(status)) return "Arrears";
	if (/close/i.test(status)) return "Closed";
	if (/disburse/i.test(status)) return "Disbursed";
	return "Applied";
}
async function getSelfLoanProducts() {
	const data = await selfGet("/self/loanproducts");
	return (Array.isArray(data) ? data : []).map((p) => ({
		id: String(p.id),
		name: p.name,
		rate: p.annualInterestRate ?? p.interestRatePerPeriod ?? 0,
		minTermMonths: p.minNumberOfRepayments ?? 1,
		maxTermMonths: p.maxNumberOfRepayments ?? 60,
		minAmount: p.minPrincipal ?? 5e3,
		maxAmount: p.maxPrincipal ?? 3e6,
		eligibility: p.description || "Contact branch for eligibility details",
		description: p.description || p.name
	}));
}
async function applySelfLoan(productId, amount, termMonths, interestRate) {
	const clientId = getClientId();
	if (!clientId) throw new Error("Not authenticated");
	const today = (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric"
	}).replace(/\//g, " ");
	return selfPost("/self/loans", {
		clientId,
		productId: Number(productId),
		principal: amount,
		loanTermFrequency: termMonths,
		loanTermFrequencyType: 2,
		numberOfRepayments: termMonths,
		repaymentEvery: 1,
		repaymentFrequencyType: 2,
		interestRatePerPeriod: interestRate,
		amortizationType: 1,
		interestType: 0,
		interestCalculationPeriodType: 1,
		transactionProcessingStrategyCode: "mifos-standard-strategy",
		submittedOnDate: today,
		expectedDisbursementDate: today,
		dateFormat: "dd MM yyyy",
		locale: "en"
	});
}
async function stkPush(msisdn, amount, accountRef) {
	const res = await fetch(`${MPESA_BASE}/stk/push`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			msisdn: msisdn.replace(/\s/g, ""),
			amount,
			account_ref: accountRef,
			description: `Payment for ${accountRef}`
		})
	});
	if (!res.ok) throw new Error("M-Pesa STK push failed");
	return res.json();
}
async function withdrawViaMpesa(accountId, amount, msisdn) {
	const clientId = getClientId();
	const res = await fetch(`${MPESA_BASE}/b2c/withdraw`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			account_id: accountId,
			client_id: String(clientId),
			msisdn: msisdn.replace(/\s/g, ""),
			amount
		})
	});
	const data = await res.json().catch(() => ({}));
	if (!res.ok) throw new Error(data.message || "Withdrawal failed");
	return data;
}
//#endregion
export { getSelfTransactions as a, getSelfLoans as i, getSelfAccounts as n, stkPush as o, getSelfLoanProducts as r, withdrawViaMpesa as s, applySelfLoan as t };
