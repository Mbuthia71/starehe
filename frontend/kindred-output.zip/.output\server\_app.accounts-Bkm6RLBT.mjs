import { o as __toESM } from "./_runtime.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { n as formatDate, t as KES } from "./_ssr/format-R9Jywg6X.mjs";
import { a as getSelfTransactions, n as getSelfAccounts } from "./_ssr/selfApi-BPocgXm-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.accounts-Bkm6RLBT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var accentByType = {
	Savings: "from-primary/90 to-primary",
	"Share Capital": "from-anchor to-anchor",
	"Fixed Deposit": "from-warning/80 to-warning",
	"Junior Savings": "from-success/80 to-success"
};
function Accounts() {
	const { data: accounts = [], isLoading } = useQuery({
		queryKey: ["selfAccounts"],
		queryFn: getSelfAccounts
	});
	const [selectedAccId, setSelectedAccId] = (0, import_react.useState)(null);
	const selectedAccount = accounts.find((a) => a.id === selectedAccId) || accounts[0];
	const { data: transactions = [], isLoading: txLoading } = useQuery({
		queryKey: ["selfTransactions", selectedAccount?.id],
		queryFn: () => getSelfTransactions(selectedAccount.id),
		enabled: !!selectedAccount?.id
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow",
				children: "My accounts"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-1 text-3xl font-semibold tracking-tight",
				children: "Everything you hold."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-5 overflow-x-auto px-5 pb-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex snap-x snap-mandatory gap-3",
					children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-muted-foreground py-4",
						children: "Loading accounts…"
					}) : accounts.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 8
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .4,
							delay: i * .06
						},
						onClick: () => setSelectedAccId(a.id),
						className: `relative w-[78%] shrink-0 snap-center overflow-hidden rounded-3xl bg-gradient-to-br cursor-pointer ${accentByType[a.type] ?? "from-primary to-primary"} p-5 text-primary-foreground shadow-[0_24px_48px_-24px_oklch(0.2_0.03_160_/_0.25)] ${selectedAccId === a.id || !selectedAccId && i === 0 ? "ring-2 ring-white/40" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-12 -top-12 size-40 rounded-full bg-white/10 blur-2xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-semibold uppercase tracking-[0.22em] text-primary-foreground/65",
									children: a.type
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "num display mt-6 text-3xl font-semibold tracking-tight",
									children: KES(a.balance)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex items-center justify-between text-[11px] text-primary-foreground/65",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a.accountNo }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a.interestRate > 0 ? `${a.interestRate}% p.a.` : a.status })]
								})
							]
						})]
					}, a.id))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "label-eyebrow mb-3",
				children: ["Transaction history ", selectedAccount ? `· ${selectedAccount.accountNo}` : ""]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-elev divide-y divide-border/60 overflow-hidden p-0",
				children: txLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-4 py-6 text-center text-sm text-muted-foreground",
					children: "Loading…"
				}) : transactions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-4 py-6 text-center text-sm text-muted-foreground",
					children: "No transactions yet."
				}) : transactions.map((t) => {
					const credit = t.amount > 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-4 py-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-medium",
									children: t.description
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] text-muted-foreground",
									children: [
										formatDate(t.date, true),
										" · ",
										t.category
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `num shrink-0 text-sm font-semibold ${credit ? "text-success" : "text-foreground"} ${t.status === "Failed" ? "line-through opacity-50" : ""}`,
								children: [credit ? "+" : "−", KES(Math.abs(t.amount))]
							})]
						})
					}, t.id);
				})
			})] })
		]
	});
}
//#endregion
export { Accounts as component };
