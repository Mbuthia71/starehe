//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DxMmre9F.js
var tsrStartManifest = () => ({
	routes: {
		__root__: {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/__root.tsx",
			children: [
				"/_app",
				"/auth/login",
				"/auth/otp",
				"/auth/pin-setup"
			],
			assets: void 0,
			preloads: [
				"/assets/index-CxUMcYUf.js",
				"/assets/jsx-runtime-DnlWeMvz.js",
				"/assets/react-dom-DriRPPLg.js"
			]
		},
		"/_app": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.tsx",
			children: [
				"/_app/accounts",
				"/_app/cards",
				"/_app/guarantors",
				"/_app/loans",
				"/_app/profile",
				"/_app/statements",
				"/_app/transfer",
				"/_app/withdraw",
				"/_app/"
			],
			assets: void 0,
			preloads: [
				"/assets/_app-7MEALYfx.js",
				"/assets/auth-BHDXz6-B.js",
				"/assets/createLucideIcon-CPOOcYn_.js",
				"/assets/banknote-BOMg5vhb.js",
				"/assets/credit-card-B77suztx.js",
				"/assets/user-Cf8iIhzP.js",
				"/assets/siohioma-logo-zm9kMDod.js"
			]
		},
		"/_app/accounts": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.accounts.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.accounts-3kBOjhkC.js",
				"/assets/selfApi-51VIF9_H.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/_app/cards": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.cards.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.cards-CIv-3U8R.js",
				"/assets/selfApi-51VIF9_H.js",
				"/assets/check-DisOH-Hr.js",
				"/assets/eye-CsqugZdO.js"
			]
		},
		"/_app/guarantors": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.guarantors.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.guarantors-C4CKQbz0.js",
				"/assets/check-DisOH-Hr.js",
				"/assets/users-B2L7i_p8.js",
				"/assets/EmptyState-CX6nppw4.js",
				"/assets/api-DIvt6uQQ.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/_app/loans": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.loans.tsx",
			children: ["/_app/loans/apply"],
			assets: void 0,
			preloads: [
				"/assets/_app.loans-BCJQdM22.js",
				"/assets/useMutation-LTEkrm95.js",
				"/assets/selfApi-51VIF9_H.js",
				"/assets/StatusPill-DnckxUbZ.js",
				"/assets/chevron-right-BaJECq_P.js",
				"/assets/circle-plus-C38gbffT.js",
				"/assets/EmptyState-CX6nppw4.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/_app/profile": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.profile.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.profile-BNEE4TXI.js",
				"/assets/StatusPill-DnckxUbZ.js",
				"/assets/chevron-right-BaJECq_P.js",
				"/assets/users-B2L7i_p8.js",
				"/assets/api-DIvt6uQQ.js"
			]
		},
		"/_app/statements": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.statements.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.statements-yzDYORZj.js",
				"/assets/file-text-DePsHLEC.js",
				"/assets/api-DIvt6uQQ.js"
			]
		},
		"/_app/transfer": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.transfer.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.transfer-aZ1OFfT8.js",
				"/assets/useMutation-LTEkrm95.js",
				"/assets/selfApi-51VIF9_H.js",
				"/assets/arrow-left-CD89c06s.js",
				"/assets/check-DisOH-Hr.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/_app/withdraw": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.withdraw.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.withdraw-C38ZefTV.js",
				"/assets/useMutation-LTEkrm95.js",
				"/assets/selfApi-51VIF9_H.js",
				"/assets/arrow-left-CD89c06s.js",
				"/assets/check-DisOH-Hr.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/auth/login": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/auth.login.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/auth.login-7R1FTRVf.js",
				"/assets/auth-BHDXz6-B.js",
				"/assets/createLucideIcon-CPOOcYn_.js",
				"/assets/siohioma-logo-zm9kMDod.js"
			]
		},
		"/auth/otp": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/auth.otp.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/auth.otp-BvKwIKah.js", "/assets/siohioma-logo-zm9kMDod.js"]
		},
		"/auth/pin-setup": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/auth.pin-setup.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/auth.pin-setup-UyNdE_Ql.js", "/assets/siohioma-logo-zm9kMDod.js"]
		},
		"/_app/": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.index.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.index-BfbpglPL.js",
				"/assets/selfApi-51VIF9_H.js",
				"/assets/chevron-right-BaJECq_P.js",
				"/assets/circle-plus-C38gbffT.js",
				"/assets/eye-CsqugZdO.js",
				"/assets/file-text-DePsHLEC.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/_app/loans/apply": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.loans.apply.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.loans.apply-BVL99uaZ.js",
				"/assets/arrow-left-CD89c06s.js",
				"/assets/check-DisOH-Hr.js"
			]
		}
	},
	clientEntry: "/assets/index-CxUMcYUf.js"
});
//#endregion
export { tsrStartManifest };
