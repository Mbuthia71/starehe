import { o as __toESM } from "./_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { c as Phone, f as Fingerprint, l as LogOut, o as ShieldCheck, r as Users, u as KeyRound, y as ChevronRight } from "./_libs/lucide-react.mjs";
import { n as currentMember } from "./_ssr/api-D5WHFWw8.mjs";
import { t as StatusPill } from "./_ssr/StatusPill-DMgQUAW4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.profile-DPRR8vlF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Profile() {
	const [biometric, setBiometric] = (0, import_react.useState)(currentMember.biometricEnabled);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-col items-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-20 place-items-center rounded-full bg-primary text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "display text-3xl font-semibold",
							children: [currentMember.firstName[0], currentMember.lastName[0]]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "display mt-4 text-2xl font-semibold tracking-tight",
						children: [
							currentMember.firstName,
							" ",
							currentMember.lastName
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "num mt-1 text-xs text-muted-foreground",
						children: currentMember.memberNo
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: currentMember.kycStatus })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-elev divide-y divide-border/60 p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						icon: Phone,
						label: "Registered phone",
						value: currentMember.phone
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						icon: ShieldCheck,
						label: "Branch",
						value: currentMember.branch
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						icon: Users,
						label: "Next of kin",
						value: currentMember.nextOfKin.name,
						sub: currentMember.nextOfKin.relation
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-elev divide-y divide-border/60 p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
						icon: Fingerprint,
						label: "Biometric login",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setBiometric((b) => !b),
							className: `relative h-6 w-11 rounded-full transition-colors ${biometric ? "bg-primary" : "bg-border"}`,
							"aria-pressed": biometric,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-5 rounded-full bg-card shadow transition-transform ${biometric ? "translate-x-5" : "translate-x-0.5"}` })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkRow, {
						icon: KeyRound,
						label: "Change PIN",
						to: "/auth/pin-setup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkRow, {
						icon: Users,
						label: "Guarantor inbox",
						to: "/guarantors"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/auth/login",
				className: "flex w-full items-center justify-center gap-2 rounded-full bg-danger-soft px-5 py-3.5 text-sm font-semibold text-danger active:scale-[0.98]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), "Sign out"]
			})
		]
	});
}
function Row({ icon: Icon, label, value, sub }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-9 place-items-center rounded-full bg-muted text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-medium",
					children: value
				})]
			}),
			sub && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted-foreground",
				children: sub
			})
		]
	});
}
function ActionRow({ icon: Icon, label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-9 place-items-center rounded-full bg-muted text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 text-sm font-medium",
				children: label
			}),
			children
		]
	});
}
function LinkRow({ icon: Icon, label, to }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "flex items-center gap-3 px-4 py-4 active:bg-muted/50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid size-9 place-items-center rounded-full bg-muted text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 text-sm font-medium",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-muted-foreground" })
		]
	});
}
//#endregion
export { Profile as component };
