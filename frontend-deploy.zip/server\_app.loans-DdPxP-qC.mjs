import { o as __toESM } from "./_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { J as Check, a as UserPlus, r as Users, t as X } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { t as EmptyState } from "./_ssr/EmptyState-DoXKeFW-.mjs";
import { t as StatusPill } from "./_ssr/StatusPill-DMgQUAW4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.loans-DdPxP-qC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var initial = [
	{
		id: "c1",
		name: "Kevin Mwangi",
		detail: "Griffin · Class of 2008 · Product Manager",
		status: "Pending",
		when: "12 min ago"
	},
	{
		id: "c2",
		name: "Sarah Njeri",
		detail: "Griffin · Class of 2012 · Journalist",
		status: "Pending",
		when: "2 h ago"
	},
	{
		id: "c3",
		name: "Brian Otieno",
		detail: "Livingstone · Class of 2011 · Senior Engineer",
		status: "Accepted",
		when: "Yesterday"
	},
	{
		id: "c4",
		name: "Peter Kimani",
		detail: "Livingstone · Class of 2009 · Data Scientist",
		status: "Accepted",
		when: "3 d ago"
	}
];
var suggestions = [
	{
		id: "s1",
		name: "Mary Wanjiku",
		detail: "Griffin · Class of 2015 · Lawyer",
		reason: "2 mutual connections"
	},
	{
		id: "s2",
		name: "David Ochieng",
		detail: "Livingstone · Class of 2007 · Architect",
		reason: "Same chapter · Nairobi"
	},
	{
		id: "s3",
		name: "Achieng Nyongo",
		detail: "Griffin · Class of 2013 · Doctor",
		reason: "5 mutual connections"
	}
];
function Connections() {
	const [requests, setRequests] = (0, import_react.useState)(initial);
	const pending = requests.filter((r) => r.status === "Pending");
	const accepted = requests.filter((r) => r.status === "Accepted");
	const decide = (id, status) => {
		setRequests((rs) => rs.map((r) => r.id === id ? {
			...r,
			status
		} : r));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Alumni connections"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-1 text-3xl font-semibold tracking-tight",
					children: "Your network."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Accept requests, discover fellow Old Starehians and grow your circle."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-baseline justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Pending requests"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [pending.length, " waiting"]
				})]
			}), pending.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-elev",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					icon: UserPlus,
					title: "No pending requests",
					description: "You're all caught up."
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: pending.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 6
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .3,
						delay: i * .05
					},
					className: "card-elev flex items-center gap-4 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-11 shrink-0 place-items-center rounded-full bg-primary/10 text-sm font-semibold text-primary",
							children: r.name.split(" ").map((p) => p[0]).slice(0, 2).join("")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-semibold text-foreground",
									children: r.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-[11px] text-muted-foreground",
									children: r.detail
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] text-muted-foreground",
									children: r.when
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => decide(r.id, "Accepted"),
								className: "inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1.5 text-[11px] font-medium text-primary-foreground hover:brightness-110",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }), " Accept"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => decide(r.id, "Declined"),
								className: "inline-flex items-center gap-1 rounded-full border border-border bg-card px-3 py-1.5 text-[11px] font-medium text-foreground hover:bg-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" }), " Decline"]
							})]
						})
					]
				}, r.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 flex items-baseline justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Recently connected"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-elev divide-y divide-border/60 overflow-hidden p-0",
				children: accepted.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-10 shrink-0 place-items-center rounded-full bg-muted text-sm font-semibold text-muted-foreground",
							children: r.name.split(" ").map((p) => p[0]).slice(0, 2).join("")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-medium text-foreground",
								children: r.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-[11px] text-muted-foreground",
								children: r.detail
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: r.status })
					]
				}, r.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 flex items-baseline justify-between",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Suggested Old Starehians"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: suggestions.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 6
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .3,
						delay: .1 + i * .05
					},
					className: "card-elev flex items-center gap-4 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-11 shrink-0 place-items-center rounded-full bg-primary/10 text-sm font-semibold text-primary",
							children: s.name.split(" ").map((p) => p[0]).slice(0, 2).join("")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-sm font-semibold text-foreground",
									children: s.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "truncate text-[11px] text-muted-foreground",
									children: s.detail
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-0.5 inline-flex items-center gap-1 text-[10px] text-primary",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3" }),
										" ",
										s.reason
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "inline-flex shrink-0 items-center gap-1 rounded-full border border-border bg-card px-3 py-1.5 text-[11px] font-medium text-foreground hover:bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3" }), " Connect"]
						})
					]
				}, s.id))
			})] })
		]
	});
}
//#endregion
export { Connections as component };
