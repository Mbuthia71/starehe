import { o as __toESM } from "./_runtime.mjs";
import { a as isAuthenticated, d as updateActivity, l as startSessionTimeoutCheck, n as detectDeviceSecurity, o as isTrustedDevice, r as getStoredMember, t as clearAuth, u as trustCurrentDevice } from "./_ssr/auth-CNvlfVI4.mjs";
import { t as siohioma_logo_default } from "./_ssr/siohioma-logo-DkFN5Et8.mjs";
import { n as require_jsx_runtime, r as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link, i as useRouterState, p as useNavigate, s as Outlet } from "./_libs/@tanstack/react-router+[...].mjs";
import { $ as Briefcase, G as ChevronsRight, K as ChevronsLeft, M as Heart, P as GraduationCap, Q as Building2, R as FileText, S as Menu, T as LogOut, b as Moon, d as Store, g as Search, i as User, j as House, l as Tag, r as Users, s as TriangleAlert, t as X, tt as Bell, u as Sun } from "./_libs/lucide-react.mjs";
import { n as AnimatePresence, t as motion } from "./_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-f0jYG2QJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Enterprise loading state — Siohioma mark with a measured breath animation
* and a thin progress hairline. Designed to feel calm, not busy.
*/
function SiohiomaLoader({ variant = "fullscreen", label = "Preparing your workspace", surface = "cream" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: variant === "fullscreen" ? `fixed inset-0 z-[100] grid place-items-center ${surface === "cream" ? "bg-background" : surface === "anchor" ? "bg-anchor" : "bg-transparent"}` : "grid w-full place-items-center py-16",
		role: "status",
		"aria-live": "polite",
		"aria-busy": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative grid place-items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						"aria-hidden": true,
						className: "absolute size-48 rounded-full",
						style: { background: "radial-gradient(closest-side, oklch(0.265 0.045 162 / 0.10), transparent 70%)" },
						animate: {
							scale: [
								1,
								1.18,
								1
							],
							opacity: [
								.5,
								.9,
								.5
							]
						},
						transition: {
							duration: 2.8,
							repeat: Infinity,
							ease: "easeInOut"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						"aria-hidden": true,
						className: "absolute size-32 rounded-full",
						style: { background: "radial-gradient(closest-side, oklch(0.62 0.18 55 / 0.18), transparent 70%)" },
						animate: {
							scale: [
								1,
								1.08,
								1
							],
							opacity: [
								.4,
								.8,
								.4
							]
						},
						transition: {
							duration: 2.8,
							repeat: Infinity,
							ease: "easeInOut",
							delay: .4
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.img, {
						src: siohioma_logo_default,
						alt: "Siohioma",
						className: "relative h-20 w-auto select-none",
						draggable: false,
						initial: {
							opacity: 0,
							y: 8,
							scale: .96
						},
						animate: {
							opacity: 1,
							y: 0,
							scale: 1
						},
						transition: {
							duration: .9,
							ease: [
								.22,
								1,
								.36,
								1
							]
						}
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative h-px w-56 overflow-hidden bg-foreground/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						className: "absolute inset-y-0 w-1/3 bg-foreground/70",
						initial: { x: "-100%" },
						animate: { x: "320%" },
						transition: {
							duration: 1.8,
							repeat: Infinity,
							ease: [
								.65,
								0,
								.35,
								1
							]
						}
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] font-semibold uppercase tracking-[0.32em] text-muted-foreground",
					children: label
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Loading"
		})]
	});
}
var tabs = [
	{
		to: "/",
		label: "Home",
		icon: House,
		exact: true
	},
	{
		to: "/accounts",
		label: "Directory",
		icon: Users
	},
	{
		to: "/jobs",
		label: "Jobs",
		icon: Briefcase
	},
	{
		to: "/tenders",
		label: "Tenders",
		icon: FileText
	},
	{
		to: "/class-groups",
		label: "Class Groups",
		icon: GraduationCap
	},
	{
		to: "/offers",
		label: "Offers",
		icon: Tag
	},
	{
		to: "/sponsorships",
		label: "Sponsorships",
		icon: Heart
	},
	{
		to: "/business",
		label: "Business",
		icon: Store
	},
	{
		to: "/groups",
		label: "Chapters",
		icon: Building2
	},
	{
		to: "/profile",
		label: "Profile",
		icon: User
	}
];
function NavItem({ to, label, icon: Icon, exact, compact, onNavigate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		activeOptions: { exact: !!exact },
		onClick: onNavigate,
		title: compact ? label : void 0,
		className: `group relative flex items-center gap-3 rounded-xl text-sm font-medium text-sidebar-foreground/70 transition-all hover:bg-sidebar-accent hover:text-sidebar-foreground data-[status=active]:bg-sidebar-accent data-[status=active]:text-sidebar-foreground ${compact ? "h-11 w-11 justify-center" : "px-3 py-2.5"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-0 top-1/2 h-0 w-[3px] -translate-y-1/2 rounded-r-full bg-sidebar-primary transition-all group-data-[status=active]:h-6" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-[18px] shrink-0",
				strokeWidth: 1.75
			}),
			!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				children: label
			})
		]
	});
}
function SidebarBody({ mode, onToggleMode, member, onSignOut, theme, onToggleTheme, onNavigate, showToggle = true }) {
	const compact = mode === "rail";
	const initials = (member?.displayName ?? "OS").split(" ").map((p) => p[0]).slice(0, 2).join("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-full flex-col bg-sidebar text-sidebar-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "starehe-stripe absolute inset-x-0 top-0 h-[3px] opacity-90" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `flex items-center gap-3 px-4 pb-4 pt-6 ${compact ? "justify-center px-2" : ""}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					onClick: onNavigate,
					className: "flex items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-9 shrink-0 place-items-center rounded-xl bg-white/10 ring-1 ring-white/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: siohioma_logo_default,
							alt: "OSS",
							className: "h-6 w-auto"
						})
					}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] font-semibold uppercase tracking-[0.2em] text-sidebar-foreground/50",
							children: "Old Starehian"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "display truncate text-sm font-semibold",
							children: "Society"
						})]
					})]
				}), showToggle && !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onToggleMode,
					"aria-label": "Collapse sidebar",
					className: "ml-auto grid size-7 place-items-center rounded-md text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsLeft, { className: "size-4" })
				})]
			}),
			!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-3 pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-sidebar-foreground/40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						placeholder: "Search alumni…",
						className: "h-9 w-full rounded-lg border border-white/10 bg-white/[0.04] pl-9 pr-3 text-xs text-sidebar-foreground placeholder:text-sidebar-foreground/40 focus:outline-none focus:ring-2 focus:ring-sidebar-primary/40"
					})]
				})
			}),
			!compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-4 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-[0.2em] text-sidebar-foreground/40",
				children: "Menu"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: `flex flex-col gap-1 ${compact ? "items-center px-2" : "px-2"}`,
				children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavItem, {
					...t,
					compact,
					onNavigate
				}, t.to))
			}),
			showToggle && compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onToggleMode,
				"aria-label": "Expand sidebar",
				className: "mx-auto mt-3 grid size-8 place-items-center rounded-md text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronsRight, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-auto flex flex-col gap-3 px-3 pb-4",
				children: [!compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center rounded-xl bg-white/[0.05] p-1 ring-1 ring-white/5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => theme !== "light" && onToggleTheme(),
						className: `flex flex-1 items-center justify-center gap-1.5 rounded-lg py-1.5 text-[11px] font-semibold transition-colors ${theme === "light" ? "bg-white/10 text-sidebar-foreground" : "text-sidebar-foreground/50"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-3.5" }), " Light"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => theme !== "dark" && onToggleTheme(),
						className: `flex flex-1 items-center justify-center gap-1.5 rounded-lg py-1.5 text-[11px] font-semibold transition-colors ${theme === "dark" ? "bg-white/10 text-sidebar-foreground" : "text-sidebar-foreground/50"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-3.5" }), " Dark"]
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onToggleTheme,
					"aria-label": "Toggle theme",
					className: "mx-auto grid size-9 place-items-center rounded-lg bg-white/[0.05] text-sidebar-foreground/70 ring-1 ring-white/5 hover:bg-white/10",
					children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `flex items-center gap-3 rounded-xl bg-white/[0.04] p-2 ring-1 ring-white/5 ${compact ? "justify-center p-2" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-9 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground text-[11px] font-semibold",
						children: initials
					}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-xs font-semibold",
							children: member?.displayName ?? "Old Starehian"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "truncate text-[10px] text-sidebar-foreground/50",
							children: member?.emailAddress ?? "OSS alumni"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onSignOut,
						"aria-label": "Sign out",
						className: "grid size-8 shrink-0 place-items-center rounded-md text-sidebar-foreground/50 hover:bg-white/10 hover:text-sidebar-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" })
					})] })]
				})]
			})
		]
	});
}
function AppLayout() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const navigate = useNavigate();
	const [booting, setBooting] = (0, import_react.useState)(true);
	const [showSecurityAlert, setShowSecurityAlert] = (0, import_react.useState)(false);
	const [securityMessage, setSecurityMessage] = (0, import_react.useState)("");
	const [member, setMember] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("full");
	const [drawerOpen, setDrawerOpen] = (0, import_react.useState)(false);
	const [theme, setTheme] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		const stored = typeof window !== "undefined" ? localStorage.getItem("oss.sidebar") : null;
		if (stored === "rail" || stored === "full") setMode(stored);
		const t = typeof window !== "undefined" ? localStorage.getItem("oss.theme") : null;
		if (t === "dark" || t === "light") {
			setTheme(t);
			document.documentElement.classList.toggle("dark", t === "dark");
		}
	}, []);
	const toggleMode = () => {
		const next = mode === "full" ? "rail" : "full";
		setMode(next);
		try {
			localStorage.setItem("oss.sidebar", next);
		} catch {}
	};
	const toggleTheme = () => {
		const next = theme === "dark" ? "light" : "dark";
		setTheme(next);
		document.documentElement.classList.toggle("dark", next === "dark");
		try {
			localStorage.setItem("oss.theme", next);
		} catch {}
	};
	const signOut = () => {
		clearAuth();
		navigate({ to: "/auth/login" });
	};
	(0, import_react.useEffect)(() => {
		setMember(getStoredMember());
		if (!isAuthenticated()) {
			navigate({ to: "/auth/login" });
			return;
		}
		const security = detectDeviceSecurity();
		if (security.isRooted || security.isJailbroken) {
			setSecurityMessage("Your device appears to be modified. For your security, please use a standard device.");
			setShowSecurityAlert(true);
		} else if (!isTrustedDevice()) {
			setSecurityMessage("New device detected. Trust this device to keep it signed in?");
			setShowSecurityAlert(true);
		}
		const timeoutInterval = startSessionTimeoutCheck(() => {
			clearAuth();
			navigate({ to: "/auth/login" });
		});
		const handleActivity = () => updateActivity();
		window.addEventListener("mousemove", handleActivity);
		window.addEventListener("keydown", handleActivity);
		window.addEventListener("touchstart", handleActivity);
		const t = setTimeout(() => setBooting(false), 1400);
		return () => {
			clearTimeout(t);
			clearInterval(timeoutInterval);
			window.removeEventListener("mousemove", handleActivity);
			window.removeEventListener("keydown", handleActivity);
			window.removeEventListener("touchstart", handleActivity);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		setDrawerOpen(false);
	}, [pathname]);
	const sidebarWidth = mode === "full" ? "260px" : "68px";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen w-full bg-background md:grid",
		style: { gridTemplateColumns: `${sidebarWidth} minmax(0,1fr)` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: booting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: { opacity: 1 },
				exit: { opacity: 0 },
				transition: {
					duration: .5,
					ease: [
						.22,
						1,
						.36,
						1
					]
				},
				className: "fixed inset-0 z-[100]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiohiomaLoader, {
					surface: "cream",
					label: `Karibu, ${member?.firstName || member?.displayName || "Old Starehian"}`
				})
			}, "boot") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: showSecurityAlert && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				exit: { opacity: 0 },
				className: "fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
					initial: {
						scale: .95,
						opacity: 0
					},
					animate: {
						scale: 1,
						opacity: 1
					},
					exit: {
						scale: .95,
						opacity: 0
					},
					className: "w-full max-w-md rounded-2xl bg-background p-6 shadow-lg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-full bg-warning/20 p-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-5 text-warning" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-lg font-semibold",
									children: "Security check"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-muted-foreground",
									children: securityMessage
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											trustCurrentDevice();
											setShowSecurityAlert(false);
										},
										className: "flex-1 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:brightness-110",
										children: "Trust device"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											clearAuth();
											navigate({ to: "/auth/login" });
										},
										className: "flex-1 rounded-lg border border-input bg-background px-4 py-2 text-sm font-medium text-foreground hover:bg-muted",
										children: "Sign out"
									})]
								})
							]
						})]
					})
				})
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "sticky top-0 hidden h-screen border-r border-sidebar-border md:block",
				style: { width: sidebarWidth },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarBody, {
					mode,
					onToggleMode: toggleMode,
					member,
					onSignOut: signOut,
					theme,
					onToggleTheme: toggleTheme
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: drawerOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: { opacity: 0 },
				animate: { opacity: 1 },
				exit: { opacity: 0 },
				onClick: () => setDrawerOpen(false),
				className: "fixed inset-0 z-40 bg-black/60 backdrop-blur-sm md:hidden"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.aside, {
				initial: { x: "-100%" },
				animate: { x: 0 },
				exit: { x: "-100%" },
				transition: {
					type: "spring",
					damping: 26,
					stiffness: 260
				},
				className: "fixed inset-y-0 left-0 z-50 w-[280px] md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarBody, {
					mode: "full",
					onToggleMode: () => setDrawerOpen(false),
					member,
					onSignOut: signOut,
					theme,
					onToggleTheme: toggleTheme,
					onNavigate: () => setDrawerOpen(false),
					showToggle: false
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setDrawerOpen(false),
					"aria-label": "Close menu",
					className: "absolute right-3 top-5 grid size-8 place-items-center rounded-md text-sidebar-foreground/70 hover:bg-white/10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
				})]
			})] }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-full flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-border/60 bg-background/90 px-4 py-3 backdrop-blur md:px-8 md:py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setDrawerOpen(true),
								"aria-label": "Open menu",
								className: "grid size-10 place-items-center rounded-xl border border-border bg-card text-foreground md:hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "flex items-center gap-2 md:hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: siohioma_logo_default,
									alt: "Old Starehian Society",
									className: "h-7 w-auto"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hidden md:block",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] font-semibold uppercase tracking-[0.22em] text-muted-foreground",
									children: "Alumni network"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "display text-sm font-semibold",
									children: "Old Starehian Society"
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						"aria-label": "Notifications",
						className: "relative grid size-10 place-items-center rounded-full border border-border bg-card text-muted-foreground active:scale-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-2.5 top-2.5 size-1.5 rounded-full bg-primary" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto w-full max-w-[860px] flex-1 px-5 pb-16 pt-6 md:px-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
						mode: "wait",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							initial: {
								opacity: 0,
								y: 8
							},
							animate: {
								opacity: 1,
								y: 0
							},
							exit: { opacity: 0 },
							transition: {
								duration: .28,
								ease: [
									.22,
									1,
									.36,
									1
								]
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
						}, pathname)
					})
				})]
			})
		]
	});
}
//#endregion
export { AppLayout as component };
