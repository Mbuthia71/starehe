import { n as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { Z as Calendar, a as UserPlus, c as ThumbsUp, rt as Award, st as Activity, x as MessageSquare } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.statements-DyQhv-vs.js
var import_jsx_runtime = require_jsx_runtime();
var feed = [
	{
		id: "1",
		actor: "Kevin Mwangi (Griffin, '08)",
		verb: "sent you a connection request",
		when: "12 min ago",
		kind: "connect"
	},
	{
		id: "2",
		actor: "Class of 2010",
		verb: "posted",
		target: "Our 15-year reunion venue is confirmed",
		when: "1 h ago",
		kind: "post"
	},
	{
		id: "3",
		actor: "Prof. Wanjiku (Faculty)",
		verb: "commented on your post about",
		target: "engineering mentorship",
		when: "3 h ago",
		kind: "comment"
	},
	{
		id: "4",
		actor: "Brian Otieno (Livingstone, '11)",
		verb: "endorsed you for",
		target: "software engineering mentorship",
		when: "Yesterday",
		kind: "endorse"
	},
	{
		id: "5",
		actor: "OSS Nairobi Chapter",
		verb: "created an event",
		target: "Chapter dinner · Sat 21 Nov",
		when: "Yesterday",
		kind: "event"
	},
	{
		id: "6",
		actor: "OSS Secretariat",
		verb: "shared",
		target: "the November newsletter",
		when: "2 d ago",
		kind: "post"
	},
	{
		id: "7",
		actor: "Achieng Nyongo (Griffin, '13)",
		verb: "connected with",
		target: "Mary Wanjiku",
		when: "3 d ago",
		kind: "connect"
	}
];
var iconFor = {
	connect: UserPlus,
	comment: MessageSquare,
	endorse: ThumbsUp,
	post: Activity,
	event: Calendar
};
function ActivityFeed() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Community activity"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-1 text-3xl font-semibold tracking-tight",
					children: "What's happening."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "A live feed of connections, posts, endorsements and events from your Starehe network."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "card-elev divide-y divide-border/60 overflow-hidden p-0",
				children: feed.map((item, i) => {
					const Icon = iconFor[item.kind];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 6
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .3,
							delay: i * .03
						},
						className: "flex items-start gap-3 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-10 shrink-0 place-items-center rounded-full bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm text-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: item.actor
									}),
									" ",
									item.verb,
									item.target && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-medium text-primary",
										children: [" · ", item.target]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-0.5 text-[11px] text-muted-foreground",
								children: item.when
							})]
						})]
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev flex items-center gap-3 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0 flex-1 text-xs text-muted-foreground",
					children: "Your activity is visible to fellow Old Starehians only. Manage visibility in Profile."
				})]
			})
		]
	});
}
//#endregion
export { ActivityFeed as component };
