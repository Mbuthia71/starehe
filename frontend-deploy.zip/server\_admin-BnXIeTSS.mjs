import { o as __toESM } from "./_runtime.mjs";
import { a as isAuthenticated, i as hasPermission, r as getStoredMember, t as clearAuth } from "./_ssr/auth-CN9qeBFn.mjs";
import { t as siohioma_logo_default } from "./_ssr/siohioma-logo-DkFN5Et8.mjs";
import { n as require_jsx_runtime, r as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link, i as useRouterState, p as useNavigate, s as Outlet } from "./_libs/@tanstack/react-router+[...].mjs";
import { T as LogOut, U as CircleCheckBig, Y as ChartColumn, a as UserPlus, r as Users, st as Activity, tt as Bell } from "./_libs/lucide-react.mjs";
import { n as AnimatePresence, t as motion } from "./_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_admin-BnXIeTSS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var adminTabs = [
	{
		to: "/admin/dashboard",
		label: "Overview",
		icon: ChartColumn,
		exact: true,
		permission: "view_all"
	},
	{
		to: "/admin/loans",
		label: "Connections",
		icon: UserPlus,
		permission: "approve"
	},
	{
		to: "/admin/members",
		label: "Alumni",
		icon: Users,
		permission: "view_all"
	},
	{
		to: "/admin/transactions",
		label: "Activity log",
		icon: Activity,
		permission: "read"
	},
	{
		to: "/admin/approvals",
		label: "Approvals",
		icon: CircleCheckBig,
		permission: "approve"
	}
];
function AdminSideTab({ to, label, icon: Icon, exact, permission }) {
	if (!(!permission || hasPermission(permission))) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		activeOptions: { exact: !!exact },
		className: "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground data-[status=active]:bg-primary/10 data-[status=active]:text-primary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4",
			strokeWidth: 1.75
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function AdminLayout() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const navigate = useNavigate();
	const [booting, setBooting] = (0, import_react.useState)(true);
	const [member, setMember] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setMember(getStoredMember());
		if (!isAuthenticated()) {
			navigate({ to: "/auth/login" });
			return;
		}
		if (!hasPermission("view_all") && !hasPermission("approve")) {
			navigate({ to: "/" });
			return;
		}
		const t = setTimeout(() => setBooting(false), 600);
		return () => clearTimeout(t);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-screen w-full bg-background lg:grid lg:grid-cols-[280px_minmax(0,1fr)]",
		children: [
			booting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[100] flex items-center justify-center bg-background",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/assets/siohioma-logo-BTZxRCjr.png",
						alt: "OSS",
						className: "mx-auto h-12 w-auto animate-pulse"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 text-sm text-muted-foreground",
						children: "Loading OSS admin…"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden lg:flex lg:sticky lg:top-0 lg:h-screen lg:flex-col lg:border-r lg:border-border/60 lg:bg-card/40 lg:px-5 lg:py-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/admin/dashboard",
						className: "flex items-center gap-2 px-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: siohioma_logo_default,
							alt: "OSS",
							className: "h-8 w-auto"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold",
							children: "Admin"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mt-10 flex flex-col gap-1",
						children: adminTabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminSideTab, { ...t }, t.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-auto rounded-2xl border border-border/60 bg-background/60 p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "Signed in as"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 truncate text-sm font-semibold",
								children: member?.displayName || "Admin"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-xs text-muted-foreground",
								children: member?.role || "Council"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => {
									clearAuth();
									navigate({ to: "/auth/login" });
								},
								className: "mt-2 flex items-center gap-2 text-xs text-danger hover:underline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-3" }), " Sign out"]
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex w-full max-w-7xl flex-col px-5 py-6 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-4 border-b border-border/60 pb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.2em] text-muted-foreground",
						children: "Old Starehian Society"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-semibold tracking-tight",
						children: "Admin console"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "relative grid size-10 place-items-center rounded-full border border-border bg-card text-muted-foreground active:scale-95",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-2.5 top-2.5 size-1.5 rounded-full bg-warning" })]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1 py-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
						mode: "wait",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
							initial: {
								opacity: 0,
								y: 8
							},
							animate: {
								opacity: 1,
								y: 0
							},
							exit: { opacity: 0 },
							transition: {
								duration: .28,
								ease: [
									.22,
									1,
									.36,
									1
								]
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
						}, pathname)
					})
				})]
			})
		]
	});
}
//#endregion
export { AdminLayout as component };
