import { c as lazyRouteComponent, l as createFileRoute } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.business._id-B_-AGwou.js
var $$splitComponentImporter = () => import("./_app.business._id-BqNBrJJC.mjs");
var Route = createFileRoute("/_app/business/$id")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
