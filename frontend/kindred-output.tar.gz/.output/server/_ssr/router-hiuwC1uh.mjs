import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react, r as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { c as lazyRouteComponent, d as Link, l as createFileRoute, m as useRouter, n as Scripts, o as createRouter, r as HeadContent, s as Outlet, u as createRootRouteWithContext } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-hiuwC1uh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-D6N1PQ_-.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$14 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Siohioma · Member Portal" },
			{
				name: "description",
				content: "Siohioma SACCO — manage your savings, loans and M-Pesa transactions"
			},
			{
				name: "author",
				content: "Siohioma"
			},
			{
				property: "og:title",
				content: "Siohioma · Member Portal"
			},
			{
				property: "og:description",
				content: "Siohioma SACCO Member Portal"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			},
			{
				name: "twitter:site",
				content: "@Siohioma"
			},
			{
				name: "theme-color",
				content: "#0a0a0a"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Forum&family=Cormorant+Garamond:wght@300;400;500;600;700&family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@500;600&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$14.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			richColors: true,
			position: "top-center"
		})]
	});
}
var $$splitComponentImporter$13 = () => import("../_app-B9wMob4R.mjs");
var Route$13 = createFileRoute("/_app")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("../_app.index-CMi7y6wb.mjs");
var Route$12 = createFileRoute("/_app/")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./auth.pin-setup-DjAHR-nn.mjs");
var Route$11 = createFileRoute("/auth/pin-setup")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./auth.otp-rF_4bzqM.mjs");
var Route$10 = createFileRoute("/auth/otp")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./auth.login-BB9QEgUl.mjs");
var Route$9 = createFileRoute("/auth/login")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("../_app.withdraw-BJ5nE6hH.mjs");
var Route$8 = createFileRoute("/_app/withdraw")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("../_app.transfer-CQnbziX1.mjs");
var Route$7 = createFileRoute("/_app/transfer")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("../_app.statements-CBtDDnv5.mjs");
var Route$6 = createFileRoute("/_app/statements")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("../_app.profile-DPRR8vlF.mjs");
var Route$5 = createFileRoute("/_app/profile")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("../_app.loans-DwhdwjVC.mjs");
var Route$4 = createFileRoute("/_app/loans")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("../_app.guarantors-CB6uR8cd.mjs");
var Route$3 = createFileRoute("/_app/guarantors")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("../_app.cards-AcTJrCNk.mjs");
var Route$2 = createFileRoute("/_app/cards")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("../_app.accounts-CkfI0F6x.mjs");
var Route$1 = createFileRoute("/_app/accounts")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("../_app.loans.apply-B7NuXnQI.mjs");
var Route = createFileRoute("/_app/loans/apply")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var AppRoute = Route$13.update({
	id: "/_app",
	getParentRoute: () => Route$14
});
var AppIndexRoute = Route$12.update({
	id: "/",
	path: "/",
	getParentRoute: () => AppRoute
});
var AuthPinSetupRoute = Route$11.update({
	id: "/auth/pin-setup",
	path: "/auth/pin-setup",
	getParentRoute: () => Route$14
});
var AuthOtpRoute = Route$10.update({
	id: "/auth/otp",
	path: "/auth/otp",
	getParentRoute: () => Route$14
});
var AuthLoginRoute = Route$9.update({
	id: "/auth/login",
	path: "/auth/login",
	getParentRoute: () => Route$14
});
var AppWithdrawRoute = Route$8.update({
	id: "/withdraw",
	path: "/withdraw",
	getParentRoute: () => AppRoute
});
var AppTransferRoute = Route$7.update({
	id: "/transfer",
	path: "/transfer",
	getParentRoute: () => AppRoute
});
var AppStatementsRoute = Route$6.update({
	id: "/statements",
	path: "/statements",
	getParentRoute: () => AppRoute
});
var AppProfileRoute = Route$5.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => AppRoute
});
var AppLoansRoute = Route$4.update({
	id: "/loans",
	path: "/loans",
	getParentRoute: () => AppRoute
});
var AppGuarantorsRoute = Route$3.update({
	id: "/guarantors",
	path: "/guarantors",
	getParentRoute: () => AppRoute
});
var AppCardsRoute = Route$2.update({
	id: "/cards",
	path: "/cards",
	getParentRoute: () => AppRoute
});
var AppAccountsRoute = Route$1.update({
	id: "/accounts",
	path: "/accounts",
	getParentRoute: () => AppRoute
});
var AppLoansRouteChildren = { AppLoansApplyRoute: Route.update({
	id: "/apply",
	path: "/apply",
	getParentRoute: () => AppLoansRoute
}) };
var AppRouteChildren = {
	AppAccountsRoute,
	AppCardsRoute,
	AppGuarantorsRoute,
	AppLoansRoute: AppLoansRoute._addFileChildren(AppLoansRouteChildren),
	AppProfileRoute,
	AppStatementsRoute,
	AppTransferRoute,
	AppWithdrawRoute,
	AppIndexRoute
};
var rootRouteChildren = {
	AppRoute: AppRoute._addFileChildren(AppRouteChildren),
	AuthLoginRoute,
	AuthOtpRoute,
	AuthPinSetupRoute
};
var routeTree = Route$14._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
