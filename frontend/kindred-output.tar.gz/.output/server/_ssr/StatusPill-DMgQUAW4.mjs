import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/StatusPill-DMgQUAW4.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var toneStyles = {
	success: "bg-success-soft text-success",
	warning: "bg-warning-soft text-warning",
	danger: "bg-danger-soft text-danger",
	neutral: "bg-muted text-muted-foreground",
	info: "bg-accent text-accent-foreground"
};
var mapping = {
	Verified: "success",
	Pending: "warning",
	Flagged: "danger",
	Completed: "success",
	Failed: "danger",
	Active: "success",
	Frozen: "warning",
	Blocked: "danger",
	Dormant: "warning",
	Closed: "neutral",
	Applied: "neutral",
	"Committee Review": "info",
	Approved: "info",
	Disbursed: "info",
	Arrears: "danger",
	Rejected: "danger",
	Confirmed: "success",
	"In Flight": "info",
	Accepted: "success",
	Declined: "danger",
	Posted: "success",
	Draft: "neutral"
};
function StatusPill({ status, tone }) {
	const t = tone ?? mapping[status] ?? "neutral";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium", toneStyles[t]),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", {
			"bg-success": t === "success",
			"bg-warning": t === "warning",
			"bg-danger": t === "danger",
			"bg-muted-foreground": t === "neutral",
			"bg-primary": t === "info"
		}) }), status]
	});
}
//#endregion
export { StatusPill as t };
