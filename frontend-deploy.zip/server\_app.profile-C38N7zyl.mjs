import { o as __toESM } from "./_runtime.mjs";
import { r as getStoredMember, t as clearAuth } from "./_ssr/auth-CN9qeBFn.mjs";
import { n as require_jsx_runtime, r as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { p as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { C as MapPin, D as Linkedin, F as Globe, I as Fingerprint, J as Check, O as KeyRound, P as GraduationCap, Q as Building2, T as LogOut, X as Camera, k as Instagram, m as ShieldCheck, nt as BadgeCheck, o as Twitter, q as ChevronRight, rt as Award, v as Phone, w as Mail } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { t as StatusPill } from "./_ssr/StatusPill-DMgQUAW4.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.profile-C38N7zyl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Profile() {
	const navigate = useNavigate();
	const member = getStoredMember();
	const [biometric, setBiometric] = (0, import_react.useState)(false);
	const fileRef = (0, import_react.useRef)(null);
	const [avatar, setAvatar] = (0, import_react.useState)(null);
	const [socials, setSocials] = (0, import_react.useState)({
		linkedin: "",
		twitter: "",
		instagram: "",
		website: ""
	});
	const [privacy, setPrivacy] = (0, import_react.useState)({
		linkedin: true,
		twitter: true,
		instagram: true,
		website: true,
		email: true,
		phone: false,
		city: true,
		employer: true
	});
	const [savedFlash, setSavedFlash] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		try {
			const a = localStorage.getItem("oss.profile.avatar");
			if (a) setAvatar(a);
			const s = localStorage.getItem("oss.profile.socials");
			if (s) setSocials(JSON.parse(s));
			const p = localStorage.getItem("oss.profile.privacy");
			if (p) setPrivacy((prev) => ({
				...prev,
				...JSON.parse(p)
			}));
		} catch {}
	}, []);
	const onFile = (file) => {
		const MAX_MB = 5;
		if (!file.type.startsWith("image/")) {
			toast.error("That file isn't an image. Please choose a JPG, PNG or WebP.");
			return;
		}
		if (!/^image\/(jpe?g|png|webp|gif)$/i.test(file.type)) {
			toast.error("Unsupported format. Use JPG, PNG, WebP or GIF.");
			return;
		}
		if (file.size > MAX_MB * 1024 * 1024) {
			toast.error(`Image is too large (${(file.size / 1024 / 1024).toFixed(1)} MB). Max ${MAX_MB} MB.`);
			return;
		}
		const reader = new FileReader();
		reader.onload = () => {
			const url = String(reader.result);
			setAvatar(url);
			try {
				localStorage.setItem("oss.profile.avatar", url);
			} catch {}
			toast.success("Profile photo updated");
		};
		reader.onerror = () => toast.error("Could not read that image. Try another file.");
		reader.readAsDataURL(file);
	};
	const saveSocials = () => {
		try {
			localStorage.setItem("oss.profile.socials", JSON.stringify(socials));
		} catch {}
		try {
			localStorage.setItem("oss.profile.privacy", JSON.stringify(privacy));
		} catch {}
		setSavedFlash(true);
		setTimeout(() => setSavedFlash(false), 1600);
	};
	const togglePrivacy = (k) => setPrivacy((p) => ({
		...p,
		[k]: !p[k]
	}));
	const shareUrl = typeof window !== "undefined" && member ? `${window.location.origin}/p/${member.accountNo ?? member.id}` : "";
	const copyShareUrl = async () => {
		if (!shareUrl) return;
		try {
			await navigator.clipboard.writeText(shareUrl);
			toast.success("Profile link copied");
		} catch {
			toast.error("Could not copy link");
		}
	};
	const initials = (member?.displayName ?? "OS").split(" ").map((p) => p[0]).slice(0, 2).join("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.22em] text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block h-[3px] w-6 rounded-full bg-primary" }), "Your profile"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "display mt-2 text-3xl font-semibold tracking-tight md:text-4xl",
					children: [member?.displayName ?? "Old Starehian", "."]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: ["Public handle · ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono",
						children: member?.accountNo ?? "OSS-0000"
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.section, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { duration: .45 },
				className: "grid gap-5 md:grid-cols-[300px_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-splash relative overflow-hidden rounded-2xl border border-white/10 p-4 text-anchor-foreground shadow-[0_30px_60px_-30px_oklch(0.15_0.06_265/0.7)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "starehe-stripe absolute inset-x-0 top-0 h-[3px]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mx-auto aspect-[4/5] w-full overflow-hidden rounded-xl",
							children: [
								avatar ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: avatar,
									alt: member?.displayName ?? "avatar",
									className: "h-full w-full object-cover"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-full w-full place-items-center bg-gradient-to-br from-primary/40 via-secondary/40 to-[oklch(0.70_0.18_45/0.5)] text-4xl font-semibold text-white",
									children: initials
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => fileRef.current?.click(),
									className: "absolute bottom-2 right-2 inline-flex items-center gap-1.5 rounded-full bg-black/60 px-3 py-1.5 text-[11px] font-semibold text-white backdrop-blur hover:bg-black/70",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3.5" }),
										" ",
										avatar ? "Change" : "Upload"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									ref: fileRef,
									type: "file",
									accept: "image/*",
									className: "hidden",
									onChange: (e) => e.target.files?.[0] && onFile(e.target.files[0])
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "display truncate text-base font-semibold",
								children: member?.displayName ?? "Old Starehian"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-4 shrink-0 text-primary" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-0.5 text-[11px] text-anchor-foreground/60",
							children: member?.officeName ?? "Griffin House · Class of 2008"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-3 gap-2 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-white/5 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] uppercase tracking-wider text-anchor-foreground/50",
										children: "Connections"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-0.5 text-sm font-semibold",
										children: "184"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-white/5 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] uppercase tracking-wider text-anchor-foreground/50",
										children: "Mentees"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-0.5 text-sm font-semibold",
										children: "7"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-white/5 py-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] uppercase tracking-wider text-anchor-foreground/50",
										children: "Chapters"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-0.5 text-sm font-semibold",
										children: "3"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: copyShareUrl,
							className: "mt-3 w-full rounded-xl bg-white text-slate-900 py-2.5 text-xs font-bold uppercase tracking-wider hover:bg-white/90",
							children: "Copy shareable link"
						}),
						shareUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 truncate text-center text-[10px] text-white/50",
							children: shareUrl
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-elev p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "label-eyebrow",
										children: "About"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-primary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, { className: "size-3" }), " Life member"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-foreground",
									children: "Old Starehian, Griffin House. Product manager currently building fintech for East Africa. Happy to mentor Form-4 leavers and Class of '24–'26 on tech and product careers."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 grid grid-cols-1 gap-2 text-[12px] sm:grid-cols-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-2 text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-3.5" }), " Starehe Boys' Centre · 2004–2008"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-2 text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-3.5" }), " Product · Independent"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-2 text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }), " Nairobi, Kenya"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-2 text-muted-foreground",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-3.5" }), " Verified alumnus"]
										})
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-elev p-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "label-eyebrow",
									children: "Socials"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: saveSocials,
									className: "inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1 text-[11px] font-semibold text-primary-foreground hover:brightness-110",
									children: savedFlash ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }), " Saved"] }) : "Save"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-2 sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialInput, {
										icon: Linkedin,
										label: "LinkedIn",
										value: socials.linkedin,
										onChange: (v) => setSocials((s) => ({
											...s,
											linkedin: v
										})),
										placeholder: "linkedin.com/in/…"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialInput, {
										icon: Twitter,
										label: "X / Twitter",
										value: socials.twitter,
										onChange: (v) => setSocials((s) => ({
											...s,
											twitter: v
										})),
										placeholder: "@handle"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialInput, {
										icon: Instagram,
										label: "Instagram",
										value: socials.instagram,
										onChange: (v) => setSocials((s) => ({
											...s,
											instagram: v
										})),
										placeholder: "@handle"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialInput, {
										icon: Globe,
										label: "Website",
										value: socials.website,
										onChange: (v) => setSocials((s) => ({
											...s,
											website: v
										})),
										placeholder: "you.com"
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "card-elev p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-between",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "label-eyebrow",
										children: "Privacy · what other alumni can see"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-[11px] text-muted-foreground",
									children: "Toggle each field to control visibility on your public member card."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid gap-2 sm:grid-cols-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyRow, {
											label: "LinkedIn",
											on: privacy.linkedin,
											onToggle: () => togglePrivacy("linkedin")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyRow, {
											label: "X / Twitter",
											on: privacy.twitter,
											onToggle: () => togglePrivacy("twitter")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyRow, {
											label: "Instagram",
											on: privacy.instagram,
											onToggle: () => togglePrivacy("instagram")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyRow, {
											label: "Website",
											on: privacy.website,
											onToggle: () => togglePrivacy("website")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyRow, {
											label: "Email",
											on: privacy.email,
											onToggle: () => togglePrivacy("email")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyRow, {
											label: "Phone number",
											on: privacy.phone,
											onToggle: () => togglePrivacy("phone")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyRow, {
											label: "Home city",
											on: privacy.city,
											onToggle: () => togglePrivacy("city")
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyRow, {
											label: "Employer",
											on: privacy.employer,
											onToggle: () => togglePrivacy("employer")
										})
									]
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow mb-3",
				children: "Contact"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev divide-y divide-border/60 overflow-hidden p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						icon: Mail,
						label: "Email",
						value: member?.emailAddress ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						icon: Phone,
						label: "Phone",
						value: member?.mobileNo ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						icon: MapPin,
						label: "Home city",
						value: "Nairobi, Kenya"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						icon: Building2,
						label: "Employer",
						value: "Independent consultant"
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow mb-3",
				children: "Security"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev divide-y divide-border/60 overflow-hidden p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-muted/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-10 shrink-0 place-items-center rounded-full bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium text-foreground",
									children: "Change password"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground",
									children: "Recommended every 90 days"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-muted-foreground" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-10 shrink-0 place-items-center rounded-full bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fingerprint, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium text-foreground",
									children: "Biometric sign-in"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground",
									children: "Use Face ID or fingerprint on this device"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setBiometric((b) => !b),
								className: `relative h-6 w-11 rounded-full transition-colors ${biometric ? "bg-primary" : "bg-muted"}`,
								"aria-label": "Toggle biometric",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-5 rounded-full bg-white transition-transform ${biometric ? "translate-x-5" : "translate-x-0.5"}` })
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid size-10 shrink-0 place-items-center rounded-full bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium text-foreground",
									children: "Two-step verification"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground",
									children: "On · SMS code on new devices"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: "Active" })
						]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: () => {
					clearAuth();
					navigate({ to: "/auth/login" });
				},
				className: "flex w-full items-center justify-center gap-2 rounded-2xl border border-danger/30 bg-danger/5 py-3 text-sm font-semibold text-danger transition-colors hover:bg-danger/10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), " Sign out"]
			})
		]
	});
}
function SocialInput({ icon: Icon, label, value, onChange, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3" }),
				" ",
				label
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			onChange: (e) => onChange(e.target.value),
			placeholder,
			className: "h-10 w-full rounded-lg border border-border bg-background px-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/30"
		})]
	});
}
function Row({ icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid size-10 shrink-0 place-items-center rounded-full bg-muted text-muted-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[11px] uppercase tracking-wider text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "truncate text-sm font-medium text-foreground",
				children: value
			})]
		})]
	});
}
function PrivacyRow({ label, on, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between rounded-lg border border-border/60 bg-background/50 px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-semibold text-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: onToggle,
			className: `relative h-5 w-9 rounded-full transition-colors ${on ? "bg-primary" : "bg-muted"}`,
			"aria-label": `Toggle ${label} visibility`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-0.5 size-4 rounded-full bg-white transition-transform ${on ? "translate-x-4" : "translate-x-0.5"}` })
		})]
	});
}
//#endregion
export { Profile as component };
