import { o as __toESM } from "../_runtime.mjs";
import { t as siohioma_logo_png_asset_default } from "./siohioma-logo.png.asset-DrWRrNAy.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { p as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.otp-BnydP_Wv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Otp() {
	const navigate = useNavigate();
	const [otp, setOtp] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-screen w-full max-w-[480px] flex-col bg-background px-6 pb-10 pt-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: siohioma_logo_png_asset_default.url,
				alt: "Siohioma",
				className: "h-10 w-auto self-start"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-4xl font-semibold tracking-tight",
					children: "Verify your device."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "We sent a 6-digit code by SMS. Enter it below."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				inputMode: "numeric",
				maxLength: 6,
				value: otp,
				onChange: (e) => setOtp(e.target.value.replace(/\D/g, "")),
				placeholder: "••••••",
				className: "num mt-10 w-full rounded-2xl border border-border bg-card px-4 py-5 text-center text-3xl tracking-[0.6em] focus:outline-none focus:ring-2 focus:ring-ring/40"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: otp.length !== 6,
				onClick: () => navigate({ to: "/" }),
				className: "mt-6 w-full rounded-full bg-primary px-5 py-4 text-sm font-semibold text-primary-foreground active:scale-[0.98] disabled:opacity-40",
				children: "Verify"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "mt-4 text-center text-xs text-muted-foreground",
				children: "Didn't get it? Resend in 30s"
			})
		]
	});
}
//#endregion
export { Otp as component };
