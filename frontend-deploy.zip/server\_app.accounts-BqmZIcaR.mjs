import { o as __toESM } from "./_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { $ as Briefcase, C as MapPin, a as UserPlus, g as Search, r as Users, t as X } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.accounts-BqmZIcaR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var alumni = [
	{
		id: "1",
		name: "Kevin Mwangi",
		house: "Griffin",
		classYear: 2008,
		role: "Product Manager · Safaricom",
		city: "Nairobi",
		initials: "KM"
	},
	{
		id: "2",
		name: "Brian Otieno",
		house: "Livingstone",
		classYear: 2011,
		role: "Senior Engineer · Andela",
		city: "Kampala",
		initials: "BO"
	},
	{
		id: "3",
		name: "Achieng Nyongo",
		house: "Griffin",
		classYear: 2013,
		role: "Doctor · Aga Khan Hospital",
		city: "Nairobi",
		initials: "AN"
	},
	{
		id: "4",
		name: "James Kariuki",
		house: "Livingstone",
		classYear: 2005,
		role: "Founder · Kilimanjaro Ventures",
		city: "Dar es Salaam",
		initials: "JK"
	},
	{
		id: "5",
		name: "Mary Wanjiku",
		house: "Griffin",
		classYear: 2015,
		role: "Lawyer · TripleOKLaw",
		city: "Mombasa",
		initials: "MW"
	},
	{
		id: "6",
		name: "Peter Kimani",
		house: "Livingstone",
		classYear: 2009,
		role: "Data Scientist · IBM",
		city: "London",
		initials: "PK"
	},
	{
		id: "7",
		name: "Sarah Njeri",
		house: "Griffin",
		classYear: 2012,
		role: "Journalist · NTV",
		city: "Nairobi",
		initials: "SN"
	},
	{
		id: "8",
		name: "David Ochieng",
		house: "Livingstone",
		classYear: 2007,
		role: "Architect · Planning Systems",
		city: "Kigali",
		initials: "DO"
	}
];
function Directory() {
	const [q, setQ] = (0, import_react.useState)("");
	const [house, setHouse] = (0, import_react.useState)("");
	const [decade, setDecade] = (0, import_react.useState)("");
	const houses = (0, import_react.useMemo)(() => Array.from(new Set(alumni.map((a) => a.house))).sort(), []);
	const decades = (0, import_react.useMemo)(() => {
		return Array.from(new Set(alumni.map((a) => `${Math.floor(a.classYear / 10) * 10}s`))).sort();
	}, []);
	const filtered = (0, import_react.useMemo)(() => {
		const term = q.trim().toLowerCase();
		return alumni.filter((a) => {
			if (house && a.house !== house) return false;
			if (decade && `${Math.floor(a.classYear / 10) * 10}s` !== decade) return false;
			if (!term) return true;
			return [
				a.name,
				a.house,
				String(a.classYear),
				a.role,
				a.city
			].some((f) => f.toLowerCase().includes(term));
		});
	}, [
		q,
		house,
		decade
	]);
	const clearFilters = () => {
		setHouse("");
		setDecade("");
		setQ("");
	};
	const anyFilter = q || house || decade;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Alumni directory"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display mt-1 text-3xl font-black tracking-tight md:text-4xl",
					children: "Find an Old Starehian."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: [filtered.length.toLocaleString(), " of 10,000+ alumni · filter by house, class year & city."]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search by name, house, class year, city…",
					className: "h-11 w-full rounded-full border border-border bg-card pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/40"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground",
						children: "House"
					}),
					houses.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setHouse((cur) => cur === h ? "" : h),
						className: `rounded-full border px-3 py-1 text-[11px] font-semibold transition-colors ${house === h ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground hover:bg-muted"}`,
						children: h
					}, h)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-[10px] font-bold uppercase tracking-[0.2em] text-muted-foreground",
						children: "Class"
					}),
					decades.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setDecade((cur) => cur === d ? "" : d),
						className: `rounded-full border px-3 py-1 text-[11px] font-semibold transition-colors ${decade === d ? "border-secondary bg-secondary text-secondary-foreground" : "border-border bg-card text-foreground hover:bg-muted"}`,
						children: d
					}, d)),
					anyFilter && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: clearFilters,
						className: "inline-flex items-center gap-1 rounded-full border border-border bg-muted px-3 py-1 text-[11px] font-semibold text-foreground hover:bg-muted/70",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3" }), " Clear"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [filtered.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 6
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .3,
						delay: i * .03
					},
					className: "card-elev flex items-center gap-4 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-12 shrink-0 place-items-center rounded-full bg-primary/10 text-sm font-semibold text-primary",
							children: a.initials
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/p/$id",
									params: { id: a.id },
									className: "truncate text-sm font-bold text-foreground hover:text-primary",
									children: a.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "rounded-full bg-muted px-2 py-0.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground",
									children: [
										a.house,
										" · '",
										String(a.classYear).slice(2)
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3" }),
										" ",
										a.role
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3" }),
										" ",
										a.city
									]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/loans",
							className: "inline-flex shrink-0 items-center gap-1 rounded-full border border-border bg-card px-3 py-1.5 text-[11px] font-medium text-foreground transition-colors hover:bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3" }), " Connect"]
						})
					]
				}, a.id)), filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-elev flex flex-col items-center justify-center gap-2 p-10 text-center text-sm text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" }), "No Old Starehians match that search."]
				})]
			})
		]
	});
}
//#endregion
export { Directory as component };
