import { t as siohioma_logo_default } from "./siohioma-logo-DkFN5Et8.mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { d as Link, m as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { $ as Briefcase, C as MapPin, D as Linkedin, F as Globe, P as GraduationCap, a as UserPlus, k as Instagram, nt as BadgeCheck, o as Twitter, ot as ArrowLeft } from "../_libs/lucide-react.mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/p._id-CJACjAT-.js
var import_jsx_runtime = require_jsx_runtime();
var alumni = [
	{
		id: "1",
		name: "Kevin Mwangi",
		house: "Griffin",
		classYear: 2008,
		role: "Product Manager · Safaricom",
		city: "Nairobi",
		initials: "KM"
	},
	{
		id: "2",
		name: "Brian Otieno",
		house: "Livingstone",
		classYear: 2011,
		role: "Senior Engineer · Andela",
		city: "Kampala",
		initials: "BO"
	},
	{
		id: "3",
		name: "Achieng Nyongo",
		house: "Griffin",
		classYear: 2013,
		role: "Doctor · Aga Khan Hospital",
		city: "Nairobi",
		initials: "AN"
	},
	{
		id: "4",
		name: "James Kariuki",
		house: "Livingstone",
		classYear: 2005,
		role: "Founder · Kilimanjaro Ventures",
		city: "Dar es Salaam",
		initials: "JK"
	},
	{
		id: "5",
		name: "Mary Wanjiku",
		house: "Griffin",
		classYear: 2015,
		role: "Lawyer · TripleOKLaw",
		city: "Mombasa",
		initials: "MW"
	},
	{
		id: "6",
		name: "Peter Kimani",
		house: "Livingstone",
		classYear: 2009,
		role: "Data Scientist · IBM",
		city: "London",
		initials: "PK"
	},
	{
		id: "7",
		name: "Sarah Njeri",
		house: "Griffin",
		classYear: 2012,
		role: "Journalist · NTV",
		city: "Nairobi",
		initials: "SN"
	},
	{
		id: "8",
		name: "David Ochieng",
		house: "Livingstone",
		classYear: 2007,
		role: "Architect · Planning Systems",
		city: "Kigali",
		initials: "DO"
	}
];
function PublicProfile() {
	const { id } = useParams({ from: "/p/$id" });
	const a = alumni.find((x) => x.id === id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "border-b border-border/60 bg-background/90 backdrop-blur",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-4xl items-center justify-between px-6 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid size-9 place-items-center rounded-xl bg-anchor",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: siohioma_logo_default,
							alt: "OSS",
							className: "h-6 w-auto"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] font-bold uppercase tracking-[0.22em] text-muted-foreground",
						children: "Old Starehian"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "display text-sm font-black",
						children: "Society"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/accounts",
					className: "inline-flex items-center gap-1 text-[11px] font-semibold text-muted-foreground hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-3" }), " Directory"]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "mx-auto max-w-4xl px-6 py-10",
			children: !a ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev p-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "display text-2xl font-black",
						children: "Member not found"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "This profile may be private or the link is invalid."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/accounts",
						className: "mt-6 inline-flex items-center gap-1 rounded-full bg-primary px-4 py-2 text-xs font-bold text-primary-foreground",
						children: "Browse directory"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.article, {
				initial: {
					opacity: 0,
					y: 10
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: { duration: .5 },
				className: "grid gap-6 md:grid-cols-[300px_minmax(0,1fr)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "surface-splash relative overflow-hidden rounded-2xl border border-white/10 p-4 text-anchor-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "starehe-stripe absolute inset-x-0 top-0 h-[3px]" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid aspect-[4/5] w-full place-items-center rounded-xl bg-gradient-to-br from-primary/40 via-secondary/40 to-[oklch(0.70_0.18_45/0.5)] text-5xl font-black text-white",
							children: a.initials
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "display truncate text-base font-black",
								children: a.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "size-4 shrink-0 text-primary" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-0.5 text-[11px] text-anchor-foreground/60",
							children: [
								a.house,
								" House · Class of ",
								a.classYear
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "mt-3 inline-flex w-full items-center justify-center gap-1.5 rounded-xl bg-white py-2.5 text-xs font-bold uppercase tracking-wider text-slate-900 hover:bg-white/90",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-3.5" }), " Request to connect"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card-elev p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "label-eyebrow",
								children: "About"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-sm leading-relaxed text-foreground",
								children: [
									"Old Starehian, ",
									a.house,
									" House, Class of ",
									a.classYear,
									". Currently working as ",
									a.role.toLowerCase(),
									" — based in ",
									a.city,
									"."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 grid grid-cols-1 gap-2 text-[12px] sm:grid-cols-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-2 text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "size-3.5" }),
											" Starehe Boys' Centre · '",
											String(a.classYear).slice(2)
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-2 text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "size-3.5" }),
											" ",
											a.role
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-2 text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5" }),
											" ",
											a.city
										]
									})
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card-elev p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "label-eyebrow",
								children: "Reach out"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2 text-[12px]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialChip, {
										icon: Linkedin,
										label: "LinkedIn"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialChip, {
										icon: Twitter,
										label: "Twitter"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialChip, {
										icon: Instagram,
										label: "Instagram"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SocialChip, {
										icon: Globe,
										label: "Website"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-[11px] text-muted-foreground",
								children: "Contact details are only shown to signed-in Old Starehians the member has allowed."
							})
						]
					})]
				})]
			})
		})]
	});
}
function SocialChip({ icon: Icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 font-semibold text-muted-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3" }),
			" ",
			label
		]
	});
}
//#endregion
export { PublicProfile as component };
