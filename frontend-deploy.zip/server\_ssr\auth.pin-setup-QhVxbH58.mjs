import { o as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { p as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { m as ShieldCheck } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.pin-setup-QhVxbH58.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PinSetup() {
	const navigate = useNavigate();
	const [pin, setPin] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-background flex items-center justify-center p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid size-12 place-items-center rounded-2xl bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-6 display text-3xl font-semibold tracking-tight",
					children: "Set your PIN."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Choose a 4-digit PIN to unlock the Old Starehian Society app on this device."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: (e) => {
						e.preventDefault();
						if (pin.length !== 4) {
							setError("PIN must be 4 digits.");
							return;
						}
						if (pin !== confirm) {
							setError("PINs don't match.");
							return;
						}
						navigate({ to: "/" });
					},
					className: "mt-8 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							inputMode: "numeric",
							maxLength: 4,
							value: pin,
							onChange: (e) => setPin(e.target.value.replace(/\D/g, "")),
							placeholder: "New PIN",
							className: "h-14 w-full rounded-2xl border border-input bg-card text-center text-2xl tracking-[0.4em] focus:outline-none focus:ring-2 focus:ring-ring/40"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							inputMode: "numeric",
							maxLength: 4,
							value: confirm,
							onChange: (e) => setConfirm(e.target.value.replace(/\D/g, "")),
							placeholder: "Confirm PIN",
							className: "h-14 w-full rounded-2xl border border-input bg-card text-center text-2xl tracking-[0.4em] focus:outline-none focus:ring-2 focus:ring-ring/40"
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-danger",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "w-full rounded-2xl bg-primary py-3 text-sm font-semibold text-primary-foreground hover:brightness-110",
							children: "Save PIN"
						})
					]
				})
			]
		})
	});
}
//#endregion
export { PinSetup as component };
