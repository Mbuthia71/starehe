//#region node_modules/.nitro/vite/services/ssr/assets/api-D5WHFWw8.js
var currentMember = {
	id: "m_001",
	firstName: "Aisha",
	lastName: "Mwangi",
	memberNo: "TJS-00142",
	kycStatus: "Verified",
	phone: "+254 712 884 921",
	msisdn: "+254712884921",
	joinedDate: "2019-03-12",
	branch: "Westlands",
	biometricEnabled: true,
	nextOfKin: {
		name: "Peter Mwangi",
		relation: "Spouse",
		phone: "+254 720 113 442"
	}
};
var myAccounts = [
	{
		id: "a_001",
		accountNo: "01-44210-001",
		type: "Savings",
		balance: 184300,
		available: 178300,
		interestRate: 6.5,
		status: "Active",
		openedOn: "2019-03-12"
	},
	{
		id: "a_002",
		accountNo: "01-44210-002",
		type: "Share Capital",
		balance: 45e3,
		available: 0,
		interestRate: 0,
		status: "Active",
		openedOn: "2019-03-12"
	},
	{
		id: "a_003",
		accountNo: "01-44210-003",
		type: "Fixed Deposit",
		balance: 12e4,
		available: 0,
		interestRate: 10.25,
		status: "Active",
		openedOn: "2024-01-08"
	}
];
myAccounts[0];
var myLoans = [{
	id: "l_001",
	accountNo: "LN-2024-0142",
	product: "Development Loan",
	principal: 4e5,
	outstanding: 268400,
	paid: 131600,
	nextPaymentAmount: 14850,
	nextPaymentDate: "2025-03-05",
	stage: "Active",
	daysOverdue: 0,
	guarantors: [{
		memberName: "Brian Otieno",
		pledgedAmount: 2e5,
		status: "Accepted"
	}, {
		memberName: "Felix Maina",
		pledgedAmount: 2e5,
		status: "Accepted"
	}],
	disbursedOn: "2024-04-18",
	termMonths: 36,
	monthsPaid: 10,
	rate: 13
}];
[
	{
		id: "t_001",
		date: "2025-02-13T09:30:00",
		description: "Deposit via M-Pesa",
		accountId: "a_001",
		category: "Deposit",
		amount: 12e3,
		status: "Completed",
		reference: "MPE7K2L9XQ"
	},
	{
		id: "t_002",
		date: "2025-02-10T16:33:00",
		description: "Share capital top-up",
		accountId: "a_002",
		category: "Share Capital",
		amount: 5e3,
		status: "Completed",
		reference: "MPE7H1A2VR"
	},
	{
		id: "t_003",
		date: "2025-02-05T08:15:00",
		description: "Loan repayment — Development",
		accountId: "a_001",
		category: "Loan Repayment",
		amount: -14850,
		status: "Completed",
		reference: "LN0142-FEB"
	},
	{
		id: "t_004",
		date: "2025-02-01T12:00:00",
		description: "Interest posting",
		accountId: "a_001",
		category: "Interest",
		amount: 998,
		status: "Completed"
	},
	{
		id: "t_005",
		date: "2025-01-28T11:42:00",
		description: "Withdrawal to M-Pesa",
		accountId: "a_001",
		category: "Withdrawal",
		amount: -6e3,
		status: "Completed",
		reference: "MPE6Q9N3ZD"
	},
	{
		id: "t_006",
		date: "2025-01-22T07:50:00",
		description: "Salary credit",
		accountId: "a_001",
		category: "Deposit",
		amount: 78e3,
		status: "Completed"
	},
	{
		id: "t_007",
		date: "2025-01-15T19:11:00",
		description: "Withdrawal to M-Pesa",
		accountId: "a_001",
		category: "Withdrawal",
		amount: -3500,
		status: "Failed",
		reference: "MPE6L4F8KB"
	},
	{
		id: "t_008",
		date: "2025-01-05T08:20:00",
		description: "Loan repayment — Development",
		accountId: "a_001",
		category: "Loan Repayment",
		amount: -14850,
		status: "Completed",
		reference: "LN0142-JAN"
	}
].slice(0, 5);
var guarantorRequests = [{
	id: "gr_001",
	fromMemberName: "Brian Otieno",
	fromMemberNo: "TJS-00187",
	loanProduct: "School Fees Loan",
	loanAmount: 2e5,
	pledgeAmount: 1e5,
	termMonths: 18,
	requestedAt: "2025-02-12T16:18:00",
	status: "Pending"
}, {
	id: "gr_002",
	fromMemberName: "Grace Wambui",
	fromMemberNo: "TJS-00501",
	loanProduct: "Emergency Loan",
	loanAmount: 5e4,
	pledgeAmount: 5e4,
	termMonths: 6,
	requestedAt: "2025-02-09T08:11:00",
	status: "Pending"
}];
var availableStatements = [
	{
		id: "st_2025_01",
		label: "January 2025",
		from: "2025-01-01",
		to: "2025-01-31"
	},
	{
		id: "st_2024_12",
		label: "December 2024",
		from: "2024-12-01",
		to: "2024-12-31"
	},
	{
		id: "st_2024_11",
		label: "November 2024",
		from: "2024-11-01",
		to: "2024-11-30"
	},
	{
		id: "st_2024_10",
		label: "October 2024",
		from: "2024-10-01",
		to: "2024-10-31"
	},
	{
		id: "st_2024_09",
		label: "September 2024",
		from: "2024-09-01",
		to: "2024-09-30"
	},
	{
		id: "st_2024_08",
		label: "August 2024",
		from: "2024-08-01",
		to: "2024-08-31"
	}
];
myAccounts.filter((a) => a.type === "Savings").reduce((s, a) => s + a.balance, 0);
myLoans.find((l) => l.stage === "Active" || l.stage === "Arrears" || l.stage === "Disbursed");
//#endregion
export { currentMember as n, guarantorRequests as r, availableStatements as t };
