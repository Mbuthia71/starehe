import { n as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { N as HeartHandshake } from "./_libs/lucide-react.mjs";
import { t as EmptyState } from "./_ssr/EmptyState-DoXKeFW-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.withdraw-B1pLigVZ.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow",
				children: "Coming soon"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-1 text-3xl font-semibold tracking-tight",
				children: "Chapter contributions."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Contribute to chapter events, reunions and bursary drives."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "card-elev",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				icon: HeartHandshake,
				title: "We're building this next",
				description: "This part of the Old Starehian Society network is on the roadmap. Watch the Activity feed for updates."
			})
		})]
	});
}
//#endregion
export { Page as component };
