//#region node_modules/.nitro/vite/services/ssr/assets/siohioma-logo-DkFN5Et8.js
var siohioma_logo_default = "/assets/siohioma-logo-BTZxRCjr.png";
//#endregion
export { siohioma_logo_default as t };
