import { n as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { C as MapPin, Q as Building2, Z as Calendar, r as Users } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.groups-Lkf0jYzP.js
var import_jsx_runtime = require_jsx_runtime();
var chapters = [
	{
		id: "nbo",
		name: "OSS Nairobi Chapter",
		members: 2140,
		city: "Nairobi",
		nextEvent: "Chapter dinner · Sat 21 Nov"
	},
	{
		id: "mba",
		name: "OSS Mombasa Chapter",
		members: 312,
		city: "Mombasa",
		nextEvent: "Beach clean-up · Sat 05 Dec"
	},
	{
		id: "lon",
		name: "OSS London Chapter",
		members: 187,
		city: "London, UK",
		nextEvent: "Networking mixer · Fri 27 Nov"
	},
	{
		id: "yr08",
		name: "Class of 2008",
		members: 246,
		city: "Global",
		nextEvent: "20-year reunion planning call"
	},
	{
		id: "yr13",
		name: "Class of 2013",
		members: 231,
		city: "Global",
		nextEvent: "Career panel · online"
	},
	{
		id: "grf",
		name: "Griffin House Alumni",
		members: 1120,
		city: "Global",
		nextEvent: "House quiz night · Dec 12"
	}
];
function Chapters() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "label-eyebrow",
				children: "Alumni chapters"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "display mt-1 text-3xl font-semibold tracking-tight",
				children: "Find your circle."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Chapters by city, class year and house. Join one to see events and posts."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: chapters.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				transition: {
					duration: .35,
					delay: i * .04
				},
				className: "card-elev p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid size-11 shrink-0 place-items-center rounded-2xl bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "truncate text-sm font-semibold text-foreground",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-3" }),
										" ",
										c.members.toLocaleString(),
										" Old Starehians"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3" }),
										" ",
										c.city
									]
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between rounded-xl bg-muted/50 px-3 py-2 text-[11px] text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5 text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "size-3.5" }), " Next"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate font-medium",
							children: c.nextEvent
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "mt-4 w-full rounded-xl bg-primary py-2 text-xs font-semibold text-primary-foreground hover:brightness-110",
						children: "Join chapter"
					})
				]
			}, c.id))
		})]
	});
}
//#endregion
export { Chapters as component };
