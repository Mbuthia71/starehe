import { o as __toESM } from "./_runtime.mjs";
import { i as getStoredMember } from "./_ssr/auth-DetQxYHL.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react, t as useMutation } from "./_libs/react+tanstack__react-query.mjs";
import { d as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as motion } from "./_libs/framer-motion.mjs";
import { E as ArrowLeft, S as Check, i as User } from "./_libs/lucide-react.mjs";
import { t as KES } from "./_ssr/format-R9Jywg6X.mjs";
import { l as transferToMember, r as getSelfAccounts, s as lookupAccountByNumber } from "./_ssr/selfApi-DGdOs9vm.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app.transfer-CQnbziX1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Transfer() {
	const [isMounted, setIsMounted] = (0, import_react.useState)(false);
	const [stage, setStage] = (0, import_react.useState)("form");
	const [amount, setAmount] = (0, import_react.useState)(50);
	const [fromAccountId, setFromAccountId] = (0, import_react.useState)("");
	const [toAccountNo, setToAccountNo] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [txRef, setTxRef] = (0, import_react.useState)("");
	const [destAccount, setDestAccount] = (0, import_react.useState)(null);
	const [lookupLoading, setLookupLoading] = (0, import_react.useState)(false);
	getStoredMember();
	const { data: accounts = [] } = useQuery({
		queryKey: ["selfAccounts"],
		queryFn: getSelfAccounts
	});
	const savings = accounts.filter((a) => a.type === "Savings" || a.type === "Junior Savings");
	const selectedAccount = savings.find((a) => a.id === fromAccountId) || savings[0];
	const lookup = useMutation({
		mutationFn: () => lookupAccountByNumber(toAccountNo),
		onSuccess: (data) => {
			setDestAccount(data);
			if (data.id === selectedAccount?.id) {
				toast.error("Cannot transfer to your own account");
				setDestAccount(null);
			}
		},
		onError: (e) => {
			toast.error(e.message);
			setDestAccount(null);
		}
	});
	const transfer = useMutation({
		mutationFn: async () => {
			if (!destAccount) throw new Error("Please verify destination account");
			if (destAccount.id === selectedAccount?.id) throw new Error("Cannot transfer to same account");
			return await transferToMember(selectedAccount?.id || "", destAccount.id, amount, description, destAccount.clientId);
		},
		onSuccess: (data) => {
			setTxRef(data.resourceId || "TRF" + Math.random().toString(36).slice(2, 8).toUpperCase());
			setStage("success");
		},
		onError: (e) => toast.error(e.message)
	});
	(0, import_react.useEffect)(() => {
		setIsMounted(true);
	}, []);
	if (!isMounted) return null;
	if (savings.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-lg font-medium",
			children: "No savings accounts found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 text-sm text-muted-foreground",
			children: "Contact admin to open a savings account"
		})]
	});
	const handleAccountLookup = () => {
		if (toAccountNo.length >= 3) {
			setLookupLoading(true);
			lookup.mutate();
			setTimeout(() => setLookupLoading(false), 500);
		}
	};
	if (stage === "success") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			scale: .96
		},
		animate: {
			opacity: 1,
			scale: 1
		},
		transition: {
			duration: .45,
			ease: [
				.22,
				1,
				.36,
				1
			]
		},
		className: "card-elev flex flex-col items-center p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
				initial: { scale: 0 },
				animate: { scale: 1 },
				transition: {
					delay: .1,
					type: "spring",
					stiffness: 240,
					damping: 14
				},
				className: "grid size-16 place-items-center rounded-full bg-success-soft text-success",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-7" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "display mt-5 text-2xl font-semibold tracking-tight",
				children: "Transfer successful"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "num display mt-3 text-3xl font-semibold",
				children: KES(amount)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Internal transfer completed"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 w-full rounded-2xl bg-muted/60 px-4 py-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] uppercase tracking-wider text-muted-foreground",
					children: "Reference"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "num mt-1 text-sm font-medium",
					children: txRef
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-6 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground",
				children: "Done"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "grid size-9 place-items-center rounded-full bg-muted active:scale-95",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "label-eyebrow",
					children: "Transfer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-2xl font-semibold tracking-tight",
					children: "To Member"
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev p-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "label-eyebrow",
						children: "Amount"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "num display mt-3 text-5xl font-semibold tracking-tight",
						children: KES(amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 50,
						max: Math.max(50, selectedAccount?.available ?? 50),
						step: 50,
						value: amount,
						onChange: (e) => setAmount(Number(e.target.value)),
						className: "mt-6 w-full accent-[color:var(--primary)]"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-elev divide-y divide-border/60 p-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-wider text-muted-foreground",
							children: "From"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: fromAccountId,
							onChange: (e) => setFromAccountId(e.target.value),
							className: "mt-1 w-full bg-transparent text-sm font-medium focus:outline-none",
							children: savings.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: a.id,
								children: [
									a.type,
									" · ",
									a.accountNo,
									" · ",
									KES(a.available),
									" available"
								]
							}, a.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-5 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] uppercase tracking-wider text-muted-foreground",
								children: "To Account Number"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								value: toAccountNo,
								onChange: (e) => {
									setToAccountNo(e.target.value);
									setDestAccount(null);
								},
								onKeyDown: (e) => {
									if (e.key === "Enter") {
										e.preventDefault();
										handleAccountLookup();
									}
								},
								placeholder: "e.g. 000000001",
								className: "mt-1 w-full bg-transparent text-sm font-medium focus:outline-none"
							}),
							destAccount && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 rounded-xl bg-success-soft/30 p-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4 text-success" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-medium text-foreground",
											children: destAccount.clientName
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted-foreground",
											children: [
												destAccount.type,
												" · ",
												destAccount.accountNo
											]
										})]
									})]
								})
							}),
							lookupLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 text-xs text-muted-foreground",
								children: "Looking up account..."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-wider text-muted-foreground",
							children: "Description (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							value: description,
							onChange: (e) => setDescription(e.target.value),
							placeholder: "What's this for?",
							className: "mt-1 w-full bg-transparent text-sm font-medium focus:outline-none"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => transfer.mutate(),
				disabled: transfer.isPending || !selectedAccount || !toAccountNo,
				className: "w-full rounded-full bg-primary px-5 py-4 text-sm font-semibold text-primary-foreground active:scale-[0.98] disabled:opacity-50",
				children: transfer.isPending ? "Processing…" : `Send ${KES(amount)}`
			})
		]
	});
}
//#endregion
export { Transfer as component };
