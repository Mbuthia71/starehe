//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BsVN8mln.js
var tsrStartManifest = () => ({
	routes: {
		__root__: {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/__root.tsx",
			children: [
				"/_app",
				"/auth/login",
				"/auth/otp",
				"/auth/pin-setup"
			],
			assets: void 0,
			preloads: ["/assets/index-DsZu0xWi.js", "/assets/jsx-runtime-DnlWeMvz.js"]
		},
		"/_app": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.tsx",
			children: [
				"/_app/accounts",
				"/_app/guarantors",
				"/_app/loans",
				"/_app/profile",
				"/_app/statements",
				"/_app/withdraw",
				"/_app/"
			],
			assets: void 0,
			preloads: [
				"/assets/_app-iw5V6Qj_.js",
				"/assets/auth-CeFygdtW.js",
				"/assets/createLucideIcon-CPOOcYn_.js",
				"/assets/banknote-BOMg5vhb.js",
				"/assets/siohioma-logo.png.asset-BDtJmCx-.js"
			]
		},
		"/_app/accounts": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.accounts.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.accounts-BsHPHzpn.js",
				"/assets/selfApi-DuzGnMIz.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/_app/guarantors": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.guarantors.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.guarantors-C4CKQbz0.js",
				"/assets/check-DisOH-Hr.js",
				"/assets/users-B2L7i_p8.js",
				"/assets/EmptyState-CX6nppw4.js",
				"/assets/api-DIvt6uQQ.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/_app/loans": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.loans.tsx",
			children: ["/_app/loans/apply"],
			assets: void 0,
			preloads: [
				"/assets/_app.loans-D4nm5w4v.js",
				"/assets/useMutation-Dv4Szsob.js",
				"/assets/selfApi-DuzGnMIz.js",
				"/assets/StatusPill-DnckxUbZ.js",
				"/assets/chevron-right-BaJECq_P.js",
				"/assets/circle-plus-C38gbffT.js",
				"/assets/EmptyState-CX6nppw4.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/_app/profile": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.profile.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.profile-CytQ51Mw.js",
				"/assets/StatusPill-DnckxUbZ.js",
				"/assets/chevron-right-BaJECq_P.js",
				"/assets/users-B2L7i_p8.js",
				"/assets/api-DIvt6uQQ.js"
			]
		},
		"/_app/statements": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.statements.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.statements-yzDYORZj.js",
				"/assets/file-text-DePsHLEC.js",
				"/assets/api-DIvt6uQQ.js"
			]
		},
		"/_app/withdraw": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.withdraw.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.withdraw-DU7UImlL.js",
				"/assets/useMutation-Dv4Szsob.js",
				"/assets/selfApi-DuzGnMIz.js",
				"/assets/arrow-left-CD89c06s.js",
				"/assets/check-DisOH-Hr.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/auth/login": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/auth.login.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/auth.login-B9UmuG2I.js",
				"/assets/auth-CeFygdtW.js",
				"/assets/createLucideIcon-CPOOcYn_.js",
				"/assets/siohioma-logo.png.asset-BDtJmCx-.js"
			]
		},
		"/auth/otp": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/auth.otp.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/auth.otp-DAlhwYKH.js", "/assets/siohioma-logo.png.asset-BDtJmCx-.js"]
		},
		"/auth/pin-setup": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/auth.pin-setup.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/auth.pin-setup-C75kfui1.js", "/assets/siohioma-logo.png.asset-BDtJmCx-.js"]
		},
		"/_app/": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.index.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.index-CEEeoXjP.js",
				"/assets/selfApi-DuzGnMIz.js",
				"/assets/chevron-right-BaJECq_P.js",
				"/assets/circle-plus-C38gbffT.js",
				"/assets/file-text-DePsHLEC.js",
				"/assets/format-DFUkzCo6.js"
			]
		},
		"/_app/loans/apply": {
			filePath: "C:/Users/Administrator/banking-project/kindred-core-admin/src/routes/_app.loans.apply.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.loans.apply-B9tbfFC2.js",
				"/assets/arrow-left-CD89c06s.js",
				"/assets/check-DisOH-Hr.js"
			]
		}
	},
	clientEntry: "/assets/index-DsZu0xWi.js"
});
//#endregion
export { tsrStartManifest };
