import { o as __toESM } from "../_runtime.mjs";
import { o as login } from "./auth-BuJnZt4q.mjs";
import { t as siohioma_logo_png_asset_default } from "./siohioma-logo.png.asset-DrWRrNAy.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { p as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as motion } from "../_libs/framer-motion.mjs";
import { v as CircleAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth.login-BmmMPZQp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const navigate = useNavigate();
	const [username, setUsername] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!username.trim() || !password.trim()) return;
		setLoading(true);
		setError("");
		try {
			await login(username.trim(), password);
			navigate({ to: "/" });
		} catch (err) {
			setError(err.message || "Login failed");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-screen w-full max-w-[480px] flex-col bg-background px-6 pb-10 pt-12",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.img, {
				initial: {
					opacity: 0,
					y: 8
				},
				animate: {
					opacity: 1,
					y: 0
				},
				src: siohioma_logo_png_asset_default.url,
				alt: "Siohioma",
				className: "h-10 w-auto self-start"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "display text-4xl font-semibold tracking-tight",
					children: "Welcome back."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Sign in with your Siohioma username and password."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: handleSubmit,
				className: "mt-10 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-wider text-muted-foreground",
							children: "Username"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: username,
							onChange: (e) => setUsername(e.target.value),
							autoComplete: "username",
							placeholder: "e.g. aisha.mwangi",
							className: "mt-1 w-full rounded-2xl border border-border bg-card px-4 py-3.5 text-base focus:outline-none focus:ring-2 focus:ring-ring/40"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] uppercase tracking-wider text-muted-foreground",
							children: "Password"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "password",
							value: password,
							onChange: (e) => setPassword(e.target.value),
							autoComplete: "current-password",
							placeholder: "Your password",
							className: "mt-1 w-full rounded-2xl border border-border bg-card px-4 py-3.5 text-base focus:outline-none focus:ring-2 focus:ring-ring/40"
						})]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 rounded-xl bg-danger-soft px-4 py-3 text-sm text-danger",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-4 shrink-0" }), error]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						disabled: loading || !username || !password,
						className: "mt-6 w-full rounded-full bg-primary px-5 py-4 text-sm font-semibold text-primary-foreground active:scale-[0.98] disabled:opacity-50",
						children: loading ? "Signing in…" : "Sign in"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-auto pt-10 text-center text-xs text-muted-foreground",
				children: "Your credentials were provided by the SACCO admin."
			})
		]
	});
}
//#endregion
export { Login as component };
