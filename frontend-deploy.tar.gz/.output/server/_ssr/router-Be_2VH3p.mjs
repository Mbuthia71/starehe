import { o as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { c as lazyRouteComponent, d as Link, h as useRouter, l as createFileRoute, n as Scripts, o as createRouter, r as HeadContent, s as Outlet, u as createRootRouteWithContext } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Route$34 } from "../_app.business._id-B_-AGwou.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Be_2VH3p.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-Be9IBxnp.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$33 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Old Starehian Society · Alumni Network" },
			{
				name: "description",
				content: "The Old Starehian Society — reconnect with fellow alumni of Starehe Boys' Centre, discover the directory, join chapter groups and follow community activity."
			},
			{
				name: "author",
				content: "Old Starehian Society"
			},
			{
				property: "og:title",
				content: "Old Starehian Society · Alumni Network"
			},
			{
				property: "og:description",
				content: "Old Starehian Society Alumni Network"
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			},
			{
				name: "twitter:site",
				content: "@OldStarehian"
			},
			{
				name: "theme-color",
				content: "#0a0a0a"
			},
			{
				name: "mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-status-bar-style",
				content: "default"
			},
			{
				name: "apple-mobile-web-app-title",
				content: "Old Starehian Society"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;0,800;0,900;1,700;1,900&family=Bodoni+Moda:ital,wght@0,700;0,800;0,900;1,700&family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@500;600&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$33.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
			richColors: true,
			position: "top-center"
		})]
	});
}
var $$splitComponentImporter$32 = () => import("../_app-f0jYG2QJ.mjs");
var Route$32 = createFileRoute("/_app")({ component: lazyRouteComponent($$splitComponentImporter$32, "component") });
var $$splitComponentImporter$31 = () => import("../_admin-C-dCCDlu.mjs");
var Route$31 = createFileRoute("/_admin")({ component: lazyRouteComponent($$splitComponentImporter$31, "component") });
var $$splitComponentImporter$30 = () => import("../_app.index-DK6yBAHq.mjs");
var Route$30 = createFileRoute("/_app/")({ component: lazyRouteComponent($$splitComponentImporter$30, "component") });
var $$splitComponentImporter$29 = () => import("./p._id-CJACjAT-.mjs");
var Route$29 = createFileRoute("/p/$id")({
	component: lazyRouteComponent($$splitComponentImporter$29, "component"),
	head: ({ params }) => ({ meta: [{ title: `Old Starehian · Member ${params.id}` }, {
		name: "description",
		content: "Public member profile on the Old Starehian Society alumni network."
	}] })
});
var $$splitComponentImporter$28 = () => import("./auth.pin-setup-QhVxbH58.mjs");
var Route$28 = createFileRoute("/auth/pin-setup")({ component: lazyRouteComponent($$splitComponentImporter$28, "component") });
var $$splitComponentImporter$27 = () => import("./auth.otp-CUExhoYI.mjs");
var Route$27 = createFileRoute("/auth/otp")({ component: lazyRouteComponent($$splitComponentImporter$27, "component") });
var $$splitComponentImporter$26 = () => import("./auth.login-BPcrlPaR.mjs");
var Route$26 = createFileRoute("/auth/login")({ component: lazyRouteComponent($$splitComponentImporter$26, "component") });
var $$splitComponentImporter$25 = () => import("../_app.withdraw-B1pLigVZ.mjs");
var Route$25 = createFileRoute("/_app/withdraw")({ component: lazyRouteComponent($$splitComponentImporter$25, "component") });
var $$splitComponentImporter$24 = () => import("../_app.transfer-CUdPTnLY.mjs");
var Route$24 = createFileRoute("/_app/transfer")({ component: lazyRouteComponent($$splitComponentImporter$24, "component") });
var $$splitComponentImporter$23 = () => import("../_app.tenders-CI8vq_UD.mjs");
var Route$23 = createFileRoute("/_app/tenders")({ component: lazyRouteComponent($$splitComponentImporter$23, "component") });
var $$splitComponentImporter$22 = () => import("../_app.statements-DyQhv-vs.mjs");
var Route$22 = createFileRoute("/_app/statements")({ component: lazyRouteComponent($$splitComponentImporter$22, "component") });
var $$splitComponentImporter$21 = () => import("../_app.staff-DiyVMOFE.mjs");
var Route$21 = createFileRoute("/_app/staff")({ component: lazyRouteComponent($$splitComponentImporter$21, "component") });
var $$splitComponentImporter$20 = () => import("../_app.sponsorships-BnNjhs0j.mjs");
var Route$20 = createFileRoute("/_app/sponsorships")({ component: lazyRouteComponent($$splitComponentImporter$20, "component") });
var $$splitComponentImporter$19 = () => import("../_app.profile-ByBdVcp-.mjs");
var Route$19 = createFileRoute("/_app/profile")({ component: lazyRouteComponent($$splitComponentImporter$19, "component") });
var $$splitComponentImporter$18 = () => import("../_app.products-eVqUmOa4.mjs");
var Route$18 = createFileRoute("/_app/products")({ component: lazyRouteComponent($$splitComponentImporter$18, "component") });
var $$splitComponentImporter$17 = () => import("../_app.offers-CHpGk1xB.mjs");
var Route$17 = createFileRoute("/_app/offers")({ component: lazyRouteComponent($$splitComponentImporter$17, "component") });
var $$splitComponentImporter$16 = () => import("../_app.loans-DdPxP-qC.mjs");
var Route$16 = createFileRoute("/_app/loans")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("../_app.jobs-BDfP_fW6.mjs");
var Route$15 = createFileRoute("/_app/jobs")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("../_app.guarantors-CDfWVMuk.mjs");
var Route$14 = createFileRoute("/_app/guarantors")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("../_app.groups-Lkf0jYzP.mjs");
var Route$13 = createFileRoute("/_app/groups")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("../_app.gl-accounts-DOAV65GY.mjs");
var Route$12 = createFileRoute("/_app/gl-accounts")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("../_app.class-groups-BjJJJ4Cl.mjs");
var Route$11 = createFileRoute("/_app/class-groups")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("../_app.cards-akp1l_L4.mjs");
var Route$10 = createFileRoute("/_app/cards")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("../_app.business-DtdxqZVr.mjs");
var Route$9 = createFileRoute("/_app/business")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("../_app.accounts-BqmZIcaR.mjs");
var Route$8 = createFileRoute("/_app/accounts")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("../_app.loans.apply-CSmnvMuz.mjs");
var Route$7 = createFileRoute("/_app/loans/apply")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("../_app.dev.statement-Bz0MZXA9.mjs");
var Route$6 = createFileRoute("/_app/dev/statement")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("../_app.dev.emails-n92_ZBmd.mjs");
var Route$5 = createFileRoute("/_app/dev/emails")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("../_admin.admin.transactions-Ie7QtRc_.mjs");
var Route$4 = createFileRoute("/_admin/admin/transactions")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("../_admin.admin.members-BxTa6G0e.mjs");
var Route$3 = createFileRoute("/_admin/admin/members")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("../_admin.admin.loans-D7HCjbz6.mjs");
var Route$2 = createFileRoute("/_admin/admin/loans")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("../_admin.admin.dashboard-BpEo0M5L.mjs");
var Route$1 = createFileRoute("/_admin/admin/dashboard")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("../_admin.admin.approvals-BYFqjp-E.mjs");
var Route = createFileRoute("/_admin/admin/approvals")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var AppRoute = Route$32.update({
	id: "/_app",
	getParentRoute: () => Route$33
});
var AdminRoute = Route$31.update({
	id: "/_admin",
	getParentRoute: () => Route$33
});
var AppIndexRoute = Route$30.update({
	id: "/",
	path: "/",
	getParentRoute: () => AppRoute
});
var PIdRoute = Route$29.update({
	id: "/p/$id",
	path: "/p/$id",
	getParentRoute: () => Route$33
});
var AuthPinSetupRoute = Route$28.update({
	id: "/auth/pin-setup",
	path: "/auth/pin-setup",
	getParentRoute: () => Route$33
});
var AuthOtpRoute = Route$27.update({
	id: "/auth/otp",
	path: "/auth/otp",
	getParentRoute: () => Route$33
});
var AuthLoginRoute = Route$26.update({
	id: "/auth/login",
	path: "/auth/login",
	getParentRoute: () => Route$33
});
var AppWithdrawRoute = Route$25.update({
	id: "/withdraw",
	path: "/withdraw",
	getParentRoute: () => AppRoute
});
var AppTransferRoute = Route$24.update({
	id: "/transfer",
	path: "/transfer",
	getParentRoute: () => AppRoute
});
var AppTendersRoute = Route$23.update({
	id: "/tenders",
	path: "/tenders",
	getParentRoute: () => AppRoute
});
var AppStatementsRoute = Route$22.update({
	id: "/statements",
	path: "/statements",
	getParentRoute: () => AppRoute
});
var AppStaffRoute = Route$21.update({
	id: "/staff",
	path: "/staff",
	getParentRoute: () => AppRoute
});
var AppSponsorshipsRoute = Route$20.update({
	id: "/sponsorships",
	path: "/sponsorships",
	getParentRoute: () => AppRoute
});
var AppProfileRoute = Route$19.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => AppRoute
});
var AppProductsRoute = Route$18.update({
	id: "/products",
	path: "/products",
	getParentRoute: () => AppRoute
});
var AppOffersRoute = Route$17.update({
	id: "/offers",
	path: "/offers",
	getParentRoute: () => AppRoute
});
var AppLoansRoute = Route$16.update({
	id: "/loans",
	path: "/loans",
	getParentRoute: () => AppRoute
});
var AppJobsRoute = Route$15.update({
	id: "/jobs",
	path: "/jobs",
	getParentRoute: () => AppRoute
});
var AppGuarantorsRoute = Route$14.update({
	id: "/guarantors",
	path: "/guarantors",
	getParentRoute: () => AppRoute
});
var AppGroupsRoute = Route$13.update({
	id: "/groups",
	path: "/groups",
	getParentRoute: () => AppRoute
});
var AppGlAccountsRoute = Route$12.update({
	id: "/gl-accounts",
	path: "/gl-accounts",
	getParentRoute: () => AppRoute
});
var AppClassGroupsRoute = Route$11.update({
	id: "/class-groups",
	path: "/class-groups",
	getParentRoute: () => AppRoute
});
var AppCardsRoute = Route$10.update({
	id: "/cards",
	path: "/cards",
	getParentRoute: () => AppRoute
});
var AppBusinessRoute = Route$9.update({
	id: "/business",
	path: "/business",
	getParentRoute: () => AppRoute
});
var AppAccountsRoute = Route$8.update({
	id: "/accounts",
	path: "/accounts",
	getParentRoute: () => AppRoute
});
var AppLoansApplyRoute = Route$7.update({
	id: "/apply",
	path: "/apply",
	getParentRoute: () => AppLoansRoute
});
var AppDevStatementRoute = Route$6.update({
	id: "/dev/statement",
	path: "/dev/statement",
	getParentRoute: () => AppRoute
});
var AppDevEmailsRoute = Route$5.update({
	id: "/dev/emails",
	path: "/dev/emails",
	getParentRoute: () => AppRoute
});
var AppBusinessIdRoute = Route$34.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AppBusinessRoute
});
var AdminAdminTransactionsRoute = Route$4.update({
	id: "/admin/transactions",
	path: "/admin/transactions",
	getParentRoute: () => AdminRoute
});
var AdminAdminMembersRoute = Route$3.update({
	id: "/admin/members",
	path: "/admin/members",
	getParentRoute: () => AdminRoute
});
var AdminAdminLoansRoute = Route$2.update({
	id: "/admin/loans",
	path: "/admin/loans",
	getParentRoute: () => AdminRoute
});
var AdminAdminDashboardRoute = Route$1.update({
	id: "/admin/dashboard",
	path: "/admin/dashboard",
	getParentRoute: () => AdminRoute
});
var AdminRouteChildren = {
	AdminAdminApprovalsRoute: Route.update({
		id: "/admin/approvals",
		path: "/admin/approvals",
		getParentRoute: () => AdminRoute
	}),
	AdminAdminDashboardRoute,
	AdminAdminLoansRoute,
	AdminAdminMembersRoute,
	AdminAdminTransactionsRoute
};
var AdminRouteWithChildren = AdminRoute._addFileChildren(AdminRouteChildren);
var AppBusinessRouteChildren = { AppBusinessIdRoute };
var AppBusinessRouteWithChildren = AppBusinessRoute._addFileChildren(AppBusinessRouteChildren);
var AppLoansRouteChildren = { AppLoansApplyRoute };
var AppRouteChildren = {
	AppAccountsRoute,
	AppBusinessRoute: AppBusinessRouteWithChildren,
	AppCardsRoute,
	AppClassGroupsRoute,
	AppGlAccountsRoute,
	AppGroupsRoute,
	AppGuarantorsRoute,
	AppJobsRoute,
	AppLoansRoute: AppLoansRoute._addFileChildren(AppLoansRouteChildren),
	AppOffersRoute,
	AppProductsRoute,
	AppProfileRoute,
	AppSponsorshipsRoute,
	AppStaffRoute,
	AppStatementsRoute,
	AppTendersRoute,
	AppTransferRoute,
	AppWithdrawRoute,
	AppIndexRoute,
	AppDevEmailsRoute,
	AppDevStatementRoute
};
var rootRouteChildren = {
	AdminRoute: AdminRouteWithChildren,
	AppRoute: AppRoute._addFileChildren(AppRouteChildren),
	AuthLoginRoute,
	AuthOtpRoute,
	AuthPinSetupRoute,
	PIdRoute
};
var routeTree = Route$33._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
