//#region node_modules/.nitro/vite/services/ssr/assets/format-R9Jywg6X.js
var KES = (n, opts = {}) => {
	const { compact, decimals = 0 } = opts;
	if (compact && Math.abs(n) >= 1e6) return `KES ${(n / 1e6).toFixed(1)}M`;
	if (compact && Math.abs(n) >= 1e3) return `KES ${(n / 1e3).toFixed(1)}K`;
	return `KES ${n.toLocaleString("en-KE", {
		minimumFractionDigits: decimals,
		maximumFractionDigits: decimals
	})}`;
};
var formatDate = (iso, withTime = false) => {
	const d = new Date(iso);
	const date = d.toLocaleDateString("en-GB", {
		day: "2-digit",
		month: "short",
		year: "numeric"
	});
	if (!withTime) return date;
	return `${date} · ${d.toLocaleTimeString("en-GB", {
		hour: "2-digit",
		minute: "2-digit"
	})}`;
};
//#endregion
export { formatDate as n, KES as t };
