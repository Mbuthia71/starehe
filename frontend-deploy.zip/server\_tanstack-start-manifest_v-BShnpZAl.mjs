//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BShnpZAl.js
var tsrStartManifest = () => ({
	routes: {
		__root__: {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/__root.tsx",
			children: [
				"/_admin",
				"/_app",
				"/auth/login",
				"/auth/otp",
				"/auth/pin-setup",
				"/p/$id"
			],
			assets: void 0,
			preloads: [
				"/assets/index-DoqN2nBR.js",
				"/assets/jsx-runtime-DnlWeMvz.js",
				"/assets/react-dom-DriRPPLg.js"
			]
		},
		"/_admin": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_admin.tsx",
			children: [
				"/_admin/admin/approvals",
				"/_admin/admin/dashboard",
				"/_admin/admin/loans",
				"/_admin/admin/members",
				"/_admin/admin/transactions"
			],
			assets: void 0,
			preloads: [
				"/assets/_admin-BK3ytWvk.js",
				"/assets/bell-zynUfiQG.js",
				"/assets/AnimatePresence-BMxtdY_u.js",
				"/assets/proxy-BckV1rm6.js",
				"/assets/activity-UnUcW5q5.js",
				"/assets/chart-column-BYlJfrgF.js",
				"/assets/circle-check-big-DqvcrxiE.js",
				"/assets/log-out-DPTk1-RN.js",
				"/assets/user-plus-DF03EV4l.js",
				"/assets/users-B2L7i_p8.js",
				"/assets/siohioma-logo-zm9kMDod.js",
				"/assets/auth-BjSvZu5U.js"
			]
		},
		"/_app": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.tsx",
			children: [
				"/_app/accounts",
				"/_app/business",
				"/_app/cards",
				"/_app/class-groups",
				"/_app/gl-accounts",
				"/_app/groups",
				"/_app/guarantors",
				"/_app/jobs",
				"/_app/loans",
				"/_app/offers",
				"/_app/products",
				"/_app/profile",
				"/_app/sponsorships",
				"/_app/staff",
				"/_app/statements",
				"/_app/tenders",
				"/_app/transfer",
				"/_app/withdraw",
				"/_app/",
				"/_app/dev/emails",
				"/_app/dev/statement"
			],
			assets: void 0,
			preloads: [
				"/assets/_app--fre6zW-.js",
				"/assets/bell-zynUfiQG.js",
				"/assets/AnimatePresence-BMxtdY_u.js",
				"/assets/proxy-BckV1rm6.js",
				"/assets/createLucideIcon-CPOOcYn_.js",
				"/assets/briefcase-yB5xLT9O.js",
				"/assets/building-2-CqnOXMZO.js",
				"/assets/file-text-DePsHLEC.js",
				"/assets/graduation-cap-r8ZBlGBy.js",
				"/assets/log-out-DPTk1-RN.js",
				"/assets/search-DdV7Kybb.js",
				"/assets/tag-DHuEKKPa.js",
				"/assets/users-B2L7i_p8.js",
				"/assets/x-CKMzcoaY.js",
				"/assets/siohioma-logo-zm9kMDod.js",
				"/assets/auth-BjSvZu5U.js"
			]
		},
		"/_app/accounts": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.accounts.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.accounts-Blk7tYCR.js",
				"/assets/map-pin-CWfj2Ivd.js",
				"/assets/user-plus-DF03EV4l.js"
			]
		},
		"/_app/business": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.business.tsx",
			children: ["/_app/business/$id"],
			assets: void 0,
			preloads: [
				"/assets/_app.business-Begl1xxv.js",
				"/assets/arrow-up-right-BOByLv2M.js",
				"/assets/star-4uDpDCTd.js",
				"/assets/filter-HZqTdF1Z.js",
				"/assets/instagram-Dz77x5Nf.js",
				"/assets/map-pin-CWfj2Ivd.js",
				"/assets/phone-DRHchQj0.js",
				"/assets/plus-PcFDA7-L.js"
			]
		},
		"/_app/cards": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.cards.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_app.cards-CZQ-Lj48.js", "/assets/EmptyState-CX6nppw4.js"]
		},
		"/_app/class-groups": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.class-groups.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.class-groups-CuPLG8Qz.js",
				"/assets/arrow-up-right-BOByLv2M.js",
				"/assets/calendar-Cq91mf76.js",
				"/assets/plus-PcFDA7-L.js"
			]
		},
		"/_app/gl-accounts": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.gl-accounts.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_app.gl-accounts-DKnroSY2.js", "/assets/EmptyState-CX6nppw4.js"]
		},
		"/_app/groups": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.groups.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.groups-CktYHt5-.js",
				"/assets/calendar-Cq91mf76.js",
				"/assets/map-pin-CWfj2Ivd.js"
			]
		},
		"/_app/guarantors": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.guarantors.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.guarantors-BOJAS062.js",
				"/assets/award-Bm33_ztT.js",
				"/assets/EmptyState-CX6nppw4.js"
			]
		},
		"/_app/jobs": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.jobs.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.jobs-Bw3kd2GB.js",
				"/assets/arrow-up-right-BOByLv2M.js",
				"/assets/calendar-Cq91mf76.js",
				"/assets/dollar-sign-BJIpFPF6.js",
				"/assets/filter-HZqTdF1Z.js",
				"/assets/map-pin-CWfj2Ivd.js",
				"/assets/plus-PcFDA7-L.js"
			]
		},
		"/_app/loans": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.loans.tsx",
			children: ["/_app/loans/apply"],
			assets: void 0,
			preloads: [
				"/assets/_app.loans-PEV44YT0.js",
				"/assets/StatusPill-JelFF9fH.js",
				"/assets/user-plus-DF03EV4l.js",
				"/assets/EmptyState-CX6nppw4.js"
			]
		},
		"/_app/offers": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.offers.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.offers-DHSZT6FL.js",
				"/assets/arrow-up-right-BOByLv2M.js",
				"/assets/calendar-Cq91mf76.js",
				"/assets/filter-HZqTdF1Z.js",
				"/assets/map-pin-CWfj2Ivd.js",
				"/assets/plus-PcFDA7-L.js"
			]
		},
		"/_app/products": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.products.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_app.products-DadNFCy2.js", "/assets/EmptyState-CX6nppw4.js"]
		},
		"/_app/profile": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.profile.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.profile-DopvOj_1.js",
				"/assets/StatusPill-JelFF9fH.js",
				"/assets/award-Bm33_ztT.js",
				"/assets/twitter-RmhNebP0.js",
				"/assets/chevron-right-BaJECq_P.js",
				"/assets/instagram-Dz77x5Nf.js",
				"/assets/key-round-BXa8FdZt.js",
				"/assets/map-pin-CWfj2Ivd.js",
				"/assets/phone-DRHchQj0.js",
				"/assets/shield-check-C1ODzdrU.js"
			]
		},
		"/_app/sponsorships": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.sponsorships.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.sponsorships-B0MVMCCd.js",
				"/assets/arrow-up-right-BOByLv2M.js",
				"/assets/calendar-Cq91mf76.js",
				"/assets/filter-HZqTdF1Z.js",
				"/assets/plus-PcFDA7-L.js"
			]
		},
		"/_app/staff": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.staff.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_app.staff-Tg0mAxKn.js", "/assets/EmptyState-CX6nppw4.js"]
		},
		"/_app/statements": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.statements.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.statements-BFPvSATt.js",
				"/assets/activity-UnUcW5q5.js",
				"/assets/award-Bm33_ztT.js",
				"/assets/calendar-Cq91mf76.js",
				"/assets/message-square-BxrRG2IR.js",
				"/assets/user-plus-DF03EV4l.js"
			]
		},
		"/_app/tenders": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.tenders.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.tenders-BJVoWKFS.js",
				"/assets/arrow-up-right-BOByLv2M.js",
				"/assets/calendar-Cq91mf76.js",
				"/assets/dollar-sign-BJIpFPF6.js",
				"/assets/filter-HZqTdF1Z.js",
				"/assets/map-pin-CWfj2Ivd.js",
				"/assets/plus-PcFDA7-L.js"
			]
		},
		"/_app/transfer": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.transfer.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_app.transfer-DPV3zfR-.js", "/assets/EmptyState-CX6nppw4.js"]
		},
		"/_app/withdraw": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.withdraw.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_app.withdraw-BtElmZcP.js", "/assets/EmptyState-CX6nppw4.js"]
		},
		"/auth/login": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/auth.login.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/auth.login-xqHUtPRM.js",
				"/assets/AnimatePresence-BMxtdY_u.js",
				"/assets/proxy-BckV1rm6.js",
				"/assets/createLucideIcon-CPOOcYn_.js",
				"/assets/circle-alert-CkI1R8ex.js",
				"/assets/siohioma-logo-zm9kMDod.js",
				"/assets/auth-BjSvZu5U.js"
			]
		},
		"/auth/otp": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/auth.otp.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/auth.otp-CBjvUOP4.js",
				"/assets/circle-alert-CkI1R8ex.js",
				"/assets/key-round-BXa8FdZt.js"
			]
		},
		"/auth/pin-setup": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/auth.pin-setup.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/auth.pin-setup-w62O5Yb0.js", "/assets/shield-check-C1ODzdrU.js"]
		},
		"/p/$id": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/p.$id.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/p._id-E-tImg8S.js",
				"/assets/proxy-BckV1rm6.js",
				"/assets/arrow-left-CD89c06s.js",
				"/assets/twitter-RmhNebP0.js",
				"/assets/briefcase-yB5xLT9O.js",
				"/assets/instagram-Dz77x5Nf.js",
				"/assets/graduation-cap-r8ZBlGBy.js",
				"/assets/map-pin-CWfj2Ivd.js",
				"/assets/user-plus-DF03EV4l.js",
				"/assets/siohioma-logo-zm9kMDod.js"
			]
		},
		"/_app/": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.index.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.index-nflOAuTe.js",
				"/assets/activity-UnUcW5q5.js",
				"/assets/arrow-up-right-BOByLv2M.js",
				"/assets/calendar-Cq91mf76.js",
				"/assets/chevron-right-BaJECq_P.js",
				"/assets/message-square-BxrRG2IR.js",
				"/assets/user-plus-DF03EV4l.js"
			]
		},
		"/_admin/admin/approvals": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_admin.admin.approvals.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_admin.admin.approvals-B88M8GNH.js"]
		},
		"/_admin/admin/dashboard": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_admin.admin.dashboard.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_admin.admin.dashboard-BCggXuwd.js"]
		},
		"/_admin/admin/loans": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_admin.admin.loans.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_admin.admin.loans-QdL49Fbh.js"]
		},
		"/_admin/admin/members": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_admin.admin.members.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_admin.admin.members-CZRVinlP.js"]
		},
		"/_admin/admin/transactions": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_admin.admin.transactions.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_admin.admin.transactions-DezZ2UFb.js"]
		},
		"/_app/business/$id": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.business.$id.tsx",
			children: void 0,
			assets: void 0,
			preloads: [
				"/assets/_app.business._id-DFqPBd22.js",
				"/assets/arrow-left-CD89c06s.js",
				"/assets/circle-check-big-DqvcrxiE.js",
				"/assets/dollar-sign-BJIpFPF6.js"
			]
		},
		"/_app/dev/emails": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.dev.emails.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_app.dev.emails-BXOQy-Qy.js", "/assets/wrench-poqayd4S.js"]
		},
		"/_app/dev/statement": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.dev.statement.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_app.dev.statement-BA-EGelR.js", "/assets/wrench-poqayd4S.js"]
		},
		"/_app/loans/apply": {
			filePath: "C:/Users/Administrator/CascadeProjects/starehian-society-platform/frontend/src/routes/_app.loans.apply.tsx",
			children: void 0,
			assets: void 0,
			preloads: ["/assets/_app.loans.apply-BTh032AQ.js"]
		}
	},
	clientEntry: "/assets/index-DoqN2nBR.js"
});
//#endregion
export { tsrStartManifest };
